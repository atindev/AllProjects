﻿namespace GTS2021.API.Demo.Models
{
    public enum TaskStatus
    {
        NotStarted,
        Started,
        Overdue,
        Completed
    }
}
