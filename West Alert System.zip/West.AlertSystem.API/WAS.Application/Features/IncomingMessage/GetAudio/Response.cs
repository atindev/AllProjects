﻿using System;
using System.Collections.Generic;
using System.Text;

namespace WAS.Application.Features.IncomingMessage.GetAudio
{
    public class Response
    {
        /// <summary>
        /// Audio Content
        /// </summary>
        public string Content { get; set; }
    }
}
