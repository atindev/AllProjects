﻿using Microsoft.Graph;
namespace WAS.Application.Common.Settings
{
    public class UserBlockedInterval
    {
        /// <summary>
        /// In minutes
        /// </summary>
        public int UserBlockedTime { get; set; }
    }
}
