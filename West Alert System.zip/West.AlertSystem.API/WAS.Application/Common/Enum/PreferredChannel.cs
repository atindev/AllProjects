﻿using System;
using System.Collections.Generic;
using System.Text;

namespace WAS.Application.Common.Enum
{
    public enum PreferredChannel
    {
        OfficialEmail,
        PersonalEmail,
        VoiceOfficeMobile,
        VoicePersonalMobile,
        VoiceOfficePhone,
        VoiceHomePhone,
        TextOfficeMobile,
        TextPersonalMobile,
        WhatsAppOfficeMobile,
        WhatsAppPersonalMobile,
    }
}
