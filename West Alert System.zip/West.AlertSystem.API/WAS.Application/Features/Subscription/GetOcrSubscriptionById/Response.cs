﻿using WAS.Application.Common.Models;

namespace WAS.Application.Features.Subscription.GetOcrSubscriptionById
{
    public class Response
    {
        public OcrSubscription OcrSubscription { get; set; }
    }
}
