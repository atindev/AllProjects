﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using Microsoft.ApplicationBlocks.Data;
using System.Data;
using System.Data.SqlClient;
using System.Text;
using System.Collections;
using PMAssistReleaseVersion.AppCode.Generic;

namespace PMAssistReleaseVersion.UI.Resource
{
    public partial class SearchTickets : System.Web.UI.Page
    {
        string strReferenceNumber;
        string strModule;
        string strFromDate;
        string strToDate;
        string strCOType;
        string strTicketType;
        string strStatus;
        string strAssignedTo;

        protected void Page_PreInit(object sender, EventArgs e)
        {
            try
            {
                if (Session["LoginType"] != null)
                {
                    clsGeneral.SetMasterPage(this.Page);
                }
            }
            catch (Exception ex)
            {
                PMAssistReleaseVersion.AppCode.ErrorLogging.clsErrorLogging.LogError(ex.Message, "SearchTickets.aspx.cs", "Page_PreInit()");
                lblError.Text = "Failed";
            }


        }

        protected void Page_Load(object sender, EventArgs e)
        {

            try
            {

                if (!Page.IsPostBack)
                {
                    LoadIncidentChangeRequest();
                    LoadCOType();
                    LoadModules();
                    LoadStatusofTicket();
                    LoadAssignedTo();
                    BindGrid();
                }
            }

            catch (Exception ex)
            {
                PMAssistReleaseVersion.AppCode.ErrorLogging.clsErrorLogging.LogError(ex.Message, "SearchTickets.aspx.cs", "Page_Load()");
                lblError.Text = "Failed";
            }
            
          }

        //To bind gridview with the TicketDetails
        public void BindGrid()
        {
            try
            {
                //Here we are passing portalId to get Ticketdetails of the specif user
                DataTable dtTicketDetails = clsSearch.GetTicketDetails();
                gvTicketList.DataSource = dtTicketDetails;
                gvTicketList.DataBind();
                dtTicketDetails.Clear();

            }
            catch (Exception ex)
            {
                PMAssistReleaseVersion.AppCode.ErrorLogging.clsErrorLogging.LogError(ex.Message, "SearchTickets.aspx.cs", "BindGrid()");
                lblError.Text = "Failed";
            }
        }


        protected void btnSearch_Click(object sender, EventArgs e)
        {
            try
            {
                GetControlValues();
                DataSet dsTicketDetails = clsSearch.GetTicketDetailsbyCriteria(strReferenceNumber, strModule, strFromDate, strToDate, strCOType, strTicketType, strStatus, strAssignedTo);
                gvTicketList.DataSource = dsTicketDetails;
                gvTicketList.DataBind();


                if (gvTicketList.Rows.Count == 0)
                {
                    lblError.Visible = true;
                    lblError.Text = "Sorry, no  matches found the search parameters";
                }
                else
                {
                    lblError.Visible = false;
                    lblError.Text = "";
                }
            }
            catch (Exception ex)
            {
                PMAssistReleaseVersion.AppCode.ErrorLogging.clsErrorLogging.LogError(ex.Message, "SearchTicket.aspx.cs", "btnSearch_Click()");
                Response.Redirect("Oops.aspx");

            }


        }

        //Load LoadTIcketTypeDetails dropdown
        private void LoadIncidentChangeRequest()
        {
            try
            {
                DataTable dt = clsTicketInformation.LoadIncidentChangeRequestData();
                ddlTicketType.DataSource = dt;
                ddlTicketType.DataTextField = "tctpTicketType";
                ddlTicketType.DataValueField = "tctpId";
                ddlTicketType.DataBind();
                ddlTicketType.Items.Insert(0, new ListItem("Select Ticket Type", ""));
            }
            catch (Exception ex)
            {
                PMAssistReleaseVersion.AppCode.ErrorLogging.clsErrorLogging.LogError(ex.Message, "SearchTicket.aspx.cs", "LoadIncidentChangeRequest()");
                Response.Redirect("Oops.aspx");

            }

        }

        //Load LoadCOType dropdown
        private void LoadCOType()
        {
            try
            {
                DataTable dt = clsTicketInformation.LoadCOType();
                ddlCoType.DataSource = dt;
                ddlCoType.DataTextField = "CotpChangeOrderType";
                ddlCoType.DataValueField = "CotpId";
                ddlCoType.DataBind();
            }

            catch (Exception ex)
            {
                PMAssistReleaseVersion.AppCode.ErrorLogging.clsErrorLogging.LogError(ex.Message, "SearchTickets.aspx.cs", "LoadCOType()");
                lblError.Text = "Failed";
            }
         }


        //Load ModuleName dropdown
        private void LoadModules()
        {
            try
            {
                DataTable dt = clsTicketInformation.LoadModuleName();
                ddlModule.DataSource = dt;
                ddlModule.DataTextField = "ModlName";
                ddlModule.DataValueField = "ModlId";
                ddlModule.DataBind();
                ddlModule.Items.Insert(0, new ListItem("Select Module", ""));
            }

            catch (Exception ex)
            {
                PMAssistReleaseVersion.AppCode.ErrorLogging.clsErrorLogging.LogError(ex.Message, "SearchTickets.aspx.cs", "LoadModules()");
                lblError.Text = "Failed";
            }
        }

        //Load Status of Ticket dropdown
        private void LoadStatusofTicket()
        {
            try
            {
                DataTable dt = clsTicketInformation.LoadStatusofTicket();
                ddlStatus.DataSource = dt;
                ddlStatus.DataTextField = "TcstTicketStatus";
                ddlStatus.DataValueField = "TcstId";
                ddlStatus.DataBind();
                ddlStatus.Items.Insert(0, new ListItem("Select Ticket Status", ""));
            }

            catch (Exception ex)
            {
                PMAssistReleaseVersion.AppCode.ErrorLogging.clsErrorLogging.LogError(ex.Message, "SearchTickets.aspx.cs", "LoadStatusofTicket()");
                lblError.Text = "Failed";
            }
        }

        //Load AssignedTo dropdown
        private void LoadAssignedTo()
        {
            try
            {
                DataTable dt = clsTicketInformation.LoadAssignedTo();
                ddlAssignedTo.DataSource = dt;
                ddlAssignedTo.DataTextField = "UnsmFirstName";
                ddlAssignedTo.DataValueField = "UnsmPortalId";
                ddlAssignedTo.DataBind();
                ddlAssignedTo.Items.Insert(0, new ListItem("Select Assigned To", ""));
            }
            catch (Exception ex)
            {
                PMAssistReleaseVersion.AppCode.ErrorLogging.clsErrorLogging.LogError(ex.Message, "SearchTickets.aspx.cs", "LoadAssignedTo()");
                lblError.Text = "Failed";
            }

        }

        protected void OnPaging(object sender, GridViewPageEventArgs e)
        {
            try
            {
                BindGrid();
                gvTicketList.PageIndex = e.NewPageIndex;
                gvTicketList.DataBind();

            }
            catch (Exception ex)
            {
                PMAssistReleaseVersion.AppCode.ErrorLogging.clsErrorLogging.LogError(ex.Message, "SearchTickets.aspx.cs", "OnPaging()");
                lblError.Text = "Failed";
            }

        }

        private void GetControlValues()
        {
            try
            {
                strReferenceNumber = txtReferenceNumber.Text.TrimEnd().TrimStart();
                strModule = ddlModule.SelectedValue;
                strFromDate = Request.Form[txtFromDate.UniqueID].ToString();
                if (!(strFromDate == string.Empty))
                    strFromDate = Convert.ToDateTime(Request.Form[txtFromDate.UniqueID]).ToShortDateString();
                strToDate = Request.Form[txtToDate.UniqueID].ToString();
                if (!(strToDate == string.Empty))
                    strToDate = Convert.ToDateTime(Request.Form[txtToDate.UniqueID]).ToShortDateString();
                strCOType = ddlCoType.SelectedValue;
                strTicketType = ddlTicketType.SelectedValue;
                strStatus = ddlStatus.SelectedValue;
                strAssignedTo = ddlAssignedTo.SelectedValue;
            }

            catch (Exception ex)
            {
                PMAssistReleaseVersion.AppCode.ErrorLogging.clsErrorLogging.LogError(ex.Message, "SearchTickets.aspx.cs", "GetControlValues()");
                lblError.Text = "Failed";
            }
        }

        protected void gvTicketList_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            try
            {
                gvTicketList.PageIndex = e.NewPageIndex;
                BindGrid();
            }

            catch (Exception ex)
            {
                PMAssistReleaseVersion.AppCode.ErrorLogging.clsErrorLogging.LogError(ex.Message, "SearchTickets.aspx.cs", "gvTicketList_PageIndexChanging()");
                lblError.Text = "Failed";
            }
        }
    }
}
