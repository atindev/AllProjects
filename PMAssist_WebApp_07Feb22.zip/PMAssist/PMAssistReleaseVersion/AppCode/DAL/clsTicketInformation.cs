﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using Microsoft.ApplicationBlocks.Data;
using System.Data;
using System.Data.SqlClient;
using System.Collections;
using System.Globalization;

namespace PMAssistReleaseVersion.AppCode.Generic
{
    public class clsTicketInformation
    {

        // To Add Ticket details into database 
        public static void AddTicketDetails(string referenceNumber, string incidentChangeRequest, string ticketType, string coNumber, string complexity, string coType, string priority, string moduleName,
                                            string incidentCategory, string statusOfTicket, string assignedTo, string assignedDate, string assignedTime, string resolvedDate, string resolvedTime, string acknowledgeDate,
                                            string acknowledgeTime, string targetDate, string ticketDescription, string comments, string reasonForRejection, string entryId, int originOfDefect, string reviewedBy,
                                            string dateOfPeerReview, string actualEffort)
        {
            try
            {

                SqlParameter[] par = new SqlParameter[26];
                par[0] = new SqlParameter("@vchTcktReferenceNumber", referenceNumber);
                par[1] = new SqlParameter("@sintTcktTctpId", incidentChangeRequest);
                par[2] = new SqlParameter("@sintTcktTctdId", ticketType);
                par[3] = new SqlParameter("@sintTcktCotypeId", coType);
                par[4] = new SqlParameter("@vchTcktCoNumber", coNumber);
                par[5] = new SqlParameter("@sintTcktCplxId", complexity);
                par[6] = new SqlParameter("@sintTcktPriorityId", priority);
                par[7] = new SqlParameter("@intTcktModulelId", moduleName);
                par[8] = new SqlParameter("@sintTcktIncidentCategoryId", incidentCategory);
                par[9] = new SqlParameter("@sintTcktStatusOfTicketId", statusOfTicket);
                par[10] = new SqlParameter("@intTcktAssignedTo", assignedTo);
                par[11] = new SqlParameter("@vchTcktAssignedDate", assignedDate);
                par[12] = new SqlParameter("@vchTcktAssignedTime", assignedTime);
                par[13] = new SqlParameter("@vchTcktResolvedDate", resolvedDate);
                par[14] = new SqlParameter("@vchTcktResolvedTime", resolvedTime);
                par[15] = new SqlParameter("@vchTcktAcknowledgeDate", acknowledgeDate);
                par[16] = new SqlParameter("@vchTcktAcknowldedgeTime", acknowledgeTime);
                par[17] = new SqlParameter("@vchTargetDate", targetDate);
                par[18] = new SqlParameter("@vchTcktDescription", ticketDescription);
                par[19] = new SqlParameter("@vchTcktComments", comments);
                par[20] = new SqlParameter("@vchTcktReasonForRejection", reasonForRejection);
                par[21] = new SqlParameter("@intTcktEntryId", entryId);
                par[22] = new SqlParameter("@intOriginOfDefect", originOfDefect);
                par[23] = new SqlParameter("@intReviewedBy", reviewedBy);
                par[24] = new SqlParameter("@vchDateOfPeerReview", dateOfPeerReview);
                par[25] = new SqlParameter("@vchActualEffort", actualEffort);

                SqlHelper.ExecuteNonQuery(clsGeneral.ConStr, CommandType.StoredProcedure, "spAddTicketdetails", par);
            }

            catch (Exception ex)
            {
                PMAssistReleaseVersion.AppCode.ErrorLogging.clsErrorLogging.LogError(ex.Message, "clsTicketInformation.cs", "SaveTicketDetails");
                throw;

            }

        }

        // To Update Ticket details in to database
        public static DataSet UpdateTicketDetailsByID(int ticketId, string referenceNumber, string incidentChangeRequest, string ticketType, string coNumber, string coType, string complexity, string priority, string moduleName,
                                            string incidentCategory, string statusOfTicket, string assignedTo, string assignedTime, string resolvedDate, string resolvedTime, string acknowledgeTime, string targetDate, string ticketDescription, string comments, string reasonForRejection, string entryId,
                                            int originOfDefect, string reviewedBy, string dateOfPeerReview, string actualEffort)
        {
            try
            {
                SqlParameter[] par = new SqlParameter[23];
                par[0] = new SqlParameter("@intTicketId", ticketId);
                par[1] = new SqlParameter("@vchTcktReferenceNumber", referenceNumber);
                par[2] = new SqlParameter("@sintTcktTctpId", Convert.ToInt32(incidentChangeRequest));
                par[3] = new SqlParameter("@@sintTcktTctdId", Convert.ToInt32(ticketType));
                par[4] = new SqlParameter("@sintTcktCotypeId", Convert.ToInt32(coType));
                par[5] = new SqlParameter("@vchTcktCoNumber", coNumber);
                par[6] = new SqlParameter("@sintTcktCplxId", complexity);
                par[7] = new SqlParameter("@sintTcktPriorityId", Convert.ToInt32(priority));
                par[8] = new SqlParameter("@intTcktModulelId", Convert.ToInt32(moduleName));
                par[9] = new SqlParameter("@sintTcktIncidentCategoryId", Convert.ToInt32(incidentCategory));
                par[10] = new SqlParameter("@sintTcktStatusOfTicketId", Convert.ToInt32(statusOfTicket));
                par[11] = new SqlParameter("@intTcktAssignedTo", assignedTo);
                //par[9] = new SqlParameter("@dtTcktAssignedDate", AssignedDate);
                //par[10] = new SqlParameter("@timeTcktAssignedTime", AssignedTime);
                par[12] = new SqlParameter("@vchTcktResolvedDate", resolvedDate);
                par[13] = new SqlParameter("@vchTcktResolvedTime", resolvedTime);
                par[14] = new SqlParameter("@vchTargetDate", targetDate);
                //par[13] = new SqlParameter("@dtTcktAcknowledgeDate", AcknowledgeDate);
                //par[14] = new SqlParameter("@timeTcktAcknowldedgeTime", AcknowledgeTime);
                par[15] = new SqlParameter("@vchTcktDescription", ticketDescription);
                par[16] = new SqlParameter("@vchTcktComments", comments);
                par[17] = new SqlParameter("@vchTcktReasonForRejection", reasonForRejection);
                par[18] = new SqlParameter("@intTcktLastChangedId", Convert.ToInt32(entryId));
                par[19] = new SqlParameter("@intOriginOfDefect", originOfDefect);
                par[20] = new SqlParameter("@intReviewedBy", reviewedBy);
                par[21] = new SqlParameter("@vchDateOfPeerReview", dateOfPeerReview);
                par[22] = new SqlParameter("@vchActualEffort", actualEffort);
                return SqlHelper.ExecuteDataset(clsGeneral.ConStr, "dbo.spUpdateTicketdetails", par);
            }
            catch (Exception ex)
            {
                PMAssistReleaseVersion.AppCode.ErrorLogging.clsErrorLogging.LogError(ex.Message, "clsTicketInformation.cs", "UpdateTicketDetailsByID");
                throw;
            }

        }

        // To Get TicketDetails
        public static DataTable GetTicketDetailsByPortalId(string PortalId)
        {
            SqlParameter[] par = new SqlParameter[1];
            par[0] = new SqlParameter("@TcktAssignedTo", PortalId);
            DataSet ds = SqlHelper.ExecuteDataset(clsGeneral.ConStr, "sptblGetTickets");
            return ds.Tables[0];
        }

        // To Get TicketDetails for KPI Calculation
        public static DataTable GetTicketDetailsByPortalIdForSlaCalculation(string PortalId)
        {
            SqlParameter[] par = new SqlParameter[1];
            par[0] = new SqlParameter("@intPortalId", PortalId);
            DataSet ds = SqlHelper.ExecuteDataset(clsGeneral.ConStr, "dbo.spGetKPIStatus", par);
            return ds.Tables[0];
        }

        // To get complete ticketdetails by TicketId
        public static DataSet GetTicketDetailsById(string TicketId)
        {
            try
            {
                SqlParameter[] par = new SqlParameter[1];
                par[0] = new SqlParameter("@TicketId", TicketId);
                return SqlHelper.ExecuteDataset(clsGeneral.ConStr, "spGetTicketDetailsByTicketID", par);
            }
            catch (Exception ex)
            {
                PMAssistReleaseVersion.AppCode.ErrorLogging.clsErrorLogging.LogError(ex.Message, "clsTicketInformation.cs", "GetTicketDetailsById");
                throw;

            }

        }

        //Check whether the Reference Number exist or not 
        public static DataSet CheckReferenceNumber(string ReferenceNumber)
        {
            try
            {
                SqlParameter[] par = new SqlParameter[1];
                par[0] = new SqlParameter("@ReferenceNumber", ReferenceNumber);
                return SqlHelper.ExecuteDataset(clsGeneral.ConStr, "spCheckReference", par);
            }
            catch (Exception ex)
            {
                PMAssistReleaseVersion.AppCode.ErrorLogging.clsErrorLogging.LogError(ex.Message, "clsTicketInformation.cs", "CheckReferenceNumber");
                throw;
            }

        }

        //Load IncidentChangeRequest data
        public static DataTable LoadIncidentChangeRequestData()
        {
            DataSet ds = SqlHelper.ExecuteDataset(clsGeneral.ConStr, "spGetIncidentChangeRequestData");
            return ds.Tables[0];
        }

        //Load COType data
        public static DataTable LoadCOType()
        {
            DataSet ds = SqlHelper.ExecuteDataset(clsGeneral.ConStr, "spGetCOTypeDetails");
            return ds.Tables[0];
        }
        //Load Priority data
        public static DataTable LoadPriorityData()
        {
            DataSet ds = SqlHelper.ExecuteDataset(clsGeneral.ConStr, "spGetPriorityData");
            return ds.Tables[0];
        }

        //Load ModuleName data
        public static DataTable LoadModuleName()
        {
            DataSet ds = SqlHelper.ExecuteDataset(clsGeneral.ConStr, "spGetModuleName");
            return ds.Tables[0];
        }


        //Load Incident Category data
        public static DataTable LoadIncidentCategory()
        {
            DataSet ds = SqlHelper.ExecuteDataset(clsGeneral.ConStr, "spGetIncidentCategory");
            return ds.Tables[0];
        }

        //Load Status of ticket data
        public static DataTable LoadStatusofTicket()
        {
            DataSet ds = SqlHelper.ExecuteDataset(clsGeneral.ConStr, "spGetTicketStatus");
            return ds.Tables[0];
        }


        //Load Assigned To
        public static DataTable LoadAssignedTo()
        {
            DataSet ds = SqlHelper.ExecuteDataset(clsGeneral.ConStr, "spGetAssignedTo");
            return ds.Tables[0];
        }
        //Load Sla Years
        public static DataTable LoadSlaYears()
        {
            DataSet ds = SqlHelper.ExecuteDataset(clsGeneral.ConStr, "spGetSlaYears");
            return ds.Tables[0];
        }
        //Load Ticket Type
        public static DataTable LoadTicketType()
        {
            DataSet ds = SqlHelper.ExecuteDataset(clsGeneral.ConStr, "spGetTicketType");
            return ds.Tables[0];
        }
        //Load Ticket Type
        public static DataTable LoadComplexity()
        {
            DataSet ds = SqlHelper.ExecuteDataset(clsGeneral.ConStr, "spGetComplexity");
            return ds.Tables[0];
        }
        //Load Reason for Defect
        public static DataTable LoadOriginOfDefect()
        {
            DataSet ds = SqlHelper.ExecuteDataset(clsGeneral.ConStr, "spGetOriginOfDefect");
            return ds.Tables[0];
        }
        public static DataTable LoadAvailabeReports()
        {
            DataSet ds = SqlHelper.ExecuteDataset(clsGeneral.ConStr, "spGetAvailableReports");
            return ds.Tables[0];
        }

        public static clsTicketDetails LoadTicketDetailsByReference(string TicketReference)
        {
            SqlCommand cmd = new SqlCommand();
            cmd.CommandText = "spLoadTicketDetailsByReference";
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@ReferenceNumber", TicketReference);
            DataSet dsTicketDetails = SqlHelper.ExecuteDataset(clsGeneral.ConStr, cmd.CommandType, cmd.CommandText, cmd);
            var TicketDetails = new clsTicketDetails();
            if (dsTicketDetails != null && dsTicketDetails.Tables.Count > 0 && dsTicketDetails.Tables[0].Rows.Count > 0)
            {
                TicketDetails.TicketId = Convert.ToInt32(dsTicketDetails.Tables[0].Rows[0]["TicketId"].ToString());
                TicketDetails.TicketReferenceNumber = dsTicketDetails.Tables[0].Rows[0]["ReferenceNumber"].ToString();
                TicketDetails.TicketTypeId = Convert.ToInt32(dsTicketDetails.Tables[0].Rows[0]["TicketType"].ToString());
                TicketDetails.CoNumber = dsTicketDetails.Tables[0].Rows[0]["CoNumber"].ToString();
                TicketDetails.CotypeId = Convert.ToInt32(dsTicketDetails.Tables[0].Rows[0]["CoTypeId"].ToString());
                TicketDetails.PriorityId = Convert.ToInt32(dsTicketDetails.Tables[0].Rows[0]["PriorityId"].ToString());
                TicketDetails.ModuleId = Convert.ToInt32(dsTicketDetails.Tables[0].Rows[0]["ModuleId"].ToString());
                TicketDetails.IncidentCategoryId = Convert.ToInt32(dsTicketDetails.Tables[0].Rows[0]["IncidentCategoryId"].ToString());
                TicketDetails.StatusOfTicketId = Convert.ToInt32(dsTicketDetails.Tables[0].Rows[0]["TicketStatus"].ToString());
                TicketDetails.FirstName = dsTicketDetails.Tables[0].Rows[0]["FirstName"].ToString();
                TicketDetails.AcknowldedgeDate = dsTicketDetails.Tables[0].Rows[0]["AcknowldedgeDate"].ToString();
                TicketDetails.AcknowldedgeTime = dsTicketDetails.Tables[0].Rows[0]["AcknowldedgeTime"].ToString();
                TicketDetails.AssignedTo = dsTicketDetails.Tables[0].Rows[0]["AssignedTo"].ToString();
                TicketDetails.AssignedDate = dsTicketDetails.Tables[0].Rows[0]["AssignedDate"].ToString();
                TicketDetails.AssignedTime = dsTicketDetails.Tables[0].Rows[0]["AssignedTime"].ToString();
                TicketDetails.Comments = dsTicketDetails.Tables[0].Rows[0]["Comments"].ToString();
                TicketDetails.Description = dsTicketDetails.Tables[0].Rows[0]["Description"].ToString();
                TicketDetails.KpiDate = dsTicketDetails.Tables[0].Rows[0]["KPIDate"].ToString();
                TicketDetails.ResolvedDate = dsTicketDetails.Tables[0].Rows[0]["ResolvedDate"].ToString();
                TicketDetails.ResolvedTime = dsTicketDetails.Tables[0].Rows[0]["ResolvedTime"].ToString();
                TicketDetails.ReasonForRejection = dsTicketDetails.Tables[0].Rows[0]["ReasonForRejection"].ToString();
                TicketDetails.EntryDate = dsTicketDetails.Tables[0].Rows[0]["EntryDate"].ToString();
                TicketDetails.EntryId = Convert.ToInt32(dsTicketDetails.Tables[0].Rows[0]["EntryId"].ToString());
                TicketDetails.ComplexityId = Convert.ToInt32(dsTicketDetails.Tables[0].Rows[0]["ComplexId"].ToString());
                TicketDetails.TicketTypeInDetailId = Convert.ToInt32(dsTicketDetails.Tables[0].Rows[0]["TicketTypeInDetailId"].ToString());
                TicketDetails.TargetDate = dsTicketDetails.Tables[0].Rows[0]["TargetDate"].ToString();
                TicketDetails.OriginOfDefect = Convert.ToInt32(dsTicketDetails.Tables[0].Rows[0]["OriginOfDefect"].ToString());
                TicketDetails.ReviewedBy = dsTicketDetails.Tables[0].Rows[0]["ReviewedBy"].ToString();
                TicketDetails.DateOfPeerReview = dsTicketDetails.Tables[0].Rows[0]["DateOfPeerReview"].ToString();
                TicketDetails.ActualEffort = dsTicketDetails.Tables[0].Rows[0]["ActualEffort"].ToString();
            }
            return TicketDetails;

        }

        public static string GetKPIByAsnDatePrty(string AssignedDateTime, string Priority)
        {
            var str = string.Empty;
            try
            {
                SqlCommand cmd = new SqlCommand();
                cmd.Connection = new SqlConnection(clsGeneral.ConStr);
                cmd.CommandText = "dbo.spGetKpiByAssignedDateAndPrty";
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@vchTcktAssignedDate", AssignedDateTime + ":00");
                cmd.Parameters.AddWithValue("@vchPrtyPriority", Priority);
                cmd.Parameters.Add("@dteKPIDate", SqlDbType.DateTime);
                cmd.Parameters["@dteKPIDate"].Direction = ParameterDirection.Output;
                cmd.Connection.Open();
                cmd.ExecuteNonQuery();
                cmd.Connection.Close();
                str = cmd.Parameters["@dteKPIDate"].Value.ToString();
                DateTime dt = Convert.ToDateTime(str);
                str = dt.ToString("dd-MMM-yyyy, HH:mm tt");
                //str = dt.ToString("dd-MMM-yyyy");
            }
            catch (Exception ex)
            {
                PMAssistReleaseVersion.AppCode.ErrorLogging.clsErrorLogging.LogError(ex.Message, "clsTicketInformation.cs", "GetKPIByAckDatePrty()");
            }
            return str;
        }
    }
}