﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using Microsoft.ApplicationBlocks.Data;
using System.Data;
using System.Data.SqlClient;
using System.Text;
using PMAssistReleaseVersion.AppCode;
using PMAssistReleaseVersion.AppCode.Generic;
using AjaxControlToolkit;
using System.Globalization;

namespace PMAssistReleaseVersion.UI.Resource
{
    public partial class AddTicketDetails : System.Web.UI.Page
    {
        string ReferenceNumber;
        string AssignedDate;
        string AcknowledgeDate;
        string ResolvedDate;
        string TargetDate;
        string DateOfPeerReview;

        protected void Page_PreInit(object sender, EventArgs e)
        {
            try
            {
                if (Session["LoginType"] != null)
                {
                    clsGeneral.SetMasterPage(this.Page);
                }
            }
            catch (Exception ex)
            {
                PMAssistReleaseVersion.AppCode.ErrorLogging.clsErrorLogging.LogError(ex.Message, "AddTicketDetails.aspx.cs", "Page_PreInit()");
                lblError.Text = "Failed";
            }
        }

        protected void Page_Load(object sender, EventArgs e)
        {
            try
            {
                if (!IsPostBack)
                {
                    LoadControls();

                    if (Request.QueryString["EditTicketReference"] != null)
                    {
                        var TicketDetails = clsTicketInformation.LoadTicketDetailsByReference(Request.QueryString["EditTicketReference"].ToString());
                        ViewTicketDetails(TicketDetails);
                        CustomizeEditPageControls(TicketDetails);
                    }
                    else if (Request.QueryString["ViewTicketReference"] != null)
                    {
                        var TicketDetails = clsTicketInformation.LoadTicketDetailsByReference(Request.QueryString["ViewTicketReference"].ToString());
                        ViewTicketDetails(TicketDetails);
                        CustomizeViewPageControls(TicketDetails);
                    }
                }
                SetResolvedTimeTextBox();
                //txtAssignedDate_CalendarExtender.s
                Page.Validate();
            }
            catch (Exception ex)
            {
                PMAssistReleaseVersion.AppCode.ErrorLogging.clsErrorLogging.LogError(ex.Message, "AddTicketDetails.aspx.cs", "Page_Load()");
                lblError.Text = "Failed";
            }
        }

        public void SetResolvedTimeTextBox()
        {
            try
            {
                if ((string.IsNullOrEmpty(txtResolvedDate.Text) && string.IsNullOrEmpty(txtResolvedTime.Text)))
                {
                    txtResolvedTime.Enabled = false;
                    txtResolvedTime_MaskedEditExtender_MaskedEditValidator.IsValidEmpty = true;
                    txtResolvedTime.Text = string.Empty;
                    reqPeerReviewedByRequired.Enabled = false;
                    ddlReviewedby.SelectedValue = "";
                    reqDateOfPeerReviewRequired.Enabled = false;
                    txtDateOfPeerReview.Text = string.Empty;
                    reqActualEffortRequired.Enabled = false;
                    txtActualEffort.Text = string.Empty;
                }
                else if (!string.IsNullOrEmpty(txtResolvedDate.Text) && string.IsNullOrEmpty(txtResolvedTime.Text))
                {
                    txtResolvedTime.Enabled = true;
                    txtResolvedTime_MaskedEditExtender_MaskedEditValidator.IsValidEmpty = false;
                    reqPeerReviewedByRequired.Enabled = true;
                    reqDateOfPeerReviewRequired.Enabled = true;
                    txtDateOfPeerReview.Text = string.Empty;
                    reqActualEffortRequired.Enabled = true;
                    txtActualEffort.Text = string.Empty;
                    //rngPeerReviewMaximum.MaximumValue = txtResolvedDate.Text.TrimEnd().TrimStart().Length > 0?txtResolvedDate.Text:"1900-01-01";
                }
                else if (string.IsNullOrEmpty(txtResolvedDate.Text) && !string.IsNullOrEmpty(txtResolvedTime.Text))
                {
                    txtResolvedTime.Enabled = false;
                    txtResolvedTime_MaskedEditExtender_MaskedEditValidator.IsValidEmpty = true;
                    txtResolvedTime.Text = string.Empty;
                    reqPeerReviewedByRequired.Enabled = false;
                    ddlReviewedby.SelectedValue = "";
                    reqDateOfPeerReviewRequired.Enabled = false;
                    txtDateOfPeerReview.Text = string.Empty;
                    reqActualEffortRequired.Enabled = false;
                    txtActualEffort.Text = string.Empty;
                }
                else if (!(string.IsNullOrEmpty(txtResolvedDate.Text) && string.IsNullOrEmpty(txtResolvedTime.Text)) && Request.QueryString["EditTicketReference"] != null)
                {
                    txtResolvedTime.Enabled = true;
                    txtResolvedTime_MaskedEditExtender_MaskedEditValidator.IsValidEmpty = false;
                    reqPeerReviewedByRequired.Enabled = true;
                    reqDateOfPeerReviewRequired.Enabled = true;
                    reqActualEffortRequired.Enabled = true;
                    //rngPeerReviewMaximum.MaximumValue = txtResolvedDate.Text;
                }
                if (Request.QueryString["ViewTicketReference"] != null)
                {
                    txtResolvedTime.Enabled = false;
                    txtResolvedTime.BackColor = System.Drawing.Color.Transparent;
                    txtResolvedTime.BorderStyle = BorderStyle.None;
                    ddlReviewedby.BackColor = System.Drawing.Color.Transparent;
                    ddlReviewedby.Enabled = false;
                    ddlReviewedby.BorderStyle = BorderStyle.None;
                    txtDateOfPeerReview.Enabled = false;
                    txtDateOfPeerReview.BackColor = System.Drawing.Color.Transparent;
                    txtDateOfPeerReview.BorderStyle = BorderStyle.None;
                    txtActualEffort.Enabled = false;
                    txtActualEffort.BackColor = System.Drawing.Color.Transparent;
                    txtActualEffort.BorderStyle = BorderStyle.None;
                }
                //rngPeerReviewMaximum.Enabled = reqPeerReviewedByRequired.Enabled;
            }
            catch (Exception ex)
            {
                PMAssistReleaseVersion.AppCode.ErrorLogging.clsErrorLogging.LogError(ex.Message, "AddTicketDetails.aspx.cs", "SetResolvedTimeTextBox()");
                lblError.Text = "Failed";
            }
        }
        public void SetPeerReviewedBy()
        {
            
        }
        public void CustomizeEditPageControls(clsTicketDetails TicketDetails)
        {
            try
            {
                btnSubmit.Text = "Update";
                lblHeading.Text = "Edit Ticket Details";
                txtReferenceNumber.Enabled = false;
                txtAssignedDate.Enabled = false;
                txtAcknowledgeDate.Enabled = false;

                txtAssignedTime.Enabled = false;
                txtAcknowledgeTime.Enabled = false;

                if (TicketDetails.TicketTypeId == 3)
                {
                    ddlCoType.Enabled = true;
                    txtCoNumber.Enabled = true;
                }
                reqCommentsRequired.InitialValue = TicketDetails.Comments;
            }
            catch (Exception ex)
            {
                PMAssistReleaseVersion.AppCode.ErrorLogging.clsErrorLogging.LogError(ex.Message, "AddTicketDetails.aspx.cs", "CustomizeEditPageControls()");
                lblError.Text = "Failed";
            }
        }
        //To apply disable properties to controls in View Page
        public void CustomizeViewPageControls(clsTicketDetails TicketDetails)
        {
            try
            {
                if (Session["intUnsmPortalId"].ToString() == TicketDetails.AssignedTo.ToString())
                {

                    btnEdit.Visible = true;
                }

                lblHeading.Text = "View Ticket Details";
                lblMandatory.Visible = false;
                btnSubmit.Visible = false;

                ContentPlaceHolder cntPlcHldrMaster = (ContentPlaceHolder)Master.FindControl("ContentPlaceHolderMaster");
                foreach (Control inputControl in cntPlcHldrMaster.Controls)
                {
                    if (inputControl is TextBox)
                    {
                        ((TextBox)inputControl).BackColor = System.Drawing.Color.Transparent;
                        ((TextBox)inputControl).Enabled = false;
                        ((TextBox)inputControl).BorderStyle = BorderStyle.None;
                    }
                    if (inputControl is DropDownList)
                    {
                        ((DropDownList)inputControl).BackColor = System.Drawing.Color.Transparent;
                        ((DropDownList)inputControl).Enabled = false;
                        ((DropDownList)inputControl).BorderStyle = BorderStyle.None;
                    }
                }
                ddlCoType.BackColor = System.Drawing.Color.Transparent;
                ddlCoType.Enabled = false;
                ddlCoType.BorderStyle = BorderStyle.None;

                txtCoNumber.BackColor = System.Drawing.Color.Transparent;
                txtCoNumber.Enabled = false;
                txtCoNumber.BorderStyle = BorderStyle.None;

                ddlTicketType.BackColor = System.Drawing.Color.Transparent;
                ddlTicketType.Enabled = false;
                ddlTicketType.BorderStyle = BorderStyle.None;

            }

            catch (Exception ex)
            {
                PMAssistReleaseVersion.AppCode.ErrorLogging.clsErrorLogging.LogError(ex.Message, "AddTicketDetails.aspx.cs", "CustomizeViewPageControls()");
                lblError.Text = "Failed";
            }


        }
        //To View Ticket Details
        public void ViewTicketDetails(clsTicketDetails ViewTicketDetails)
        {
            try
            {
                ViewState["TicketId"] = ViewTicketDetails.TicketId;
                txtReferenceNumber.Text = ViewTicketDetails.TicketReferenceNumber;
                ddlIncidentChangeRequest.SelectedValue = ViewTicketDetails.TicketTypeId.ToString();
                txtCoNumber.Text = ViewTicketDetails.CoNumber;
                ViewState["CoNumber"] = ViewTicketDetails.CoNumber;
                ddlCoType.SelectedValue = ViewTicketDetails.CotypeId.ToString();
                ddlModuleName.SelectedValue = ViewTicketDetails.ModuleId.ToString();
                ddlPriority.SelectedValue = ViewTicketDetails.PriorityId.ToString();
                ddlStatusofTicket.SelectedValue = ViewTicketDetails.StatusOfTicketId.ToString();
                ddlIncidentCategory.SelectedValue = ViewTicketDetails.IncidentCategoryId.ToString();
                ddlAssignedTo.SelectedValue = ViewTicketDetails.AssignedTo.ToString();
                txtAssignedDate.Text = Convert.ToDateTime(ViewTicketDetails.AssignedDate).ToString("dd-MMM-yyyy");
                txtAssignedTime.Text = ViewTicketDetails.AssignedTime.Substring(0, 5);

                if (!(ViewTicketDetails.ResolvedDate == string.Empty))
                    txtResolvedDate.Text = DateTime.ParseExact(ViewTicketDetails.ResolvedDate, "dd/MM/yyyy", CultureInfo.InvariantCulture).ToString("dd-MMM-yyyy");

                txtResolvedTime.Text = ViewTicketDetails.ResolvedTime == string.Empty ? string.Empty : ViewTicketDetails.ResolvedTime.Substring(0, 5);
                txtAcknowledgeDate.Text = Convert.ToDateTime(ViewTicketDetails.AcknowldedgeDate).ToString("dd-MMM-yyyy");

                txtAcknowledgeTime.Text = ViewTicketDetails.AcknowldedgeTime.Substring(0, 5);
                txtTicketDescription.Text = ViewTicketDetails.Description;
                txtComments.Text = ViewTicketDetails.Comments;
                txtReasonforRejection.Text = ViewTicketDetails.ReasonForRejection;
                ddlComplexity.SelectedValue = ViewTicketDetails.ComplexityId.ToString();
                ddlTicketType.SelectedValue = ViewTicketDetails.TicketTypeInDetailId.ToString();
                if (!(ViewTicketDetails.TargetDate == string.Empty))
                    txtTargetDate.Text = DateTime.ParseExact(ViewTicketDetails.TargetDate, "dd/MM/yyyy", CultureInfo.InvariantCulture).ToString("dd-MMM-yyyy");
                ddlOriginOfDefect.SelectedValue = ViewTicketDetails.OriginOfDefect.ToString();
                ddlReviewedby.SelectedValue = ViewTicketDetails.ReviewedBy.ToString();
                if (!(ViewTicketDetails.DateOfPeerReview == string.Empty))
                    txtDateOfPeerReview.Text = DateTime.ParseExact(ViewTicketDetails.DateOfPeerReview, "dd/MM/yyyy", CultureInfo.InvariantCulture).ToString("dd-MMM-yyyy");
                txtActualEffort.Text = ViewTicketDetails.ActualEffort;
                GetKpi();
            }

            catch (Exception ex)
            {
                PMAssistReleaseVersion.AppCode.ErrorLogging.clsErrorLogging.LogError(ex.Message, "AddTicketDetails.aspx.cs", "ViewTicketDetails()");
                lblError.Text = "Failed";
            }

        }

        //To Save Ticket Details 
        public void AddTicketInformation()
        {
            try
            {
                clsTicketInformation.AddTicketDetails(txtReferenceNumber.Text, ddlIncidentChangeRequest.SelectedValue, ddlTicketType.SelectedValue, txtCoNumber.Text, ddlComplexity.SelectedValue, ddlCoType.SelectedValue, ddlPriority.SelectedValue, ddlModuleName.SelectedValue,
                    ddlIncidentCategory.SelectedValue, ddlStatusofTicket.SelectedValue, ddlAssignedTo.SelectedValue, AssignedDate, txtAssignedTime.Text + ":00", ResolvedDate, txtResolvedTime.Text == string.Empty ? string.Empty : txtResolvedTime.Text + ":00", AcknowledgeDate,
                                                      txtAcknowledgeTime.Text + ":00", TargetDate, txtTicketDescription.Text, txtComments.Text, txtReasonforRejection.Text, Session["intUnsmPortalId"].ToString(), Convert.ToInt32(ddlOriginOfDefect.SelectedValue), ddlReviewedby.SelectedValue == string.Empty ? "0" : ddlReviewedby.SelectedValue, DateOfPeerReview, txtActualEffort.Text);
                
                //Master Popup Code
                Label lblAddTicketPopupMessageMasterMessage = (Label)Master.FindControl("lblAddTicketPopupMessageMaster");
                lblAddTicketPopupMessageMasterMessage.Text = "New Ticket with reference \"" + txtReferenceNumber.Text + "\" is added successfully into PMAssist";
                ModalPopupExtender hdnAddTicketPopup_ModalPopupExtenderMasterPanel = (ModalPopupExtender)Master.FindControl("hdnAddTicketPopupMaster_ModalPopupExtender");
                hdnAddTicketPopup_ModalPopupExtenderMasterPanel.Show();

                }

            catch (Exception ex)
            {
                PMAssistReleaseVersion.AppCode.ErrorLogging.clsErrorLogging.LogError(ex.Message, "AddTicketDetails.aspx.cs", "AddTicketInformation()");
                lblError.Text = "Failed to Add";
            }
        }

        // To Update Ticket Details 

        public void UpdateTicketDetails()
        {
            try
            {
                if (!(txtCoNumber.Text == string.Empty))
                    ViewState["CoNumber"] = txtCoNumber.Text;
                clsTicketInformation.UpdateTicketDetailsByID(Convert.ToInt32(ViewState["TicketId"].ToString()), txtReferenceNumber.Text, ddlIncidentChangeRequest.SelectedValue, ddlTicketType.SelectedValue, ViewState["CoNumber"].ToString(), ddlCoType.SelectedValue, ddlComplexity.SelectedValue, ddlPriority.SelectedValue, ddlModuleName.SelectedValue,
                                                      ddlIncidentCategory.SelectedValue, ddlStatusofTicket.SelectedValue, ddlAssignedTo.SelectedValue, txtAssignedTime.Text + ":00", ResolvedDate, txtResolvedTime.Text == string.Empty ? string.Empty : txtResolvedTime.Text + ":00",
                                                      txtAcknowledgeTime.Text + ":00", TargetDate, txtTicketDescription.Text, txtComments.Text, txtReasonforRejection.Text, Session["intUnsmPortalId"].ToString(), Convert.ToInt32(ddlOriginOfDefect.SelectedValue), ddlReviewedby.SelectedValue == string.Empty ? "0" : ddlReviewedby.SelectedValue, DateOfPeerReview, txtActualEffort.Text);
                
                Label lblAddTicketPopupMessageMasterMessage = (Label)Master.FindControl("lblAddTicketPopupMessageMaster");
                lblAddTicketPopupMessageMasterMessage.Text = "Ticket details with reference \"" + txtReferenceNumber.Text + "\" is updated successfully into PMAssist";
                ModalPopupExtender hdnAddTicketPopup_ModalPopupExtenderMasterPanel = (ModalPopupExtender)Master.FindControl("hdnAddTicketPopupMaster_ModalPopupExtender");
                hdnAddTicketPopup_ModalPopupExtenderMasterPanel.Show();
            }

            catch (Exception ex)
            {
                PMAssistReleaseVersion.AppCode.ErrorLogging.clsErrorLogging.LogError(ex.Message, "AddTicketDetails.aspx.cs", "UpdateTicketDetails()");
                lblError.Text = "Failed to Update";
            }
        }


        
        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            // To save Ticket Details in to database
            try
            {
                if(Page.IsValid)
                    SaveData();
            }
            catch (Exception ex)
            {
                PMAssistReleaseVersion.AppCode.ErrorLogging.clsErrorLogging.LogError(ex.Message, "AddTicketDetails.aspx.cs", "btnSubmit_Click()");
                Response.Redirect("Oops.aspx");
            }
        }

        // code to check whether the reference exists or not 

        public void SaveData()
        {
            try
            {
                ReferenceNumber = txtReferenceNumber.Text;
                DataSet dsReferenceNumberExists = clsTicketInformation.CheckReferenceNumber(ReferenceNumber);
                DataTable dtCheckReferenceNumber = dsReferenceNumberExists.Tables[0];

                ResolvedDate = Request.Form[txtResolvedDate.UniqueID].ToString();
                if (!(ResolvedDate == string.Empty))
                    ResolvedDate = Convert.ToDateTime(Request.Form[txtResolvedDate.UniqueID]).ToString("dd/MM/yyyy");
                TargetDate = Request.Form[txtTargetDate.UniqueID].ToString();
                if (!(TargetDate == string.Empty))
                    TargetDate = Convert.ToDateTime(Request.Form[txtTargetDate.UniqueID]).ToString("dd/MM/yyyy");
                DateOfPeerReview = Request.Form[txtDateOfPeerReview.UniqueID].ToString();
                if (!(DateOfPeerReview == string.Empty))
                    DateOfPeerReview = Convert.ToDateTime(Request.Form[txtDateOfPeerReview.UniqueID]).ToString("dd/MM/yyyy");
                if (dtCheckReferenceNumber.Rows.Count == 0)
                {
                    AssignedDate = Request.Form[txtAssignedDate.UniqueID].ToString();
                    if (!(AssignedDate == string.Empty))
                        AssignedDate = Convert.ToDateTime(Request.Form[txtAssignedDate.UniqueID]).ToShortDateString();
                    AcknowledgeDate = Request.Form[txtAcknowledgeDate.UniqueID].ToString();
                    if (!(AcknowledgeDate == string.Empty))
                        AcknowledgeDate = Convert.ToDateTime(Request.Form[txtAcknowledgeDate.UniqueID]).ToShortDateString();
                    AddTicketInformation();
                }
                else
                {
                    if (Request.QueryString["EditTicketReference"] != null)
                    {
                        UpdateTicketDetails();
                    }
                    else
                    {
                        lblError.Text = "Ticket reference number already exists";
                    }
                }
            }
            catch (Exception ex)
            {
                PMAssistReleaseVersion.AppCode.ErrorLogging.clsErrorLogging.LogError(ex.Message, "AddTicketDetails.aspx.cs", "SaveData()");
                lblError.Text = "Failed";
            }
        }


        //Load LoadTIcketTypeDetails dropdown
        private void LoadIncidentChangeRequest()
        {
            try
            {
                DataTable dt = clsTicketInformation.LoadIncidentChangeRequestData();
                ddlIncidentChangeRequest.DataSource = dt;
                ddlIncidentChangeRequest.DataTextField = "tctpTicketType";
                ddlIncidentChangeRequest.DataValueField = "tctpId";
                ddlIncidentChangeRequest.DataBind();
                ddlIncidentChangeRequest.Items.Insert(0, new ListItem("Select Incident Type", ""));
            }

            catch (Exception ex)
            {
                PMAssistReleaseVersion.AppCode.ErrorLogging.clsErrorLogging.LogError(ex.Message, "AddTicketDetails.aspx.cs", "LoadIncidentChangeRequest()");
                lblError.Text = "Failed";
            }
        }

        //Load LoadCOType dropdown
        private void LoadCOType()
        {
            try
            {
                DataTable dt = clsTicketInformation.LoadCOType();
                ddlCoType.DataSource = dt;
                ddlCoType.DataTextField = "CotpChangeOrderType";
                ddlCoType.DataValueField = "CotpId";
                ddlCoType.DataBind();
            }
            catch (Exception ex)
            {
                PMAssistReleaseVersion.AppCode.ErrorLogging.clsErrorLogging.LogError(ex.Message, "AddTicketDetails.aspx.cs", "LoadCOType()");
                lblError.Text = "Failed";
            }

        }

        //Load Priority dropdown
        private void LoadpriorityData()
        {
            try
            {
                DataTable dt = clsTicketInformation.LoadPriorityData();
                ddlPriority.DataSource = dt;
                ddlPriority.DataTextField = "PrtyPriority";
                ddlPriority.DataValueField = "PrtyId";
                ddlPriority.DataBind();
                ddlPriority.Items.Insert(0, new ListItem("Select Priority", ""));
            }
            catch (Exception ex)
            {
                PMAssistReleaseVersion.AppCode.ErrorLogging.clsErrorLogging.LogError(ex.Message, "AddTicketDetails.aspx.cs", "LoadpriorityData()");
                lblError.Text = "Failed";
            }

        }

        //Load ModuleName dropdown
        private void LoadModuleName()
        { 
            try {
            DataTable dt = clsTicketInformation.LoadModuleName();
            ddlModuleName.DataSource = dt;
            ddlModuleName.DataTextField = "ModlName";
            ddlModuleName.DataValueField = "ModlId";
            ddlModuleName.DataBind();
            ddlModuleName.Items.Insert(0, new ListItem("Select Module", ""));
        }
            catch (Exception ex)
            {
                PMAssistReleaseVersion.AppCode.ErrorLogging.clsErrorLogging.LogError(ex.Message, "AddTicketDetails.aspx.cs", "LoadModuleName()");
                lblError.Text = "Failed";
            }

        }

        //Load Incident Category dropdown
        private void LoadIncidentCategory()
        {
            try
            {
                DataTable dt = clsTicketInformation.LoadIncidentCategory();
                ddlIncidentCategory.DataSource = dt;
                ddlIncidentCategory.DataTextField = "InctIncidentCategory";
                ddlIncidentCategory.DataValueField = "InctId";
                ddlIncidentCategory.DataBind();
                ddlIncidentCategory.Items.Insert(0, new ListItem("Select Incident Category", ""));
            }
            catch (Exception ex)
            {
                PMAssistReleaseVersion.AppCode.ErrorLogging.clsErrorLogging.LogError(ex.Message, "AddTicketDetails.aspx.cs", "LoadIncidentCategory()");
                lblError.Text = "Failed";
            }

        }


        //Load Status of Ticket dropdown
        private void LoadStatusofTicket()
        {
            try
            {
                DataTable dt = clsTicketInformation.LoadStatusofTicket();
                ddlStatusofTicket.DataSource = dt;
                ddlStatusofTicket.DataTextField = "TcstTicketStatus";
                ddlStatusofTicket.DataValueField = "TcstId";
                ddlStatusofTicket.DataBind();
                ddlStatusofTicket.Items.Insert(0, new ListItem("Select Ticket Status", ""));
            }
            catch (Exception ex)
            {
                PMAssistReleaseVersion.AppCode.ErrorLogging.clsErrorLogging.LogError(ex.Message, "AddTicketDetails.aspx.cs", "LoadStatusofTicket()");
                lblError.Text = "Failed";
            }

        }

        //Load AssignedTo dropdown
        private void LoadAssignedTo()
        {
            try
            {
                DataTable dt = clsTicketInformation.LoadAssignedTo();
                ddlAssignedTo.DataSource = dt;
                ddlAssignedTo.DataTextField = "UnsmFirstName";
                ddlAssignedTo.DataValueField = "UnsmPortalId";
                ddlAssignedTo.DataBind();
                ddlAssignedTo.Items.Insert(0, new ListItem("Select Asignee", ""));
            }

            catch (Exception ex)
            {
                PMAssistReleaseVersion.AppCode.ErrorLogging.clsErrorLogging.LogError(ex.Message, "AddTicketDetails.aspx.cs", "LoadAssignedTo()");
                lblError.Text = "Failed";
            }

        }

        //Load Ticket Type
        private void LoadTicketType()
        {
            try
            {
                DataTable dt = clsTicketInformation.LoadTicketType();
                ddlTicketType.DataSource = dt;
                ddlTicketType.DataTextField = "TctdTicketTypeInDetails";
                ddlTicketType.DataValueField = "TctdId";
                ddlTicketType.DataBind();
                ddlTicketType.Items.Insert(0, new ListItem("Select Ticket Type", ""));
            }

            catch (Exception ex)
            {
                PMAssistReleaseVersion.AppCode.ErrorLogging.clsErrorLogging.LogError(ex.Message, "AddTicketDetails.aspx.cs", "LoadTicketType()");
                lblError.Text = "Failed";
            }
        }

        //Load Complexity
        private void LoadComplexity()
        {
            try
            {
                DataTable dt = clsTicketInformation.LoadComplexity();
                ddlComplexity.DataSource = dt;
                ddlComplexity.DataTextField = "CplxComplexity";
                ddlComplexity.DataValueField = "CplxId";
                ddlComplexity.DataBind();
                ddlComplexity.Items.Insert(0, new ListItem("Select Complexity", ""));
            }
            catch (Exception ex)
            {
                PMAssistReleaseVersion.AppCode.ErrorLogging.clsErrorLogging.LogError(ex.Message, "AddTicketDetails.aspx.cs", "LoadComplexity()");
                lblError.Text = "Failed";
            }

        }

        //Load Origin/Reason of Ticket
        private void LoadOriginOfDefect()
        {
            try
            {
                DataTable dt = clsTicketInformation.LoadOriginOfDefect();
                ddlOriginOfDefect.DataSource = dt;
                ddlOriginOfDefect.DataTextField = "OrgnOriginOfDefect";
                ddlOriginOfDefect.DataValueField = "OrgnId";
                ddlOriginOfDefect.DataBind();
            }
            catch (Exception ex)
            {
                PMAssistReleaseVersion.AppCode.ErrorLogging.clsErrorLogging.LogError(ex.Message, "AddTicketDetails.aspx.cs", "LoadOriginOfDefect()");
                lblError.Text = "Failed";
            }

        }

        //Load PeerReview dropdown
        private void LoadPeerReviewer()
        {
            try
            {
                DataTable dt = clsTicketInformation.LoadAssignedTo();
                ddlReviewedby.DataSource = dt;
                ddlReviewedby.DataTextField = "UnsmFirstName";
                ddlReviewedby.DataValueField = "UnsmPortalId";
                ddlReviewedby.DataBind();
                ddlReviewedby.Items.Insert(0, new ListItem("Select Peer Reviewer", ""));
            }
            catch (Exception ex)
            {
                PMAssistReleaseVersion.AppCode.ErrorLogging.clsErrorLogging.LogError(ex.Message, "AddTicketDetails.aspx.cs", "LoadPeerReviewer()");
                lblError.Text = "Failed";
            }

        }

       public void LoadControls()
        {
            try
            {
                LoadIncidentChangeRequest();
                LoadCOType();
                LoadpriorityData();
                LoadModuleName();
                LoadIncidentCategory();
                LoadStatusofTicket();
                LoadOriginOfDefect();
                LoadAssignedTo();
                LoadTicketType();
                LoadComplexity();
                LoadPeerReviewer();
            }
            catch (Exception ex)
            {
                PMAssistReleaseVersion.AppCode.ErrorLogging.clsErrorLogging.LogError(ex.Message, "AddTicketDetails.aspx.cs", "LoadControls()");
                lblError.Text = "Failed";
            }
        }

        protected void ddlTicketType_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                DropDownList ticketType = (DropDownList)sender;
                if (ticketType.SelectedItem.Text.ToUpper().Contains("CHANGE"))
                {
                    txtCoNumber.Enabled = true;
                    ddlCoType.Enabled = true;
                    reqCoTypeRequired.Enabled = true;
                    reqCoNumberRequired.Enabled = true;
                }
                else
                {
                    txtCoNumber.Enabled = false;
                    reqCoTypeRequired.Enabled = false;
                    ddlCoType.Enabled = false;

                    txtCoNumber.Text = string.Empty;
                    ddlCoType.SelectedIndex = 0;
                    reqCoNumberRequired.Enabled = false;
                }
                Page.Validate();
            }

            catch (Exception ex)
            {
                PMAssistReleaseVersion.AppCode.ErrorLogging.clsErrorLogging.LogError(ex.Message, "AddTicketDetails.aspx.cs", "ddlTicketType_SelectedIndexChanged()");
                lblError.Text = "Failed";
            }
        }

        void GetKpi()
        {
            try
            {
                if (ddlPriority.SelectedValue == string.Empty || txtAssignedDate.Text == string.Empty || txtAssignedTime.Text == string.Empty)
                    lblKPICalculated.Text = string.Empty;
                else
                {
                    DateTime assignedDateTime = DateTime.ParseExact(txtAssignedDate.Text + " " + txtAssignedTime.Text, "dd-MMM-yyyy HH:mm", CultureInfo.InvariantCulture);
                    lblKPICalculated.Text = clsTicketInformation.GetKPIByAsnDatePrty(assignedDateTime.ToString("yyyyMMdd HH:mm"), ddlPriority.SelectedItem.Text);
                }
                Page.Validate();
            }
            catch (Exception ex)
            {
                PMAssistReleaseVersion.AppCode.ErrorLogging.clsErrorLogging.LogError(ex.Message, "AddTicketDetails.aspx.cs", "GetKpi()");
                lblError.Text = "Failed";
            }

        }

        protected void txtAssignedDate_TextChanged(object sender, EventArgs e)
        {
            try
            {
                GetKpi();
            }

            catch (Exception ex)
            {
                PMAssistReleaseVersion.AppCode.ErrorLogging.clsErrorLogging.LogError(ex.Message, "AddTicketDetails.aspx.cs", "txtAssignedDate_TextChanged()");
                lblError.Text = "Failed";
            }
        }

        protected void txtAssignedTime_TextChanged(object sender, EventArgs e)
        {
            try
            {
                GetKpi();
            }
            catch (Exception ex)
            {
                PMAssistReleaseVersion.AppCode.ErrorLogging.clsErrorLogging.LogError(ex.Message, "AddTicketDetails.aspx.cs", "txtAssignedTime_TextChanged()");
                lblError.Text = "Failed";
            }
        }

        protected void ddlPriority_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                GetKpi();
            }
            catch (Exception ex)
            {
                PMAssistReleaseVersion.AppCode.ErrorLogging.clsErrorLogging.LogError(ex.Message, "AddTicketDetails.aspx.cs", "ddlPriority_SelectedIndexChanged()");
                lblError.Text = "Failed";
            }
        }

        protected void btnEdit_Click(object sender, EventArgs e)
        {
            try
            {
                Response.Redirect("~/UI/Resource/AddTicketDetails.aspx?EditTicketReference=" + txtReferenceNumber.Text, false);
            }

            catch (Exception ex)
            {
                PMAssistReleaseVersion.AppCode.ErrorLogging.clsErrorLogging.LogError(ex.Message, "AddTicketDetails.aspx.cs", "btnEdit_Click()");
                lblError.Text = "Failed";
            }
        }

    }

}





