﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.IO;
using System.Text;
using System.Configuration;

namespace PMAssistReleaseVersion.AppCode.ErrorLogging
{
    public class clsErrorLogging
    {
        public static void LogError(string Message, string FileName, string MethodName)
        {
            try
            {

                string sLogFormat;
                string PathName;
                string ErrorFileName;
                PathName = ConfigurationManager.AppSettings["ErrorLogPath"];
                sLogFormat = DateTime.Now.ToLongTimeString().ToString() + " ";

                string sYear = DateTime.Now.Year.ToString();
                string sMonth = DateTime.Now.Month.ToString();
                string sDay = DateTime.Now.Day.ToString();
                ErrorFileName = sYear + "_" + sMonth + "_" + sDay + ".txt";

                StreamWriter sw = new StreamWriter(PathName + ErrorFileName, true);
                sw.WriteLine(sLogFormat + "FileName: " + FileName + " MethodName: " + MethodName + Message);
                sw.Flush();
                sw.Close();
            }
            catch (Exception ex)
            {
                
            }
        }
    
    
    }
    }