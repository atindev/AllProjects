﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace PMAssistReleaseVersion
{
    public partial class Resource : System.Web.UI.MasterPage
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            try
            {
                if (Session["intUnsmPortalId"] == null)
                {
                    Response.Redirect("~/UI/Login.aspx", true);
                }
                else
                {
                    lblLogin.Text = "Loggedin as " + Session["intUnsmPortalId"].ToString();
                }
            }

            catch (Exception ex)
            {
                PMAssistReleaseVersion.AppCode.ErrorLogging.clsErrorLogging.LogError(ex.Message, "Resource.Master.cs", "Page_Load()");
            }
        }

        protected void lnkResourceSignOut_Click(object sender, EventArgs e)
        {
            try
            {
                if (Session["intUnsmPortalId"] != null)
                {
                    Session.Clear();
                    Response.Redirect("~/UI/Logout.aspx", true);
                }
            }

            catch (Exception ex)
            {
                PMAssistReleaseVersion.AppCode.ErrorLogging.clsErrorLogging.LogError(ex.Message, "Resource.Master.cs", "lnkResourceSignOut_Click()");
            }

        }
        protected void btnOkMaster_Click(object sender, EventArgs e)
        {
            try
            {
                if (this.ContentPlaceHolderMaster.Page.AppRelativeVirtualPath.Contains("AddTicketDetails"))
                {
                    TextBox txtPortalIdAddTicketContentPlaceHolder = (TextBox)this.ContentPlaceHolderMaster.FindControl("txtReferenceNumber");
                    Response.Redirect("~/UI/Resource/AddTicketDetails.aspx?ViewTicketReference=" + txtPortalIdAddTicketContentPlaceHolder.Text, false);
                }
                if (this.ContentPlaceHolderMaster.Page.AppRelativeVirtualPath.Contains("AddTaskDetails"))
                {
                    Label lblPortalIdAddTicketContentPlaceHolder = (Label)this.ContentPlaceHolderMaster.FindControl("lblNewTaskReference");
                    Response.Redirect("~/UI/Resource/AddTaskDetails.aspx?ViewTaskReference=" + lblPortalIdAddTicketContentPlaceHolder.Text, false);
                }
            }

            catch (Exception ex)
            {
                PMAssistReleaseVersion.AppCode.ErrorLogging.clsErrorLogging.LogError(ex.Message, "Resource.Master.cs", "btnOkMaster_Click()");
            }

        }

        protected void lnkAddEditTickets_Click(object sender, EventArgs e)
        {
            try
            {
                Response.Redirect("~/UI/Resource/AddTicketDetails.aspx", true);
            }
            catch (Exception ex)
            {
                PMAssistReleaseVersion.AppCode.ErrorLogging.clsErrorLogging.LogError(ex.Message, "Resource.Master.cs", "lnkAddEditTickets_Click()");
            }

        }

        protected void lnkSearchTickets_Click(object sender, EventArgs e)
        {
            try
            {
                Response.Redirect("~/UI/Resource/SearchTickets.aspx", true);
            }

            catch (Exception ex)
            {
                PMAssistReleaseVersion.AppCode.ErrorLogging.clsErrorLogging.LogError(ex.Message, "Resource.Master.cs", "lnkSearchTickets_Click()");
            }

        }

        protected void lnkResetPassword_Click(object sender, EventArgs e)
        {
            try
            {
                Response.Redirect("~/UI/ResetPassword.aspx", true);
            }
            catch (Exception ex)
            {
                PMAssistReleaseVersion.AppCode.ErrorLogging.clsErrorLogging.LogError(ex.Message, "Resource.Master.cs", "lnkResetPassword_Click()");
            }

        }

        protected void lnkRaiseHelpAlarm_Click(object sender, EventArgs e)
        {
            try
            {
                Response.Redirect("~/UI/Resource/HelpAlarm.aspx", true);
            }
            catch (Exception ex)
            {
                PMAssistReleaseVersion.AppCode.ErrorLogging.clsErrorLogging.LogError(ex.Message, "Resource.Master.cs", "lnkRaiseHelpAlarm_Click()");
            }

        }

        protected void lnkAddEditTasks_Click(object sender, EventArgs e)
        {
            try
            {
                Response.Redirect("~/UI/Resource/AddTaskDetails.aspx", true);
            }

            catch (Exception ex)
            {
                PMAssistReleaseVersion.AppCode.ErrorLogging.clsErrorLogging.LogError(ex.Message, "Resource.Master.cs", "lnkAddEditTasks_Click()");
            }

        }

        protected void lnkSearchEfforts_Click(object sender, EventArgs e)
        {
            try
            {
                Response.Redirect("~/UI/Resource/SearchTasks.aspx", true);
            }
            catch (Exception ex)
            {
                PMAssistReleaseVersion.AppCode.ErrorLogging.clsErrorLogging.LogError(ex.Message, "Resource.Master.cs", "lnkSearchEfforts_Click()");
            }
        }

        protected void lnkSLACalculator_Click(object sender, EventArgs e)
        {
            try
            {
                Response.Redirect("~/UI/Resource/SlaCalculator.aspx", true);
            }

            catch (Exception ex)
            {
                PMAssistReleaseVersion.AppCode.ErrorLogging.clsErrorLogging.LogError(ex.Message, "Resource.Master.cs", "lnkSLACalculator_Click()");
            }
        }
    }
}
