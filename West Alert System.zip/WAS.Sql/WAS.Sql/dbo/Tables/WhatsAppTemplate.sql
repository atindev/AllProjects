﻿CREATE TABLE [dbo].[WhatsAppTemplate]
(
	[Id] UNIQUEIDENTIFIER NOT NULL PRIMARY KEY, 
    [TemplateName] NCHAR(10) NULL
)
