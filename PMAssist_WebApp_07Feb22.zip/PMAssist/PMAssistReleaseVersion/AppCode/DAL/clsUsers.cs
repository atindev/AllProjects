﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using Microsoft.ApplicationBlocks.Data;
using System.Data;
using System.Data.SqlClient;
using System.Collections;

namespace PMAssistReleaseVersion.AppCode.Generic
{
    public class clsUsers
    {
        public static string PortalId;
        // To Add User details into database 
        public static void AddUserDetails(string UnsmPortalId, string UnsmEmployeeId, string UnsmEmail, string UnsmFirstName, string UnsmLastName, string UnsmProjectAccount,
                                          string UnsmAccountJoiningdate, string UnsmAccountLeavingDate, int UnsmGrade, int UnsmPractice,int UnsmLocation, int UnsmTeam, string UnsmIsManager, string UnsmCurrent, string UnsmEntryId)
        {
            try
            {

                SqlParameter[] par = new SqlParameter[15];
                par[0] = new SqlParameter("@intUnsmPortalId", UnsmPortalId);
                par[1] = new SqlParameter("@vchUnsmEmployeeId", UnsmEmployeeId);
                par[2] = new SqlParameter("@vchUnsmEmail", UnsmEmail);
                //par[2] = new SqlParameter("@vchUnsmPassword", System.Text.Encoding.ASCII.GetBytes(UnsmPassword));
                par[3] = new SqlParameter("@vchUnsmFirstName", UnsmFirstName);
                par[4] = new SqlParameter("@vchUnsmLastName", UnsmLastName);
                par[5] = new SqlParameter("@vchUnsmProjectAccount", UnsmProjectAccount);
                par[6] = new SqlParameter("@vchUnsmAccountJoiningDate", UnsmAccountJoiningdate);
                par[7] = new SqlParameter("@vchUnsmAccountLeavingDate", UnsmAccountLeavingDate);
                par[8] = new SqlParameter("@intUnsmGrade", UnsmGrade);
                par[9] = new SqlParameter("@intUnsmPractice", UnsmPractice);
                par[10] = new SqlParameter("@intUnsmLocation", UnsmLocation);
                par[11] = new SqlParameter("@sintTeam", UnsmTeam);
                par[12] = new SqlParameter("@chUnsmIsManager", UnsmIsManager);
                par[13] = new SqlParameter("@vchUnsmCurrent", UnsmCurrent);
                par[14] = new SqlParameter("@vchUnsmEntryId", UnsmEntryId);

                SqlHelper.ExecuteNonQuery(clsGeneral.ConStr, CommandType.StoredProcedure, "spAddUserDetails", par);
            }

            catch (Exception ex)
            {
                PMAssistReleaseVersion.AppCode.ErrorLogging.clsErrorLogging.LogError(ex.Message, "clsUsers.cs", "AddUserDetails");
                throw;

            }

        }

        // To Update Ticket details in to database
        public static DataSet UpdateUserDetailsByPortalId(int UserId, string UnsmPortalId, string UnsmEmployeeId, string UnsmEmail, string UnsmFirstName, string UnsmLastName, string UnsmProjectAccount,
                                          string UnsmAccountJoiningdate, string UnsmAccountLeavingDate, int UnsmGrade, int UnsmPractice,int UnsmLocation, int UnsmTeam, string UnsmIsManager, string UnsmCurrent, string UnsmLastChangedId)
        {
            try
            {
                SqlParameter[] par = new SqlParameter[16];
                par[0] = new SqlParameter("@intUnsmId", UserId);
                par[1] = new SqlParameter("@intUnsmPortalId", UnsmPortalId);
                par[2] = new SqlParameter("@vchUnsmEmployeeId", UnsmEmployeeId);
                par[3] = new SqlParameter("@vchUnsmEmail", UnsmEmail);
                par[4] = new SqlParameter("@vchUnsmFirstName", UnsmFirstName);
                par[5] = new SqlParameter("@vchUnsmLastName", UnsmLastName);
                par[6] = new SqlParameter("@vchUnsmProjectAccount", UnsmProjectAccount);
                par[7] = new SqlParameter("@vchUnsmAccountJoiningDate", UnsmAccountJoiningdate);
                par[8] = new SqlParameter("@vchUnsmAccountLeavingDate", UnsmAccountLeavingDate);
                par[9] = new SqlParameter("@intUnsmGrade", UnsmGrade);
                par[10] = new SqlParameter("@intUnsmPractice", UnsmPractice);
                par[11] = new SqlParameter("@intUnsmLocation", UnsmLocation);
                par[12] = new SqlParameter("@sintTeam", UnsmTeam);
                par[13] = new SqlParameter("@chUnsmIsManager", UnsmIsManager);
                par[14] = new SqlParameter("@vchUnsmCurrent", UnsmCurrent);
                par[15] = new SqlParameter("@vchUnsmLastChangedId", UnsmLastChangedId);
                return SqlHelper.ExecuteDataset(clsGeneral.ConStr, "spUpdateUserDetailsByPortalId", par);
            }
            catch (Exception ex)
            {
                PMAssistReleaseVersion.AppCode.ErrorLogging.clsErrorLogging.LogError(ex.Message, "clsUsers.cs", "UpdateUserDetailsById");
                throw;
            }
        }
        //Load ProjectDetails data
        public static DataTable LoadProjectDetailsData()
        {
            DataSet ds = SqlHelper.ExecuteDataset(clsGeneral.ConStr, "spGetProjectAccountDetails");
            return ds.Tables[0];
        }

        //Load User List
        public static DataTable LoadPortalID()
        {
            DataSet ds = SqlHelper.ExecuteDataset(clsGeneral.ConStr, "spGetPortalID");
            return ds.Tables[0];
        }

        //Load Grade
        public static DataTable LoadGrade()
        {
            DataSet ds = SqlHelper.ExecuteDataset(clsGeneral.ConStr, "spGetGradeDetails");
            return ds.Tables[0];
        }
        //Load Team Data
        public static DataTable LoadTeam()
        {
            DataSet ds = SqlHelper.ExecuteDataset(clsGeneral.ConStr, "spGetTeamDetails");
            return ds.Tables[0];
        }

        //Load Location Data
        public static DataTable LoadLocation()
        {
            DataSet ds = SqlHelper.ExecuteDataset(clsGeneral.ConStr, "spGetLocationDetails");
            return ds.Tables[0];
        }

        //Load Practice Data
        public static DataTable LoadPractice()
        {
            DataSet ds = SqlHelper.ExecuteDataset(clsGeneral.ConStr, "spGetPracticeDetails");
            return ds.Tables[0];
        }

        //Check whether the User exist or not 
        public static DataSet CheckUserExists(string PortalId)
        {
            try
            {
                SqlParameter[] par = new SqlParameter[1];
                par[0] = new SqlParameter("@PortalId", PortalId);

                return SqlHelper.ExecuteDataset(clsGeneral.ConStr, "spCheckUserExists", par);

            }
            catch (Exception ex)
            {
                PMAssistReleaseVersion.AppCode.ErrorLogging.clsErrorLogging.LogError(ex.Message, "clsUsers.cs", "CheckUserExists");
                throw;
            }

        }

        // To load user details to Users Page
        public static clsUserDetails LoadUserDetailsByPortalId(string portalId)
        {
            SqlCommand cmd = new SqlCommand();
            cmd.CommandText = "spGetUserDetailsByPortalId";
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@intPortalId", portalId);
            DataSet dsUserDetails = SqlHelper.ExecuteDataset(clsGeneral.ConStr, cmd.CommandType, cmd.CommandText, cmd);
            var UserDetails = new clsUserDetails();
            if (dsUserDetails != null && dsUserDetails.Tables.Count > 0 && dsUserDetails.Tables[0].Rows.Count > 0)
            {
                UserDetails.UserId = Convert.ToInt32(dsUserDetails.Tables[0].Rows[0]["UnsmId"].ToString());
                UserDetails.UserPortalId = dsUserDetails.Tables[0].Rows[0]["UnsmPortalId"].ToString();
                UserDetails.UserEmail = dsUserDetails.Tables[0].Rows[0]["UnsmEmail"].ToString();
                //UserDetails.UserPassword = (byte[])dsUserDetails.Tables[0].Rows[0]["UnsmPassword"];
                UserDetails.UserFirstName = dsUserDetails.Tables[0].Rows[0]["UnsmFirstName"].ToString();
                UserDetails.UserLastName = dsUserDetails.Tables[0].Rows[0]["UnsmLastName"].ToString();
                UserDetails.UserProjectAccount = dsUserDetails.Tables[0].Rows[0]["UnsmProjectAccount"].ToString();
                UserDetails.UserGrade = Convert.ToInt32(dsUserDetails.Tables[0].Rows[0]["UnsmGrdeId"].ToString());
                UserDetails.UserIsManager = dsUserDetails.Tables[0].Rows[0]["UnsmIsManager"].ToString();
                UserDetails.UserCurrent = dsUserDetails.Tables[0].Rows[0]["UnsmCurrent"].ToString();
                UserDetails.UserEntryId = Convert.ToInt32(dsUserDetails.Tables[0].Rows[0]["UnsmEntryId"].ToString());
                UserDetails.UserEntryDate = dsUserDetails.Tables[0].Rows[0]["UnsmEntrydate"].ToString();
                UserDetails.UserTeam = Convert.ToInt32(dsUserDetails.Tables[0].Rows[0]["UnsmTeam"].ToString());
                UserDetails.UserAccountJoiningDate = dsUserDetails.Tables[0].Rows[0]["UnsmAccountJoiningDate"].ToString();
                UserDetails.UserAccountLeavingDate = dsUserDetails.Tables[0].Rows[0]["UnsmAccountLeavingDate"].ToString();
                UserDetails.UserLocation = Convert.ToInt32(dsUserDetails.Tables[0].Rows[0]["UnsmLocaId"].ToString());
                UserDetails.UserEmployeeId = dsUserDetails.Tables[0].Rows[0]["UnsmEmployeeId"].ToString();
                UserDetails.UserPractice = Convert.ToInt32(dsUserDetails.Tables[0].Rows[0]["UnsmPrtcId"].ToString());
            }
            return UserDetails;
        }

        //Load ScqsSecurityQuestion data
        public static DataTable LoadSecurityQuestionData()
        {
            DataSet ds = SqlHelper.ExecuteDataset(clsGeneral.ConStr, "spGetSecurityQuestions");
            return ds.Tables[0];
        }

        //To Reset password
        public static DataSet ResetUserPassword(string UnsmPortalId, string ScqsSecurityQuestion, byte[] UnsmScqsSecurityAnswer, byte[] OldUnsmPassword, byte[] NewUnsmPassword)
        {
            try
            {
                SqlParameter[] par = new SqlParameter[5];
                par[0] = new SqlParameter("@intUnsmPortalId", UnsmPortalId);
                par[1] = new SqlParameter("@intScqsSecurityQuestion", ScqsSecurityQuestion);
                par[2] = new SqlParameter("@vchUnsmScqsSecurityAnswer", UnsmScqsSecurityAnswer);
                par[3] = new SqlParameter("@vchbnryOldUnsmPassword", OldUnsmPassword);
                par[4] = new SqlParameter("@vchbnryNewUnsmPassword", NewUnsmPassword);

                return SqlHelper.ExecuteDataset(clsGeneral.ConStr, "spResetPassword", par);
            }
            catch (Exception ex)
            {
                PMAssistReleaseVersion.AppCode.ErrorLogging.clsErrorLogging.LogError(ex.Message, "clsUsers.cs", "ResetPassword");
                throw;
            }
        }

        //To verify User Security Rules
        public static string VerifyUserSecurityRules(string UnsmPortalId, string ScqsSecurityQuestion, string UnsmScqsSecurityAnswer, string IsVerifiedUser)
        {
            try
            {
                //SqlConnection con = new SqlConnection(clsGeneral.ConStr);
                SqlCommand cmd = new SqlCommand();
                cmd.Connection = new SqlConnection(clsGeneral.ConStr);
                cmd.CommandText = "dbo.spVerifyUserSecurityRules";
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@intUnsmPortalId", UnsmPortalId);
                cmd.Parameters.AddWithValue("@vchScqsID", ScqsSecurityQuestion);
                cmd.Parameters.AddWithValue("@vchUnsmScqsSecurityAnswer", System.Text.Encoding.ASCII.GetBytes(UnsmScqsSecurityAnswer));
                //System.Text.Encoding.ASCII.GetString(); //Decoding
                cmd.Parameters.Add("@chIsVerifiedUser", SqlDbType.Char);
                cmd.Parameters["@chIsVerifiedUser"].Direction = ParameterDirection.Output;
                cmd.Parameters["@chIsVerifiedUser"].Size = 1;
                cmd.Connection.Open();
                cmd.ExecuteNonQuery();
                cmd.Connection.Close();
                var str = cmd.Parameters["@chIsVerifiedUser"].Value.ToString();
                return str;
                //cmd.Parameters.AddWithValue("@chIsVerifiedUser", IsVerifiedUser);
                //SqlParameter[] par = new SqlParameter[4];
                //par[0] = new SqlParameter("@intUnsmPortalId", UnsmPortalId);
                //par[1] = new SqlParameter("@vchScqsSecurityQuestion", ScqsSecurityQuestion);
                //par[2] = new SqlParameter("@vchUnsmScqsSecurityAnswer", System.Text.Encoding.ASCII.GetBytes(UnsmScqsSecurityAnswer));
                //par[3] = new SqlParameter("@chIsVerifiedUser", IsVerifiedUser);
                //par[3].Direction = ParameterDirection.Output;

                //string IsVerifiedUser = parm[3].Value.ToString();

                //SqlHelper.ExecuteDataset(clsGeneral.ConStr, "spVerifyUserSecurityRules", par);
                //return par[3].Value.ToString();
            }
            catch (Exception ex)
            {
                PMAssistReleaseVersion.AppCode.ErrorLogging.clsErrorLogging.LogError(ex.Message, "clsUsers.cs", "VerifyUserSecurityRules");
                throw;
            }
        }

        //For forgot passowrd
        public static void UpdatePassword(string IsVerifiedUser, string UnsmPortalId, byte[] ConfirmPassword)
        {
            try
            {
                SqlParameter[] par = new SqlParameter[3];
                par[0] = new SqlParameter("@chIsVerifiedUser", IsVerifiedUser);
                par[1] = new SqlParameter("@intUnsmPortalId", UnsmPortalId);
                par[2] = new SqlParameter("@vchbnryNewUnsmPassword", ConfirmPassword);
                //par[4] = new SqlParameter("@vchbnryNewUnsmPassword", SessionID);

                SqlHelper.ExecuteDataset(clsGeneral.ConStr, "spUpdatePassword", par);

            }
            catch (Exception ex)
            {
                PMAssistReleaseVersion.AppCode.ErrorLogging.clsErrorLogging.LogError(ex.Message, "clsUsers.cs", "UpdatePassword");
                throw;
            }
        }

        //To check if first time login or not
        public static string IsFirstLogin(string UnsmPortalId, string IsFirstLogin)
        {
            try
            {

                //SqlParameter[] par = new SqlParameter[2];
                //par[0] = new SqlParameter("@intUnsmPortalId", UnsmPortalId);
                //par[1] = new SqlParameter("@chIsFirstLogin", IsFirstLogin);
                //par[1].Direction = ParameterDirection.Output;

                //SqlHelper.ExecuteDataset(clsGeneral.ConStr, "spIsFirstLogin", par);
                //return IsFirstLogin;
                SqlCommand cmd = new SqlCommand();
                cmd.Connection = new SqlConnection(clsGeneral.ConStr);
                cmd.CommandText = "dbo.spIsFirstLogin";
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@intUnsmPortalId", UnsmPortalId);
                //cmd.Parameters.AddWithValue("@chIsFirstLogin", IsFirstLogin);
                //cmd.Parameters.AddWithValue("@vchUnsmScqsSecurityAnswer", System.Text.Encoding.ASCII.GetBytes(UnsmScqsSecurityAnswer));
                //System.Text.Encoding.ASCII.GetString(); //Decoding
                cmd.Parameters.Add("@chIsFirstLogin", SqlDbType.Char);
                cmd.Parameters["@chIsFirstLogin"].Direction = ParameterDirection.Output;
                cmd.Parameters["@chIsFirstLogin"].Size = 1;
                cmd.Connection.Open();
                cmd.ExecuteNonQuery();
                cmd.Connection.Close();
                var str = cmd.Parameters["@chIsFirstLogin"].Value.ToString();
                return str;

            }
            catch (Exception ex)
            {
                PMAssistReleaseVersion.AppCode.ErrorLogging.clsErrorLogging.LogError(ex.Message, "clsUsers.cs", "IsFirstLogin");
                throw;
            }
        }

        // To get user security detaisl
        public static DataSet GetUserSecurityDetails(string PortalID)
        {
            try
            {
                SqlParameter[] par = new SqlParameter[1];
                par[0] = new SqlParameter("@intUnsmPortalId", PortalID);
                return SqlHelper.ExecuteDataset(clsGeneral.ConStr, "spGetUserSecurityDetails", par);
            }
            catch (Exception ex)
            {
                PMAssistReleaseVersion.AppCode.ErrorLogging.clsErrorLogging.LogError(ex.Message, "clsUsers.cs", "GetUserSecurityDetails");
                throw;
            }
        }
    }
}

    