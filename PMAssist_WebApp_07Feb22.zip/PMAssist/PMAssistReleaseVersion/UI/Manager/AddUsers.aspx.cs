﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using Microsoft.ApplicationBlocks.Data;
using System.Data;
using System.Data.SqlClient;
using System.Text;
using PMAssistReleaseVersion.AppCode.Generic;
using AjaxControlToolkit;


namespace PMAssistReleaseVersion.UI.Manager
{
    public partial class AddUsers : System.Web.UI.Page
    {
        string PortalId;
        string AccountJoiningDate;
        string AccountLeavingDate;

        protected void Page_PreInit(object sender, EventArgs e)
        {
            try
            {
                if (Session["LoginType"] != null)
                {
                    clsGeneral.SetMasterPage(this.Page);
                }
            }

            catch (Exception ex)
            {
                PMAssistReleaseVersion.AppCode.ErrorLogging.clsErrorLogging.LogError(ex.Message, "AddUsers.aspx.cs", "Page_PreInit()");
                lblError.Text = "Failed";
            }
        }
        protected void Page_Load(object sender, EventArgs e)
        {
            try
            {
                if (!IsPostBack)
                {
                    LoadControls();
                    if (Request.QueryString["EditUserDetails"] != null)
                    {
                        var UserDetails = clsUsers.LoadUserDetailsByPortalId(Request.QueryString["EditUserDetails"].ToString());
                        ViewUserDetails(UserDetails);
                        CustomizeEditPageControls();
                    }
                    else if (Request.QueryString["ViewUserDetails"] != null)
                    {
                        var UserDetails = clsUsers.LoadUserDetailsByPortalId(Request.QueryString["ViewUserDetails"].ToString());
                        ViewUserDetails(UserDetails);
                        CustomizeViewPageControls();
                    }
                }

                Page.Validate();
            }

            catch (Exception ex)
            {
                PMAssistReleaseVersion.AppCode.ErrorLogging.clsErrorLogging.LogError(ex.Message, "AddUsers.aspx.cs", "Page_Load()");
                lblError.Text = "Failed";
            }
        }

        public void ViewUserDetails(clsUserDetails UserDetails)
        {
            try
            {
                ViewState["UserId"] = UserDetails.UserId;
                txtPortalId.Text = UserDetails.UserPortalId.ToString();
                txtEmployeeId.Text = UserDetails.UserEmployeeId;
                txtEmailId.Text = UserDetails.UserEmail;
                txtFirstName.Text = UserDetails.UserFirstName;
                txtLastName.Text = UserDetails.UserLastName;
                txtAccount.Text = UserDetails.UserProjectAccount;
                txtAccountJoiningDate.Text = UserDetails.UserAccountJoiningDate;
                txtAccountLeavingDate.Text = UserDetails.UserAccountLeavingDate;
                ddlGrade.SelectedValue = UserDetails.UserGrade.ToString();
                ddlPractice.SelectedValue = UserDetails.UserPractice.ToString();
                ddlLocation.SelectedValue = UserDetails.UserLocation.ToString();
                ddlTeam.SelectedValue = UserDetails.UserTeam.ToString();
                rdRole.Items.FindByValue(UserDetails.UserIsManager).Selected = true;
                rdActive.Items.FindByValue(UserDetails.UserCurrent).Selected = true;
            }
            catch (Exception ex)
            {
                PMAssistReleaseVersion.AppCode.ErrorLogging.clsErrorLogging.LogError(ex.Message, "AddUsers.aspx.cs", "ViewUserDetails()");
                lblError.Text = "Failed";
            }
        }

        public void CustomizeEditPageControls()
        {
            try
            {
                lblHeading.Text = "Edit User Details";
                btnSubmit.Text = "Update";
                txtPortalId.Enabled = false;
            }

            catch (Exception ex)
            {
                PMAssistReleaseVersion.AppCode.ErrorLogging.clsErrorLogging.LogError(ex.Message, "AddUsers.aspx.cs", "CustomizeEditPageControls()");
                lblError.Text = "Failed";
            }
        }

        public void CustomizeViewPageControls()
        {
            try
            {

                lblHeading.Text = "View User Details";
                lblMandatory.Visible = false;
                btnSubmit.Text = "Edit";
                rdRole.Enabled = false;
                rdActive.Enabled = false;
                ContentPlaceHolder cntPlcHldrMaster = (ContentPlaceHolder)Master.FindControl("ContentPlaceHolderMaster");
                foreach (Control inputControl in cntPlcHldrMaster.Controls)
                {
                    if (inputControl is TextBox)
                    {
                        ((TextBox)inputControl).BackColor = System.Drawing.Color.Transparent;
                        ((TextBox)inputControl).Enabled = false;
                        ((TextBox)inputControl).BorderStyle = BorderStyle.None;
                    }
                    if (inputControl is DropDownList)
                    {
                        ((DropDownList)inputControl).BackColor = System.Drawing.Color.Transparent;
                        ((DropDownList)inputControl).Enabled = false;
                        ((DropDownList)inputControl).BorderStyle = BorderStyle.None;
                    }
                }
            }

            catch (Exception ex)
            {
                PMAssistReleaseVersion.AppCode.ErrorLogging.clsErrorLogging.LogError(ex.Message, "AddUsers.aspx.cs", "CustomizeViewPageControls()");
                lblError.Text = "Failed";
            }
        }

        //To Add AddUserformation
        public void AddUserInformation()
        {
            try
            {
                clsUsers.AddUserDetails(txtPortalId.Text,txtEmployeeId.Text,txtEmailId.Text, txtFirstName.Text, txtLastName.Text, txtAccount.Text, AccountJoiningDate,AccountLeavingDate, Convert.ToInt32(ddlGrade.SelectedValue),Convert.ToInt32(ddlPractice.SelectedValue),Convert.ToInt32(ddlLocation.SelectedValue),Convert.ToInt32(ddlTeam.SelectedValue), rdRole.SelectedValue, rdActive.SelectedValue, Session["intUnsmPortalId"].ToString());
                
                //Master Popup Code
                Label ltrAddUserPopupMessageMasterMessage = (Label)Master.FindControl("lblAddUserManagerPopupMessageMaster");
                ltrAddUserPopupMessageMasterMessage.Text = "New user \"" + txtFirstName.Text + " " + txtLastName.Text + "\" is added successfully into PMAssist";
                ModalPopupExtender hdnAddUserPopup_ModalPopupExtenderMasterPanel = (ModalPopupExtender)Master.FindControl("hdnAddUserManagerPopupMaster_ModalPopupExtender");
                hdnAddUserPopup_ModalPopupExtenderMasterPanel.Show();
            }
            catch (Exception ex)
            {
                PMAssistReleaseVersion.AppCode.ErrorLogging.clsErrorLogging.LogError(ex.Message, "AddUsers.aspx.cs", "AddUserformation()");
                lblError.Text = "Failed";
            }
        }

        // To Update UpdateUserInformation
        public void UpdateUserInformation()
        {
            try
            {
                clsUsers.UpdateUserDetailsByPortalId(Convert.ToInt32(ViewState["UserId"].ToString()), txtPortalId.Text,txtEmployeeId.Text,txtEmailId.Text, txtFirstName.Text, txtLastName.Text, txtAccount.Text, AccountJoiningDate,AccountLeavingDate, Convert.ToInt32(ddlGrade.SelectedValue),Convert.ToInt32(ddlPractice.SelectedValue),Convert.ToInt32(ddlLocation.SelectedValue),Convert.ToInt32(ddlTeam.SelectedValue), rdRole.SelectedValue, rdActive.SelectedValue, Session["intUnsmPortalId"].ToString());
                //Error.Text = " User Information Updated successfully";
                Label ltrAddUserPopupMessageMasterMessage = (Label)Master.FindControl("lblAddUserManagerPopupMessageMaster");
                ltrAddUserPopupMessageMasterMessage.Text = "User \"" + txtFirstName.Text + " " + txtLastName.Text + "\" details has updated successfully into PMAssist";
                ModalPopupExtender hdnAddUserPopup_ModalPopupExtenderMasterPanel = (ModalPopupExtender)Master.FindControl("hdnAddUserManagerPopupMaster_ModalPopupExtender");
                hdnAddUserPopup_ModalPopupExtenderMasterPanel.Show();
            }

            catch (Exception ex)
            {
                PMAssistReleaseVersion.AppCode.ErrorLogging.clsErrorLogging.LogError(ex.Message, "AddUsers.aspx.cs", "UpdateUserInformation()");
                lblError.Text = "Failed to Update";
            }
        }

        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            // To save or update user information in to database
            try
            {
                if (btnSubmit.Text.ToUpper() == "EDIT")
                {
                    Response.Redirect("~/UI/Manager/AddUsers.aspx?EditUserDetails=" + txtPortalId.Text, false);
                }
                else
                {
                    SaveData();
                }

            }
            catch (Exception ex)
            {
                PMAssistReleaseVersion.AppCode.ErrorLogging.clsErrorLogging.LogError(ex.Message, "AddUsers.aspx.cs", "btnSubmit_Click()");
                Response.Redirect("Oops.aspx");
            }

        }

        
        //Load JobTitleDropdown
        private void LoadGrade()
        {
            try
            {
                DataTable dt = clsUsers.LoadGrade();
                ddlGrade.DataSource = dt;
                ddlGrade.DataTextField = "GrdeGrade";
                ddlGrade.DataValueField = "GrdeId";
                ddlGrade.DataBind();
                ddlGrade.Items.Insert(0, new ListItem("Select Grade", ""));
            }
            catch (Exception ex)
            {
                PMAssistReleaseVersion.AppCode.ErrorLogging.clsErrorLogging.LogError(ex.Message, "AddUsers.aspx.cs", "LoadGrade()");
                lblError.Text = "Failed";
            }
        }

        //Load Team Dropdown
        private void LoadTeam()
        {
            try
            {
                DataTable dt = clsUsers.LoadTeam();
                ddlTeam.DataSource = dt;
                ddlTeam.DataTextField = "TeamLevel";
                ddlTeam.DataValueField = "TeamId";
                ddlTeam.DataBind();
            }

            catch (Exception ex)
            {
                PMAssistReleaseVersion.AppCode.ErrorLogging.clsErrorLogging.LogError(ex.Message, "AddUsers.aspx.cs", "LoadTeam()");
                lblError.Text = "Failed";
            }
        }
        //Load Location Dropdown
        private void LoadLoation()
        {
            try
            {
                DataTable dt = clsUsers.LoadLocation();
                ddlLocation.DataSource = dt;
                ddlLocation.DataTextField = "LocaCity";
                ddlLocation.DataValueField = "LocaId";
                ddlLocation.DataBind();
                ddlLocation.Items.Insert(0, new ListItem("Select Location", ""));
            }
            catch (Exception ex)
            {
                PMAssistReleaseVersion.AppCode.ErrorLogging.clsErrorLogging.LogError(ex.Message, "AddUsers.aspx.cs", "LoadLoation()");
                lblError.Text = "Failed";
            }
        }

        //Load Practice Dropdown
        private void LoadPractice()
        {
            try
            {
                DataTable dt = clsUsers.LoadPractice();
                ddlPractice.DataSource = dt;
                ddlPractice.DataTextField = "PrtcPractice";
                ddlPractice.DataValueField = "PrtcId";
                ddlPractice.DataBind();
                ddlPractice.Items.Insert(0, new ListItem("Select Practice", ""));
            }
            catch (Exception ex)
            {
                PMAssistReleaseVersion.AppCode.ErrorLogging.clsErrorLogging.LogError(ex.Message, "AddUsers.aspx.cs", "LoadPractice()");
                lblError.Text = "Failed";
            }
        }

        private void LoadControls()
        {
            try
            {

                LoadGrade();
                LoadTeam();
                LoadLoation();
                LoadPractice();
            }
            catch (Exception ex)
            {
                PMAssistReleaseVersion.AppCode.ErrorLogging.clsErrorLogging.LogError(ex.Message, "AddUsers.aspx.cs", "LoadControls()");
                lblError.Text = "Failed";
            }
        }

        // code to check whether the reference exists or not 
        public void SaveData()
        {
           try{
            PortalId = txtPortalId.Text;
            DataSet dUserExists = clsUsers.CheckUserExists(PortalId);
            DataTable dtUserExists = dUserExists.Tables[0];
            AccountJoiningDate = Request.Form[txtAccountJoiningDate.UniqueID].ToString();
            if (!(AccountJoiningDate == string.Empty))
                AccountJoiningDate = Convert.ToDateTime(Request.Form[txtAccountJoiningDate.UniqueID]).ToString("dd-MMM-yyyy");
            AccountLeavingDate = Request.Form[txtAccountLeavingDate.UniqueID].ToString();
            if (!(AccountLeavingDate == string.Empty))
                AccountLeavingDate = Convert.ToDateTime(Request.Form[txtAccountLeavingDate.UniqueID]).ToString("dd-MMM-yyyy");
            if (dtUserExists.Rows.Count == 0)
            {
                AddUserInformation();
            }
            else
            {
                ViewState["UserId"] = dtUserExists.Rows[0]["UnsmId"].ToString();
                UpdateUserInformation();
            }

        }
           catch (Exception ex)
           {
               PMAssistReleaseVersion.AppCode.ErrorLogging.clsErrorLogging.LogError(ex.Message, "AddUsers.aspx.cs", "SaveData()");
               lblError.Text = "Failed";
           }
        }

    }
}