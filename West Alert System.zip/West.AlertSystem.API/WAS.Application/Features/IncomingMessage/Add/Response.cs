﻿namespace WAS.Application.Features.IncomingMessage.Add
{
    public class Response
    {
        /// <summary>
        /// Is incoming message added successully
        /// </summary>
        public bool Success { get; set; }
    }
}
