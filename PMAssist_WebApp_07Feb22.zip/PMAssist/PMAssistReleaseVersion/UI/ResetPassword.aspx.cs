﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using Microsoft.ApplicationBlocks.Data;
using System.Data;
using System.Data.SqlClient;
using System.Text;
using PMAssistReleaseVersion.AppCode;
using PMAssistReleaseVersion.AppCode.Generic;
using AjaxControlToolkit;


namespace PMAssistReleaseVersion.UI
{
    public partial class ResetPassword : System.Web.UI.Page
    {
        protected void Page_PreInit(object sender, EventArgs e)
        {
            try
            {
                if (Session["LoginType"] != null)
                {
                    clsGeneral.SetMasterPage(this.Page);
                }
            }

            catch (Exception ex)
            {
                PMAssistReleaseVersion.AppCode.ErrorLogging.clsErrorLogging.LogError(ex.Message, "ResetPassword.aspx.cs", "Page_PreInit()");
                lblError.Text = "Failed";
            }
        }

        protected void Page_Load(object sender, EventArgs e)
        {
            try
            {
                if (!IsPostBack)
                {
                    LoadSecurityQuestion();
                    ResetNavigation();
                    Page.Validate();
                }
            }
            catch (Exception ex)
            {
                PMAssistReleaseVersion.AppCode.ErrorLogging.clsErrorLogging.LogError(ex.Message, "ResetPassword.aspx.cs", "Page_Load()");
                lblError.Text = "Failed";
            }


        }

        public void GetUserSecurityDetails()
        {
            try
            {
                string PortalID = (Session["intUnsmPortalId"].ToString());

                if (!(Session["intUnsmPortalId"] == null))
                {
                    DataSet dsGetUserSecurityDetails = clsUsers.GetUserSecurityDetails(PortalID);
                    DataTable GetUserSecurityDetails = dsGetUserSecurityDetails.Tables[0];
                    DataRow drow = GetUserSecurityDetails.Rows[0];

                    ddlSecurityQuestion.SelectedValue = drow["ScqsID"].ToString();
                    txtSecurityAnswer.Text = System.Text.Encoding.ASCII.GetString((byte[])drow["UnsmScqsSecurityAnswer"]);
                }
            }
            catch (Exception ex)
            {
                PMAssistReleaseVersion.AppCode.ErrorLogging.clsErrorLogging.LogError(ex.Message, "ResetPassword.aspx.cs", "GetUserSecurityDetails()");
                throw;
            }
        }

        public void ResetNavigation()
        {
            try
            {
                string PortalID = (Session["intUnsmPortalId"].ToString());
                string isFirstLogin = string.Empty;
                isFirstLogin = clsUsers.IsFirstLogin(PortalID, isFirstLogin);

                if (!(Session["intUnsmPortalId"] == null))
                {
                    string LoginType = Session["LoginType"].ToString();
                    if (isFirstLogin.TrimEnd().ToUpper() == "N")
                    {
                        GetUserSecurityDetails();
                    }
                }
            }
            catch (Exception ex)
            {
                PMAssistReleaseVersion.AppCode.ErrorLogging.clsErrorLogging.LogError(ex.Message, "ResetPassword.aspx.cs", "ResetNavigation()");
                throw;
            }
        }
        //Load SecurityQuestion dropdown
        public void LoadSecurityQuestion()
        {

            try
            {
                DataTable dt = clsUsers.LoadSecurityQuestionData();
                ddlSecurityQuestion.DataSource = dt;
                ddlSecurityQuestion.DataTextField = "ScqsSecurityQuestion";
                ddlSecurityQuestion.DataValueField = "ScqsID";
                ddlSecurityQuestion.DataBind();
                ddlSecurityQuestion.Items.Insert(0, new ListItem("Select Security Question", ""));
            }

            catch (Exception ex)
            {
                PMAssistReleaseVersion.AppCode.ErrorLogging.clsErrorLogging.LogError(ex.Message, "ResetPassword.aspx.cs", "LoadSecurityQuestion()");
                lblError.Text = "Failed";
            }
        }

        //To Set the Password and Security Question
        public bool ResetUserPassword()
        {
            bool validateLogin = false;
            try
            {
                string PortalID = (Session["intUnsmPortalId"].ToString());
                string isFirstLogin = string.Empty;
                isFirstLogin = clsUsers.IsFirstLogin(PortalID, isFirstLogin);
                
                byte[] oldPassword;
                byte[] confirmPassword;
                byte[] securityAnswer;
                oldPassword = new ASCIIEncoding().GetBytes(txtDefaultPassword.Text);
                if (GenericLogin.ValidateLogin(PortalID, oldPassword))
                {
                    confirmPassword = new ASCIIEncoding().GetBytes(txtConfirmPassword.Text);
                    securityAnswer = new ASCIIEncoding().GetBytes(txtSecurityAnswer.Text);
                    clsUsers.ResetUserPassword(PortalID, ddlSecurityQuestion.SelectedValue, securityAnswer, oldPassword, confirmPassword);
                    lblError.Text = "Your SecurityQuestion/Password has Been Reset.";
                    lblError.ForeColor = System.Drawing.Color.Green;
                    validateLogin = true;
                }
                else
                {
                    lblError.Text = "Old password is incorrect.";
                    lblError.ForeColor = System.Drawing.Color.Red;
                    validateLogin = false;
                }

            }
            catch (Exception ex)
            {
                PMAssistReleaseVersion.AppCode.ErrorLogging.clsErrorLogging.LogError(ex.Message, "ISFirstLogin.aspx.cs", "ResetPassword()");
                lblError.Text = "Failed to Reset";
            }
            return validateLogin;
        }

        protected void btnReset_Click(object sender, EventArgs e)
        {
            try
            {
                bool proceed = ResetUserPassword();
                Label lblLoginPopupMessage = (Label)Master.FindControl("lblLoginPopupMessageMaster");
                if (lblLoginPopupMessage != null && proceed)
                {
                    lblLoginPopupMessage.Text = "Your security details has been reset." + Environment.NewLine + "Please Login to continue.";
                    ModalPopupExtender hdnLoginPopup_ModalPopupExtenderPanel = (ModalPopupExtender)Master.FindControl("hdnLoginPopupMaster_ModalPopupExtender");
                    hdnLoginPopup_ModalPopupExtenderPanel.Show();
                }
            }

            catch (Exception ex)
            {
                PMAssistReleaseVersion.AppCode.ErrorLogging.clsErrorLogging.LogError(ex.Message, "ISFirstLogin.aspx.cs", "btnReset_Click()");
                lblError.Text = "Failed to Reset";
            }

        }
    }
}