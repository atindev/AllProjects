﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.Security;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using Microsoft.ApplicationBlocks.Data;
using System.Data;
using System.Data.SqlClient;
using System.Text;
using PMAssistReleaseVersion.AppCode.Generic;


namespace PMAssistReleaseVersion.UI
{
    public partial class Login : System.Web.UI.Page
    {

        protected void Page_Load(object sender, EventArgs e)
        {
            try
            {

                if (!(Session["intUnsmPortalId"] == null))
                {
                    string LoginType = Session["LoginType"].ToString();

                    if (LoginType == "Y")
                    {
                        Response.Redirect("~/UI/Manager/ManagerDashboard.aspx");
                    }
                    else
                    {
                        Response.Redirect("~/UI/Resource/ResourceDashboard.aspx");
                    }
                }
            }


            catch (Exception ex)
            {
                PMAssistReleaseVersion.AppCode.ErrorLogging.clsErrorLogging.LogError(ex.Message, "Login.aspx.cs", "Page_Load()");
                lblError.Text = "Failed";
            }
        }
        private string IsFirstLogin()
        {
            try
            {
                string PortalID = (Session["intUnsmPortalId"].ToString());
                string isFirstLogin = string.Empty;
                isFirstLogin = clsUsers.IsFirstLogin(PortalID, isFirstLogin);
                Session["isFirstLogin"] = isFirstLogin;
                return isFirstLogin;
                
            }
            catch (Exception ex)
            {
                PMAssistReleaseVersion.AppCode.ErrorLogging.clsErrorLogging.LogError(ex.Message, "Login.aspx.cs", "IsFirstLogin()");
                throw;
            }
        }
        protected void btnLogin_Click(object sender, EventArgs e)
        {
            try
            {
                byte[] password;
                password = new ASCIIEncoding().GetBytes(txtPassword.Text);

                if (GenericLogin.ValidateLogin(txtPortalId.Text, password))
                {
                    if (IsFirstLogin() == "Y")
                    {
                        Response.Redirect("~/UI/ResetPassword.aspx", false);
                    }
                    else if ((Session["LoginType"].ToString() == "Y") && (IsFirstLogin() == "N"))
                    {
                        Response.Redirect("~/UI/Manager/ManagerDashboard.aspx",false);

                    }
                    else if ((Session["LoginType"].ToString() == "N") && (IsFirstLogin() == "N"))
                    {
                        Response.Redirect("~/UI/Resource/ResourceDashboard.aspx", false);
                    }

                }
                else
                {
                    lblError.Text = "Invalid Login";
                }
            }

            catch (Exception ex)
            {
                PMAssistReleaseVersion.AppCode.ErrorLogging.clsErrorLogging.LogError(ex.Message, "Login.aspx.cs", "btnLogin_Click()");
            }

        }

        protected void LbtnForgotPwd_Click(object sender, EventArgs e)
            
        {
            try
            {
                Response.Redirect("~/UI/ForgotPassword.aspx", false);
            }

            catch (Exception ex)
            {
                PMAssistReleaseVersion.AppCode.ErrorLogging.clsErrorLogging.LogError(ex.Message, "Login.aspx.cs", "LbtnForgotPwd_Click()");
            }
        }

        protected void btnOk_Click(object sender, EventArgs e)
        {

            try
            {
                Response.Redirect("~/UI/Login.aspx", false);
            }

            catch (Exception ex)
            {
                PMAssistReleaseVersion.AppCode.ErrorLogging.clsErrorLogging.LogError(ex.Message, "Login.aspx.cs", "btnOk_Click()");
            }
        }

    }

}