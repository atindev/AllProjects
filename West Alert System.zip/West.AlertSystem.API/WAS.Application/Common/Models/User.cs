﻿using System;
using System.Collections.Generic;
using System.Text;

namespace WAS.Application.Common.Models
{
    public class User:ADUser
    {
    }
}
