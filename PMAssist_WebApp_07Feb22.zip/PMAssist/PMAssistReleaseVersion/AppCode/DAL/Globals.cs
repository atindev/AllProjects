using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

/// <summary>
/// Summary description for Globals
/// </summary>
public class Globals
{
    // Paypal Subscription Variable Constants
    public const string _urlVarSeperator = "&";

    // Specify the URL that the button will link to
    public const string _postUrl = ""; 

    // Paypal Sandbox test URL
    public const string _postUrlTEST = "";

    // Specify a subscription type payment
    public const string _cmdSubscription = "cmd=_xclick-subscriptions";

    // Specify a singley payment or donation
    public const string _cmdSinglePayment = "cmd=_xclick";

    // Specify the Paypal merchant account email address
    public const string _business = "business=chandakkineni@softprosys.com";

    // If set to "1," the payment will recur unless your customer cancels the 
    // subscription before the end of the billing cycle. If omitted, the subscription 
    // payment will not recur at the end of the billing cycle.
    public const string _recurring = "src=1";

    // If set to "1," and the payment fails, the payment will be reattempted two more times. 
    // After the third failure, the subscription will be cancelled. If omitted and the payment 
    // fails, payment will not be reattempted and the subscription will be immediately cancelled.
    public const string _reattempt = "sra=1";

    // The URL to which the customer's browser is returned after completing the payment; 
    // for example, a URL on your site that displays a "Thank you for your payment" page. 
    // Default: customer is taken to the PayPal website.
    public const string _returnUrl = "return=";

    // A URL to which the customer's browser is returned if payment is canceled; for example, 
    // a URL on your website that displays a "Payment Canceled" page. 
    //Default: Browser is directed to the PayPal website.
    public const string _cancelReturnUrl = "cancel_return="; 
}
