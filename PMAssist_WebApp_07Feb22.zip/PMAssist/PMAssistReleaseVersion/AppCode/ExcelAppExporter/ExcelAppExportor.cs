﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Microsoft.Office.Interop.Excel;
using System.Diagnostics;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Collections;
using PMAssistReleaseVersion.AppCode.Generic;

namespace PMAssistReleaseVersion.UI.Manager
{
    /// <summary>
    /// Class to Export the Data to Excel sheet. Input must be a IList colection
    /// </summary>
    /// <typeparam name="T">Entity</typeparam>
    public class ExcelAppExportor<T>
    {
        /// <summary>
        /// Constructor
        /// </summary>
        public ExcelAppExportor()
        {
            TemplateFileName = string.Empty;
            IsExportIncludesHeader = true;
            ExportSheetName = "Export";
            ReportStaticFields = clsReports.GetReportStaticFields();
        }
        /// <summary>
        /// Holds the Data
        /// </summary>
        private IList<T> ListData;

        /// <summary>
        /// Holds the Export Columns
        /// </summary>
        private IList<ExportColumn> ExportColumns;

        /// <summary>
        /// Add the export column
        /// </summary>
        /// <param name="ExportColumn">ExportColumn</param>
        public void AddExportColumn(ExportColumn ExportColumn)
        {
            if (ExportColumns == null) ExportColumns = new List<ExportColumn>();
            ExportColumns.Add(ExportColumn);
        }
        /// <summary>
        /// List contains the list of entity object which are export to excel
        /// </summary>
        public IList<T> BindDataList
        {
            get { return ListData; }
            set { ListData = value; }
        }
        /// <summary>
        /// File Name of the Export output file
        /// </summary>
        public string ExportFileName { get; set; }

        /// <summary>
        /// Template File Name - Using Template file to Export
        /// </summary>
        public string TemplateFileName { get; set; }

        /// <summary>
        /// Sheet name to Export the data
        /// </summary>
        public string ExportSheetName { get; set; }

        public ArrayList ReportStaticFields { get; set; }

        /// <summary>
        /// Is the header data needs to be exported
        /// </summary>
        public bool IsExportIncludesHeader { get; set; }

        public void Export(bool insertRow)
        {
            try
            {
                #region Filling Export Columns
                // Check the columns to export is mentioned, if not
                if (ExportColumns == null)
                {
                    // Create an entity object. If the list count == 0 ??? - needs to be handled from client
                    T tEntity = ListData[0];

                    // Export the columns to export from the property name
                    ExportColumns = new List<ExportColumn>();
                    foreach (System.Reflection.PropertyInfo propertyInfo in tEntity.GetType().GetProperties())
                        ExportColumns.Add(new ExportColumn(propertyInfo.Name, propertyInfo.Name));
                }
                #endregion

                // Create excel application
                Application ExcelApp = new ApplicationClass();
                Workbook workbook;
                Sheets sheets;
                Worksheet worksheet;

                // Is Export needs to be exported to a Template file
                if (TemplateFileName != string.Empty)
                {
                    #region Load the Template file
                    // Load the work book
                    ExcelApp.DisplayAlerts = false;
                    workbook = ExcelApp.Workbooks.Open(TemplateFileName, 0, false, 5, "", "", false,
                        XlPlatform.xlWindows, "", true, false, 0, true, false, false);

                    sheets = workbook.Sheets;
                    worksheet = (Worksheet)sheets.get_Item(1); // To avoid unassigned variable error

                    bool IsWorkSheetFound = false;

                    //Check is there any worksheet with the name provided. If yes, clear all data inside to fill new data
                    for (int intSheetIndex = 1; intSheetIndex <= sheets.Count; intSheetIndex++)
                    {
                        worksheet = (Worksheet)sheets.get_Item(intSheetIndex);
                        if (worksheet.Name.ToString().Equals(ExportSheetName))
                        {
                            IsWorkSheetFound = true;
                            worksheet.Activate();
                            break;
                        }
                    }

                    // If No work sheet found, add it at the last
                    if (!IsWorkSheetFound)
                    {
                        worksheet = (Worksheet)workbook.Sheets.Add(
                            Type.Missing, (Worksheet)sheets.get_Item(sheets.Count),
                            Type.Missing, Type.Missing);
                        worksheet.Name = ExportSheetName;
                    }
                    #endregion
                }
                else
                {
                    #region Create the Template File
                    // Adding new work book
                    workbook = ExcelApp.Workbooks.Add(XlWBATemplate.xlWBATWorksheet);

                    sheets = workbook.Sheets;

                    worksheet = (Worksheet)sheets.get_Item(1);

                    worksheet.Name = ExportSheetName;
                    #endregion
                }
                int intCol = 0;

                #region Populating the Header
                // If the header needs to exported. In templated files, normally we will have the headings
                if (IsExportIncludesHeader == true)
                {
                    // Exporting Header
                    foreach (ExportColumn exportColumn in ExportColumns)
                    {
                        Range range = (Range)worksheet.Cells[exportColumn.StartRowIndex++, ((exportColumn.ExcelColumnIndex == 0) ? ++intCol : exportColumn.ExcelColumnIndex - 1)];
                        range.Select();
                        range.Value2 = exportColumn.HeaderText.ToString();
                        range.Columns.EntireColumn.AutoFit();
                        range.Font.Bold = true;
                    }
                }
                #endregion

                // Exporting Data 
                bool isStaticField = false;
                foreach (T tEntity in BindDataList)
                {
                    intCol = 0;
                    Range range = null;

                    foreach (ExportColumn exportColumn in ExportColumns)
                    {
                        isStaticField = ReportStaticFields.Contains(exportColumn.ColumnName.Trim());
                        if (isStaticField)
                        {
                            range = (Range)worksheet.Cells[exportColumn.StartRowIndex, ((exportColumn.ExcelColumnIndex == 0) ? ++intCol : exportColumn.ExcelColumnIndex)];
                        }
                        else
                        {
                            range = (Range)worksheet.Cells[exportColumn.StartRowIndex++, ((exportColumn.ExcelColumnIndex == 0) ? ++intCol : exportColumn.ExcelColumnIndex)];
                        }
                        range.Select();
                        range.Value2 = tEntity.GetType().GetProperty(exportColumn.ColumnName.ToString()).GetValue(tEntity, null).ToString();
                        //if (insertRow && exportColumn.HeaderText.Contains("InsertNewLine") && !string.IsNullOrEmpty(Convert.ToString(range.Value2)))
                        //{
                        //    range.Value2 = string.Empty;
                        //    worksheet.Rows.Insert(XlInsertShiftDirection.xlShiftDown, false);
                        //    //range.Insert(XlInsertShiftDirection.xlShiftDown, XlInsertFormatOrigin.xlFormatFromRightOrBelow);
                        //    //worksheet.Range[string.Format("{0}:{0}", range.Row + 1)].EntireRow.Insert(Microsoft.Office.Interop.Excel.XlInsertShiftDirection.xlShiftDown, Microsoft.Office.Interop.Excel.XlInsertFormatOrigin.xlFormatFromRightOrBelow);
                        //    //range.Insert(Microsoft.Office.Interop.Excel.XlInsertShiftDirection.xlShiftDown, Microsoft.Office.Interop.Excel.XlInsertFormatOrigin.xlFormatFromRightOrBelow);
                        //    //worksheet..Insert(Type.Missing, Type.Missing);
                        //    //range.EntireRow.EntireRow.Insert(Microsoft.Office.Interop.Excel.XlInsertShiftDirection.xlShiftDown, Microsoft.Office.Interop.Excel.XlInsertFormatOrigin.xlFormatFromRightOrBelow);
                        //}
                    }
                }

                intCol = 0;
                foreach (ExportColumn exportColumn in ExportColumns)
                {
                    Range range = (Range)worksheet.Cells[exportColumn.StartRowIndex++, ((exportColumn.ExcelColumnIndex == 0) ? ++intCol : exportColumn.ExcelColumnIndex)];
                    if (exportColumn.ValueFormat != string.Empty)
                        range.Columns.EntireColumn.NumberFormat = exportColumn.ValueFormat;
                }
                try
                {
                    // Save the workbook with saving option
                    workbook.Close(true, ExportFileName, Type.Missing);
                    ExcelApp.UserControl = false;
                    ExcelApp.Quit();
                    ExcelApp = null;
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                Process[] ps = Process.GetProcesses();
                foreach (Process p in ps)
                {
                    if (p.ProcessName.ToLower().Equals("excel"))
                        p.Kill();
                }
            }
        }
    }
}