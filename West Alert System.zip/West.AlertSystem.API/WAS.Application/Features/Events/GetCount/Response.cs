﻿using System.Collections.Generic;

namespace WAS.Application.Features.Events.GetCount
{
    public class Response
    {
        /// <summary>
        /// Count of All events
        /// </summary>
        public int Count { get; set; }

    }
}
