﻿using System;
using XamarinMvvm.Common;

namespace XamarinMvvm.Model
{
    public class BaseModel:NotifyPropertyChanged
    {
        public BaseModel()
        {
        }
    }
}
