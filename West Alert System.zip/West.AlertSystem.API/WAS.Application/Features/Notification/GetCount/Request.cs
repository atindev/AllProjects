﻿using MediatR;
using System;
using System.Collections.Generic;
using System.Text;

namespace WAS.Application.Features.Notification.GetCount
{
    public class Request : IRequest<Response>
    {
    }
}
