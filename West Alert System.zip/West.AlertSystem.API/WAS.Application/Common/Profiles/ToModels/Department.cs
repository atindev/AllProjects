﻿using System;
using System.Collections.Generic;
using System.Text;

namespace WAS.Application.Common.Models
{
    public class Department
    {
        public int Id { get; set; }

        public string Name { get; set; }
    }
}
