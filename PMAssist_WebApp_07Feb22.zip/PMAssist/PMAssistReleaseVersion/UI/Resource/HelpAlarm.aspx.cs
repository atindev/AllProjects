﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.Mail;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using Microsoft.ApplicationBlocks.Data;
using System.Data;
using System.Data.SqlClient;
using System.Text;
using System.Collections;
using System.Net.Mail;
using PMAssistReleaseVersion.AppCode.Generic;


namespace PMAssistReleaseVersion.UI.Resource
{
    public partial class HelpAlarm : System.Web.UI.Page
    {
        protected void Page_PreInit(object sender, EventArgs e)
        {
            try
            {
                if (Session["LoginType"] != null)
                {
                    clsGeneral.SetMasterPage(this.Page);
                }
            }
            catch (Exception ex)
            {
                PMAssistReleaseVersion.AppCode.ErrorLogging.clsErrorLogging.LogError(ex.Message, "HelpAlarm.aspx.cs", "Page_PreInit()");
              
            }
        }
        protected void Page_Load(object sender, EventArgs e)
        {

        }

         protected void btnGetEmails_Click(object sender, EventArgs e)
        {
            try
            {

                //Get all Email addresses 
                DataTable dtRecipientsEmails = null;
                dtRecipientsEmails = GenericLogin.GetTeamEmailsList();
                if ((dtRecipientsEmails == null) || (dtRecipientsEmails.Rows.Count == 0))
                {
                    lblMsg.Visible = true;
                    lblMsg.Text = "No User Emails Exist";
                }
                else
                {
                    if ((dtRecipientsEmails != null) || (dtRecipientsEmails.Rows.Count > 0))
                    {
                        string strEmailsList = GetCommaSeparatedEmailsList(dtRecipientsEmails);
                        if (strEmailsList != "")
                        {
                            Session["EmailsList"] = strEmailsList;
                            txtTo.Text = strEmailsList;
                            lblMsg.Text = "*You have selected " + dtRecipientsEmails.Rows.Count.ToString() + " Emails to send mail.";

                        }
                    }
                }
            }

            catch (Exception ex)
            {
                PMAssistReleaseVersion.AppCode.ErrorLogging.clsErrorLogging.LogError(ex.Message, "HelpAlarm.aspx.cs", "btnGetEmails_Click()");

            }
         }

        public string GetCommaSeparatedEmailsList(DataTable dtEmails)
        {
            string strEmailsList = "";
            try
            {
               
               
                int cnt = dtEmails.Rows.Count - 1;
                if (dtEmails.Rows.Count == 1)
                {
                    strEmailsList = dtEmails.Rows[0]["Emails"].ToString();

                }
                else
                {
                    for (int i = 0; i < (dtEmails.Rows.Count - 1); i++)
                    {
                        strEmailsList = strEmailsList + dtEmails.Rows[i]["UnsmEmail"].ToString() + ", ";

                    }
                }
                strEmailsList = strEmailsList.Remove(strEmailsList.Length - 2);
                
            }
            catch (Exception ex)
            {
                PMAssistReleaseVersion.AppCode.ErrorLogging.clsErrorLogging.LogError(ex.Message, "HelpAlarm.aspx.cs", "GetCommaSeparatedEmailsList()");

            }
            return strEmailsList;
        }

        protected void SendMail_Click(object sender, EventArgs e)
        {
            try
            {

                SmtpClient client = new SmtpClient();
                client.Host = "smtp.gmail.com";
                client.Port = 587;
                client.Credentials = new System.Net.NetworkCredential("sivakumarkpch@gmail.com", "sivakumarkpch1984");

                System.Net.Mail.MailMessage cmail = new System.Net.Mail.MailMessage();

                cmail.From = new MailAddress("sivakumarkpch@gmail.com");
                string strEmails = string.Empty;

                if (Session["EmailsList"] != null)

                    strEmails = txtTo.Text;

                cmail.Bcc.Add(strEmails);

                string strSubject = txtSubject.Text.ToString();

                if ((strSubject.Length == 0) || (strSubject.Equals(String.Empty)))

                    cmail.Subject = "PMAssist - Help Alarm from one of the Resource ";
                else
                    cmail.Subject = strSubject.ToString();

                cmail.IsBodyHtml = true;

                client.Send(cmail);
            }

            catch (Exception ex)
            {
                PMAssistReleaseVersion.AppCode.ErrorLogging.clsErrorLogging.LogError(ex.Message, "HelpAlarm.aspx.cs", "SendMail_Click()");

            }

        }

       

        }

       
    }

 