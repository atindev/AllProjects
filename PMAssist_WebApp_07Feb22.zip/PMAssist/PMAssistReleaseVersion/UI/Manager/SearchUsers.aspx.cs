﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using Microsoft.ApplicationBlocks.Data;
using System.Data;
using System.Data.SqlClient;
using System.Text;
using PMAssistReleaseVersion.AppCode.Generic;

namespace PMAssistReleaseVersion.UI.Manager
{
    public partial class SearchUsers : System.Web.UI.Page
    {
        string PortalId;
        protected void Page_PreInit(object sender, EventArgs e)
        {
            try
            {
                if (Session["LoginType"] != null)
                {
                    clsGeneral.SetMasterPage(this.Page);
                }
            }
            catch (Exception ex)
            {
                PMAssistReleaseVersion.AppCode.ErrorLogging.clsErrorLogging.LogError(ex.Message, "SearchUsers.aspx.cs", "Page_PreInit()");
                lblError.Text = "Failed";
            }
        }

        protected void Page_Load(object sender, EventArgs e)
        {
            try
            {
                if (!IsPostBack)
                {
                    FillControls();
                }
            }
            catch (Exception ex)
            {
                PMAssistReleaseVersion.AppCode.ErrorLogging.clsErrorLogging.LogError(ex.Message, "SearchUsers.aspx.cs", "Page_Load()");
                lblError.Text = "Failed";
            }
        }

        private void FillControls()
        {
            try
            {
                LoadPortalID();
            }
            catch (Exception ex)
            {
                PMAssistReleaseVersion.AppCode.ErrorLogging.clsErrorLogging.LogError(ex.Message, "SearchUsers.aspx.cs", "FillControls()");
                lblError.Text = "Failed";
            }
        }

        protected void btnSearch_Click(object sender, EventArgs e)
        {
            try
            {

                PortalId = ddlPortal.SelectedValue;
                DataSet dsUserDetails = clsSearch.GetUserDetails(PortalId);
                gvUserList.DataSource = dsUserDetails;
                gvUserList.DataBind();


                if (gvUserList.Rows.Count == 0)
                {
                    lblHeadingUser.Visible = false;
                }
                else
                {
                    lblHeadingUser.Visible = true;
                }
            }
            catch (Exception ex)
            {
                PMAssistReleaseVersion.AppCode.ErrorLogging.clsErrorLogging.LogError(ex.Message, "SearchUsers.aspx.cs", "btnSearch_Click()");
                Response.Redirect("Oops.aspx");

            }
        }

        //To bind gridview with the UserDetails
        public void BindGrid()
        {
            try
            {
                //Here we are passing portalId to get Ticketdetails of the specif user
                DataSet dtUserDetails = clsSearch.GetUserDetails(PortalId);
                gvUserList.DataSource = dtUserDetails;
                gvUserList.DataBind();
                dtUserDetails.Clear();

            }

            catch (Exception ex)
            {
                PMAssistReleaseVersion.AppCode.ErrorLogging.clsErrorLogging.LogError(ex.Message, "SearchUsers.aspx.cs", "BindGrid()");
                lblError.Text = "Failed";
            }
        }

        //Load LoadPortalID Dropdown
        private void LoadPortalID()
        {
            try
            {
                DataTable dt = clsUsers.LoadPortalID();
                ddlPortal.DataSource = dt;
                ddlPortal.DataTextField = "ResourceName";
                ddlPortal.DataValueField = "PortalId";
                ddlPortal.DataBind();
                ddlPortal.Items.Insert(0, new ListItem("Select Portal ID", "0"));
            }
            catch (Exception ex)
            {
                PMAssistReleaseVersion.AppCode.ErrorLogging.clsErrorLogging.LogError(ex.Message, "SearchUsers.aspx.cs", "LoadPortalID()");
                lblError.Text = "Failed";
            }

        }
        
        protected void gvUserList_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            try
            {
                gvUserList.PageIndex = e.NewPageIndex;
                BindGrid();
            }
            catch (Exception ex)
            {
                PMAssistReleaseVersion.AppCode.ErrorLogging.clsErrorLogging.LogError(ex.Message, "SearchUsers.aspx.cs", "gvUserList_PageIndexChanging()");
                lblError.Text = "Failed";
            }

        }
    }
}