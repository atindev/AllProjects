﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace PMAssistReleaseVersion.UI.Manager
{
    /// <summary>
    /// Holds the details of te columns to be exported to Excel from IList
    /// </summary>
    public class ExportColumn
    {
        /// <summary>
        /// Entity object(class) property name, mandatory
        /// </summary>
        public string ColumnName { get; set; }

        /// <summary>
        /// What needs to be shows in the Excel sheet for that col, mandatory
        /// </summary>
        public string HeaderText { get; set; }

        /// <summary>
        /// The format of the value. To get the format string, from the excel sheet -> Column -> Format Cells -> Number -> Custom -> Take the Type
        /// </summary>
        public string ValueFormat { get; set; }

        /// <summary>
        /// From which row the data needs to be exported, for template file it will be useful
        /// </summary>
        public int StartRowIndex { get; set; }

        /// <summary>
        /// On which column the data needs to be exports, So it can be any column. Useful for Templated file
        /// Needs to assign the Index of the column starting by 1
        /// A - 1, B - 2, C - 3 etc., Counting will include the hidden column
        /// </summary>
        public int ExcelColumnIndex { get; set; }

        public ExportColumn()
        {
            StartRowIndex = 1;
            this.ValueFormat = string.Empty;
            this.StartRowIndex = 1;
            this.ExcelColumnIndex = 0;
        }
        public ExportColumn(string ColumnName, string HeaderText)
        {
            this.ColumnName = ColumnName;
            this.HeaderText = HeaderText;
            this.ValueFormat = string.Empty;
            this.StartRowIndex = 1;
            this.ExcelColumnIndex = 0;
        }
        public ExportColumn(string ColumnName, string HeaderText, int StartRowIndex, int ExcelColumnIndex)
        {
            this.ColumnName = ColumnName;
            this.HeaderText = HeaderText;
            this.ValueFormat = string.Empty;
            this.StartRowIndex = StartRowIndex;
            this.ExcelColumnIndex = ExcelColumnIndex;
        }
        public ExportColumn(string ColumnName, string HeaderText, string ValueFormat)
        {
            this.ColumnName = ColumnName;
            this.HeaderText = HeaderText;
            this.ValueFormat = ValueFormat;
            this.StartRowIndex = 1;
            this.ExcelColumnIndex = 0;
        }
        public ExportColumn(string ColumnName, string HeaderText, string ValueFormat, int StartRowIndex, int ExcelColumnIndex)
        {
            this.ColumnName = ColumnName;
            this.HeaderText = HeaderText;
            this.ValueFormat = ValueFormat;
            this.StartRowIndex = StartRowIndex;
            this.ExcelColumnIndex = ExcelColumnIndex;
        }
    }
}
