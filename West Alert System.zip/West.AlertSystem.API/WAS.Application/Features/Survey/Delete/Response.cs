﻿using System;
using System.Collections.Generic;
using System.Text;

namespace WAS.Application.Features.Survey.Delete
{
    public class Response
    {
        /// <summary>
        /// Is Survey delete success
        /// </summary>
        public bool Success { get; set; }
    }
}
