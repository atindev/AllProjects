﻿using System;
using System.Collections.Generic;
using System.Text;

namespace WAS.Application.Features.Events.Archive
{
    public class Response
    {
        /// <summary>
        /// Is Event Create/update success
        /// </summary>
        public bool Success { get; set; }
    }
}
