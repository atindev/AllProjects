﻿using System;
using System.Collections.Generic;
using System.Text;

namespace WAS.Application.Common.Settings
{
    public class TextAnalyticsSettings
    {
        /// <summary>
        /// SubscriptionKey
        /// </summary>
        public string SubscriptionKey { get; set; }

        /// <summary>
        /// EndPoint
        /// </summary>
        public string EndPoint { get; set; }
    }
}
