﻿using System;
using System.Collections.Generic;
using System.Text;

namespace WAS.Application.Features.Subscription.GetByMailUnMasked
{
    public class Response : Common.Models.SubscriptionDetails
    {

       
    }
}
