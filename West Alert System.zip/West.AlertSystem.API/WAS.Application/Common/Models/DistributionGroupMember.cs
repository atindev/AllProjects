﻿namespace WAS.Application.Common.Models
{
    public class DistributionGroupMember
    {
        public string FirstName { get; set; }

        public string LastName { get; set; }

        public string EmailId { get; set; }

        public string Department { get; set; }

        public string Location { get; set; }
    }
}
