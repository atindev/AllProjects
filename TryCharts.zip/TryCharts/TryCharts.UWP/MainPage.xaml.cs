﻿namespace TryCharts.UWP
{
    public sealed partial class MainPage
    {
        public MainPage()
        {
            this.InitializeComponent();

            LoadApplication(new TryCharts.App());
        }
    }
}
