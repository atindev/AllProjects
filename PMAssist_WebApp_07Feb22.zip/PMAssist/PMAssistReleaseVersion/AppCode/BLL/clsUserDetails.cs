﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace PMAssistReleaseVersion.AppCode.Generic
{
    public class clsUserDetails
    {
        public int UserId { get; set; }
        public string UserPortalId { get; set; }
        public string UserEmail { get; set; }
        public byte[] UserPassword { get; set; }
        public string UserFirstName { get; set; }
        public string UserLastName { get; set; }
        public string UserProjectAccount { get; set; }
        public int UserGrade { get; set; }
        public string UserIsManager { get; set; }
        public string UserCurrent { get; set; }
        public int UserEntryId { get; set; }
        public string UserEntryDate { get; set; }
        public int UserLastChangedId { get; set; }
        public string UserLastChangedDate { get; set; }
        public int UserTeam { get; set; }
        public int UserSecurityQuestion { get; set; }
        public string UserSecurityAnswer { get; set; }
        public string IsFirstLogin { get; set; }
        public string UserAccountJoiningDate { get; set; }
        public string UserAccountLeavingDate { get; set; }
        public int UserLocation { get; set; }
        public string UserEmployeeId { get; set; }
        public int UserPractice { get; set; }
    }
}