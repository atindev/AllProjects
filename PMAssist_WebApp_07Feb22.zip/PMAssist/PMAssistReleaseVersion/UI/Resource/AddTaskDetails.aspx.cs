﻿using AjaxControlToolkit;
using PMAssistReleaseVersion.AppCode;
using PMAssistReleaseVersion.AppCode.Generic;
using System;
using System.Collections.Generic;
using System.Data;
using System.Globalization;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace PMAssistReleaseVersion.UI.Resource
{
    public partial class AddTaskDetails : System.Web.UI.Page
    {
        string taskDate;
        public string ReferenceNumber { get; set; }
        protected void Page_PreInit(object sender, EventArgs e)
        {
            try
            {
                if (Session["LoginType"] != null)
                {
                    clsGeneral.SetMasterPage(this.Page);
                }
            }

            catch (Exception ex)
            {
                PMAssistReleaseVersion.AppCode.ErrorLogging.clsErrorLogging.LogError(ex.Message, "AddTaskDetails.aspx.cs", "Page_PreInit()");
                lblError.Text = "Failed";
            }
        }

        protected void Page_Load(object sender, EventArgs e)
        {
            try
            {
                if (!IsPostBack)
                {
                    LoadControls();

                    if (Request.QueryString["EditTaskReference"] != null)
                    {
                        var TaskDetails = clsTaskInformation.LoadTaskDetailsByReference(Request.QueryString["EditTaskReference"].ToString());
                        ViewTaskDetails(TaskDetails);
                        CustomizeEditPageControls(TaskDetails);
                    }
                    else if (Request.QueryString["ViewTaskReference"] != null)
                    {
                        var TaskDetails = clsTaskInformation.LoadTaskDetailsByReference(Request.QueryString["ViewTaskReference"].ToString());
                        ViewTaskDetails(TaskDetails);
                        CustomizeViewPageControls(TaskDetails);
                    }
                }
                Page.Validate();
            }
            catch (Exception ex)
            {
                PMAssistReleaseVersion.AppCode.ErrorLogging.clsErrorLogging.LogError(ex.Message, "AddTaskDetails.aspx.cs", "Page_Load()");
                lblError.Text = "Failed";
            }
        }
        public void CustomizeEditPageControls(clsTaskDetails TicketDetails)
        {
            try
            {

                btnSubmit.Text = "Update";
                lblHeading.Text = "Edit Task Details";
                lblNewTaskReference.Enabled = false;
                txtTaskDate.Enabled = false;
            }

            catch (Exception ex)
            {
                PMAssistReleaseVersion.AppCode.ErrorLogging.clsErrorLogging.LogError(ex.Message, "AddTaskDetails.aspx.cs", "CustomizeEditPageControls()");
                lblError.Text = "Failed";
            }
            
        }
        public void CustomizeViewPageControls(clsTaskDetails TaskDetails)
        {
            try
            {
                if (Session["intUnsmPortalId"].ToString() == TaskDetails.EntryId)
                {
                    btnSubmit.Text = "Edit";
                }
                else
                {
                    btnSubmit.Visible = false;
                }
                lblHeading.Text = "View Task Details";
                lblMandatory.Visible = false;

                ContentPlaceHolder cntPlcHldrMaster = (ContentPlaceHolder)Master.FindControl("ContentPlaceHolderMaster");
                foreach (Control inputControl in cntPlcHldrMaster.Controls)
                {
                    if (inputControl is TextBox)
                    {
                        ((TextBox)inputControl).BackColor = System.Drawing.Color.Transparent;
                        ((TextBox)inputControl).Enabled = false;
                        ((TextBox)inputControl).BorderStyle = BorderStyle.None;
                    }
                    if (inputControl is DropDownList)
                    {
                        ((DropDownList)inputControl).BackColor = System.Drawing.Color.Transparent;
                        ((DropDownList)inputControl).Enabled = false;
                        ((DropDownList)inputControl).BorderStyle = BorderStyle.None;
                    }
                }
                ddlSecondaryActivity.BackColor = System.Drawing.Color.Transparent;
                ddlSecondaryActivity.Enabled = false;
                ddlSecondaryActivity.BorderStyle = BorderStyle.None;
            }

            catch (Exception ex)
            {
                PMAssistReleaseVersion.AppCode.ErrorLogging.clsErrorLogging.LogError(ex.Message, "AddTaskDetails.aspx.cs", "CustomizeViewPageControls()");
                lblError.Text = "Failed";
            }
            

        }
        public void ViewTaskDetails(clsTaskDetails ViewTaskDetails)
        {
            try
            {
                ViewState["TaskId"] = ViewTaskDetails.TaskId;
                txtTaskDate.Text = ViewTaskDetails.TaskDate;
                lblNewTaskReference.Text = ViewTaskDetails.TaskReference;
                ddlPrimaryActivity.SelectedValue = ViewTaskDetails.PrimaryActivityId;
                LoadSecondaryActivity(Convert.ToInt32(ViewTaskDetails.PrimaryActivityId));
                ddlSecondaryActivity.SelectedValue = ViewTaskDetails.SecondaryActivityId;
                txtTask.Text = ViewTaskDetails.Task;
                txtDescription.Text = ViewTaskDetails.TaskDescription;
                txtHours.Text = ViewTaskDetails.TaskHours;
                txtStatus.Text = ViewTaskDetails.TaskStatus;
                txtRemarks.Text = ViewTaskDetails.TaskRemarks;
            }

            catch (Exception ex)
            {
                PMAssistReleaseVersion.AppCode.ErrorLogging.clsErrorLogging.LogError(ex.Message, "AddTaskDetails.aspx.cs", "ViewTaskDetails()");
                lblError.Text = "Failed";
            }
            

        }
        public void LoadControls()
        {
            try
            {
                LoadPrimaryActivity();
                LoadSecondaryActivity(0); //Primary loading
            }

            catch (Exception ex)
            {
                PMAssistReleaseVersion.AppCode.ErrorLogging.clsErrorLogging.LogError(ex.Message, "AddTaskDetails.aspx.cs", "LoadControls()");
                lblError.Text = "Failed";
            }
        }
        //Load LoadTIcketTypeDetails dropdown
        private void LoadPrimaryActivity()
        {
            try
            {
                DataTable dt = clsTaskInformation.LoadPrimaryActivity();
                ddlPrimaryActivity.DataSource = dt;
                ddlPrimaryActivity.DataTextField = "PrmyPrimaryActivity";
                ddlPrimaryActivity.DataValueField = "PrmyId";
                ddlPrimaryActivity.DataBind();
            }
            catch (Exception ex)
            {
                PMAssistReleaseVersion.AppCode.ErrorLogging.clsErrorLogging.LogError(ex.Message, "AddTaskDetails.aspx.cs", "LoadPrimaryActivity()");
                lblError.Text = "Failed";
            }

        }
        //Load LoadTIcketTypeDetails dropdown
        private void LoadSecondaryActivity(int PrimaryId)
        {
            try
            {
                DataTable dt = clsTaskInformation.LoadSecondaryActivity(PrimaryId);
                ddlSecondaryActivity.DataSource = dt;
                ddlSecondaryActivity.DataTextField = "ScacSecondaryActivity";
                ddlSecondaryActivity.DataValueField = "ScacId";
                ddlSecondaryActivity.DataBind();
            }
            catch (Exception ex)
            {
                PMAssistReleaseVersion.AppCode.ErrorLogging.clsErrorLogging.LogError(ex.Message, "AddTaskDetails.aspx.cs", "LoadSecondaryActivity()");
                lblError.Text = "Failed";
            }

        }
        protected void ddlPrimaryActivity_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {

                LoadSecondaryActivity(Convert.ToInt32(ddlPrimaryActivity.SelectedValue));
            }

            catch (Exception ex)
            {
                PMAssistReleaseVersion.AppCode.ErrorLogging.clsErrorLogging.LogError(ex.Message, "AddTaskDetails.aspx.cs", "ddlPrimaryActivity_SelectedIndexChanged()");
                lblError.Text = "Failed";
            }
        }

        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            try
            {

                if (btnSubmit.Text == "Edit")
                {
                    //btnSubmit.PostBackUrl = "~/UI/Resource/AddTicketDetails.aspx?EditTicketReference=" + txtReferenceNumber.Text;
                    Response.Redirect("~/UI/Resource/AddTaskDetails.aspx?EditTaskReference=" + lblNewTaskReference.Text, false);
                }
                else
                {
                    SaveData();
                }
            }
            catch (Exception ex)
            {
                PMAssistReleaseVersion.AppCode.ErrorLogging.clsErrorLogging.LogError(ex.Message, "AddTaskDetails.aspx.cs", "btnSubmit_Click()");
                lblError.Text = "Failed";
            }

        }
        void SaveData()
        {
            try
            {
                ReferenceNumber = lblNewTaskReference.Text;
                DataSet dsTaskReferenceNumberExists = clsTaskInformation.CheckTaskReferenceNumber(ReferenceNumber);
                DataTable dtCheckTaskReferenceNumber = dsTaskReferenceNumberExists.Tables[0];

                if (dtCheckTaskReferenceNumber.Rows.Count == 0)
                {
                    GetTaskDate();
                    AddTaskdetails();
                }
                else
                {
                    UpdateTaskDetails();
                }
            }

            catch (Exception ex)
            {
                PMAssistReleaseVersion.AppCode.ErrorLogging.clsErrorLogging.LogError(ex.Message, "AddTaskDetails.aspx.cs", "SaveData()");
                lblError.Text = "Failed";
            }
        }
        protected void txtTaskDate_TextChanged(object sender, EventArgs e)
        {
            try
            {

                if (!(txtTaskDate.Text == string.Empty))
                {
                    GetTaskDate();
                    lblNewTaskReference.Text = clsTaskInformation.GetNewTaskReferenceByPortalIdTaskDate(Session["intUnsmPortalId"].ToString(), taskDate);
                }
                else
                    lblNewTaskReference.Text = string.Empty;
            }
            catch (Exception ex)
            {
                PMAssistReleaseVersion.AppCode.ErrorLogging.clsErrorLogging.LogError(ex.Message, "AddTaskDetails.aspx.cs", "txtTaskDate_TextChanged()");
                lblError.Text = "Failed";
            }
        }
        void AddTaskdetails()
        {
            try
            {
                clsTaskInformation.AddTaskDetails(lblNewTaskReference.Text, taskDate, Convert.ToInt32(ddlPrimaryActivity.SelectedValue), Convert.ToInt32(ddlSecondaryActivity.SelectedValue), txtTask.Text, txtDescription.Text, Convert.ToInt32(txtHours.Text), Convert.ToInt32(txtStatus.Text), txtRemarks.Text, Session["intUnsmPortalId"].ToString());
                Label lblAddTicketPopupMessageMasterMessage = (Label)Master.FindControl("lblAddTicketPopupMessageMaster");
                lblAddTicketPopupMessageMasterMessage.Text = "New Task with reference \"" + lblNewTaskReference.Text + "\" is added successfully into PMAssist";
                ModalPopupExtender hdnAddTicketPopup_ModalPopupExtenderMasterPanel = (ModalPopupExtender)Master.FindControl("hdnAddTicketPopupMaster_ModalPopupExtender");
                hdnAddTicketPopup_ModalPopupExtenderMasterPanel.Show();

            }

            catch (Exception ex)
            {
                PMAssistReleaseVersion.AppCode.ErrorLogging.clsErrorLogging.LogError(ex.Message, "AddTaskDetails.aspx.cs", "AddTaskdetails()");
                lblError.Text = "Failed to Update";
            }
        }
        void UpdateTaskDetails()
        {
            try
            {
                clsTaskInformation.UpdateTaskDetailsByID(Convert.ToInt32(ViewState["TaskId"].ToString()), lblNewTaskReference.Text, Convert.ToInt32(ddlPrimaryActivity.SelectedValue), Convert.ToInt32(ddlSecondaryActivity.SelectedValue), txtTask.Text, txtDescription.Text, Convert.ToInt32(txtHours.Text), Convert.ToInt32(txtStatus.Text), txtRemarks.Text, Session["intUnsmPortalId"].ToString(), "N");
                Label lblAddTicketPopupMessageMasterMessage = (Label)Master.FindControl("lblAddTicketPopupMessageMaster");
                lblAddTicketPopupMessageMasterMessage.Text = "Task details with reference \"" + lblNewTaskReference.Text + "\" is updated successfully into PMAssist";
                ModalPopupExtender hdnAddTicketPopup_ModalPopupExtenderMasterPanel = (ModalPopupExtender)Master.FindControl("hdnAddTicketPopupMaster_ModalPopupExtender");
                hdnAddTicketPopup_ModalPopupExtenderMasterPanel.Show();
            }

            catch (Exception ex)
            {
                PMAssistReleaseVersion.AppCode.ErrorLogging.clsErrorLogging.LogError(ex.Message, "AddTaskDetails.aspx.cs", "UpdateTaskDetails()");
                lblError.Text = "Failed to Update";
            }
        }
        void GetTaskDate()
        {
            try
            {
                taskDate = Request.Form[txtTaskDate.UniqueID].ToString();
                if (!(taskDate == string.Empty))
                    taskDate = Convert.ToDateTime(Request.Form[txtTaskDate.UniqueID]).ToString("dd/MM/yyyy");
            }
            catch (Exception ex)
            {
                PMAssistReleaseVersion.AppCode.ErrorLogging.clsErrorLogging.LogError(ex.Message, "AddTaskDetails.aspx.cs", "GetTaskDate()");
                lblError.Text = "Failed";
            }

        }
    }
}