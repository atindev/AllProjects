﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace PMAssistReleaseVersion
{
    public partial class Manager : System.Web.UI.MasterPage
    {

        protected void Page_Load(object sender, EventArgs e)
        {
            try
            {

                if (Session["intUnsmPortalId"] == null)
                {
                    Response.Redirect("~/UI/Login.aspx", false);
                }
                else
                {
                    lblLogin.Text = "Loggedin as " + Session["intUnsmPortalId"].ToString();
                }
            }

            catch (Exception ex)
            {
                PMAssistReleaseVersion.AppCode.ErrorLogging.clsErrorLogging.LogError(ex.Message, "Manager.Master.cs", "Page_Load()");
            }
        }

        protected void btnOkManagerMaster_Click(object sender, EventArgs e)
        {
            try
            {
                TextBox txtPortalIdAddUserContentPlaceHolder = (TextBox)this.ContentPlaceHolderMaster.FindControl("txtPortalId");
                Response.Redirect("~/UI/Manager/AddUsers.aspx?ViewUserDetails=" + txtPortalIdAddUserContentPlaceHolder.Text, false);
            }
            catch (Exception ex)
            {
                PMAssistReleaseVersion.AppCode.ErrorLogging.clsErrorLogging.LogError(ex.Message, "Manager.Master.cs", "btnOkManagerMaster_Click()");
            }

        }

        protected void lnkManagerSignOut_Click(object sender, EventArgs e)
        {
            try
            {
                if (Session["intUnsmPortalId"] != null)
                {
                    Session.Clear();
                    Response.Redirect("~/UI/Logout.aspx");
                }
            }
            catch (Exception ex)
            {
                PMAssistReleaseVersion.AppCode.ErrorLogging.clsErrorLogging.LogError(ex.Message, "Manager.Master.cs", "lnkManagerSignOut_Click()");
            }

        }

        protected void lnkManagerAddResource_Click(object sender, EventArgs e)
        {
            try
            {
                Response.Redirect("~/UI/Manager/AddUsers.aspx");
            }

            catch (Exception ex)
            {
                PMAssistReleaseVersion.AppCode.ErrorLogging.clsErrorLogging.LogError(ex.Message, "Manager.Master.cs", "lnkManagerAddResource_Click()");
            }
        }

        protected void lnkManagerSearchResource_Click(object sender, EventArgs e)
        {
            try
            {
                Response.Redirect("~/UI/Manager/SearchUsers.aspx");
            }
            catch (Exception ex)
            {
                PMAssistReleaseVersion.AppCode.ErrorLogging.clsErrorLogging.LogError(ex.Message, "Manager.Master.cs", "lnkManagerSearchResource_Click()");
            }

        }

        protected void lnkManagerGenerateReports_Click(object sender, EventArgs e)
        {
            try
            {
                Response.Redirect("~/UI/Manager/GenerateReports.aspx");
            }

            catch (Exception ex)
            {
                PMAssistReleaseVersion.AppCode.ErrorLogging.clsErrorLogging.LogError(ex.Message, "Manager.Master.cs", "lnkManagerGenerateReports_Click()");
            }
        }

        protected void lnkManagerResetPassword_Click(object sender, EventArgs e)
        {
            try
            {
                Response.Redirect("~/UI/ResetPassword.aspx");
            }

            catch (Exception ex)
            {
                PMAssistReleaseVersion.AppCode.ErrorLogging.clsErrorLogging.LogError(ex.Message, "Manager.Master.cs", "lnkManagerResetPassword_Click()");
            }

        }

        protected void lnkManagerUtilizationReport_Click(object sender, EventArgs e)
        {
            try
            {
                Response.Redirect("~/UI/Resource/SearchTasks.aspx");
            }
            catch (Exception ex)
            {
                PMAssistReleaseVersion.AppCode.ErrorLogging.clsErrorLogging.LogError(ex.Message, "Manager.Master.cs", "lnkManagerUtilizationReport_Click()");
            }

        }

        protected void lnkSLACalculator_Click(object sender, EventArgs e)
        {
            try
            {
                Response.Redirect("~/UI/SlaCalculator.aspx", true);
            }

            catch (Exception ex)
            {
                PMAssistReleaseVersion.AppCode.ErrorLogging.clsErrorLogging.LogError(ex.Message, "Manager.Master.cs", "lnkSLACalculator_Click()");
            }
        }
    }
}
