﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace PMAssistRelease1._0.UI.Resource
{
    public partial class ResourceDashboard : System.Web.UI.Page
    {
        protected void Page_PreInit(object sender, EventArgs e)
        {
            try
            {
                if (Session["LoginType"] != null)
                {
                    clsGeneral.SetMasterPage(this.Page);
                }
            }

            catch (Exception ex)
            {
                PMAssistReleaseVersion.AppCode.ErrorLogging.clsErrorLogging.LogError(ex.Message, "ResourceDashboard.aspx.cs", "Page_PreInit()");

            }
        }
        protected void Page_Load(object sender, EventArgs e)
        {
            Response.Redirect("~/UI/SlaCalculator.aspx", true);
        }
    }
}