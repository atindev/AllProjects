﻿using System;
using System.Collections.Generic;
using System.Text;

namespace WAS.Application.Features.Group.Active
{
    public class Response
    {
        /// <summary>
        /// Is group update success
        /// </summary>
        public bool Success { get; set; }
    }
}
