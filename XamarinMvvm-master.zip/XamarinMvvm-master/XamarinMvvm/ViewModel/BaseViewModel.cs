﻿using System;
using XamarinMvvm.Common;

namespace XamarinMvvm.ViewModel
{
    public class BaseViewModel:NotifyPropertyChanged
    {
        public BaseViewModel()
        {
        }
    }
}
