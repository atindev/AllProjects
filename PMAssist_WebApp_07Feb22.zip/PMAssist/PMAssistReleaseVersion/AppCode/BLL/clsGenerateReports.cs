﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
//Add
using System.IO;
using PMAssistReleaseVersion.UI.Manager;
using PMAssistReleaseVersion.AppCode.Generic;

namespace PMAssistReleaseVersion.AppCode.BLL
{
    public class clsGenerateReports
    {
        public static string ConsolidatedStatusReport(string strReferenceNumber, string strModule, string strFromDate, string strToDate, string strCOType, string strTicketType, string strStatus, string strAssignedTo)
        {
            ExcelAppExportor<ConsolidatedReportExcelEntities> exportorConsolidatedTracker = new ExcelAppExportor<ConsolidatedReportExcelEntities>();
            string strExportFileName = string.Empty;
            try
            {

                exportorConsolidatedTracker.BindDataList = clsReports.ConsolidatedStatusReportExcelList(strReferenceNumber, strModule, strFromDate, strToDate, strCOType, strTicketType, strStatus, strAssignedTo);
                //New Consolidated Tracker Code
                exportorConsolidatedTracker.AddExportColumn(new ExportColumn("ReferenceNumber", "Reference No", 4, 1));
                exportorConsolidatedTracker.AddExportColumn(new ExportColumn("CoNumber", "Co Number", 4, 2));
                exportorConsolidatedTracker.AddExportColumn(new ExportColumn("PriorityId", "Priority", 4, 3));
                exportorConsolidatedTracker.AddExportColumn(new ExportColumn("TicketType", "Type", 4, 4));
                exportorConsolidatedTracker.AddExportColumn(new ExportColumn("Complexity", "Complexity", 4, 5));
                exportorConsolidatedTracker.AddExportColumn(new ExportColumn("ModuleName", "Application", 4, 6));
                exportorConsolidatedTracker.AddExportColumn(new ExportColumn("IncidentCategory", "Module", 4, 7));
                exportorConsolidatedTracker.AddExportColumn(new ExportColumn("Description", "Description", 4, 8));
                exportorConsolidatedTracker.AddExportColumn(new ExportColumn("OriginOfDefect", "Origin/Reason Of Defect", 4, 9));
                exportorConsolidatedTracker.AddExportColumn(new ExportColumn("TicketStatus", "Current Status", 4, 10));
                exportorConsolidatedTracker.AddExportColumn(new ExportColumn("AssignedTo", "Assigned To", 4, 11));
                exportorConsolidatedTracker.AddExportColumn(new ExportColumn("ReviewedBy", "Peer Review", 4, 12));
                exportorConsolidatedTracker.AddExportColumn(new ExportColumn("ReceivedDateTime", "Date/Time Recd", 4, 13));
                exportorConsolidatedTracker.AddExportColumn(new ExportColumn("ResponseDateTime", "Date/Time Response", 4, 14));
                exportorConsolidatedTracker.AddExportColumn(new ExportColumn("TargetDate", "Target Completion Date", 4, 15));
                exportorConsolidatedTracker.AddExportColumn(new ExportColumn("KPIDate", "KPI Date", 4, 16));
                exportorConsolidatedTracker.AddExportColumn(new ExportColumn("DateOfPeerReview", "Date Of Peer Review", 4, 17));
                exportorConsolidatedTracker.AddExportColumn(new ExportColumn("ResolvedDate", "Actual Completion Date", 4, 18));
                exportorConsolidatedTracker.AddExportColumn(new ExportColumn("ActualEffort", "Actual Effort", 4, 19));
                //Elapsed Days
                exportorConsolidatedTracker.AddExportColumn(new ExportColumn("StatusCommentary", "Status Commentary", 4, 21));
                exportorConsolidatedTracker.AddExportColumn(new ExportColumn("ReasonForRejection", "Reason for Rejection (If Re-ocurred incident)", 4, 22));
                exportorConsolidatedTracker.AddExportColumn(new ExportColumn("OnHoldTime", "Reference No", 4, 23));

                strExportFileName = Path.Combine(clsGeneral.GetDadeValueByType("Reports Generation Path"), Guid.NewGuid().ToString("N")) + ".xlsm";
                string strTemplateFileName = HttpContext.Current.Request.PhysicalApplicationPath;
                if (!strTemplateFileName.EndsWith("\\"))
                    strTemplateFileName = strTemplateFileName + "\\";
                //Template file name
                strTemplateFileName = strTemplateFileName + "Consolidated_Tracker.xlsm";

                exportorConsolidatedTracker.ExportFileName = strExportFileName;
                exportorConsolidatedTracker.TemplateFileName = strTemplateFileName;
                exportorConsolidatedTracker.IsExportIncludesHeader = false;
                exportorConsolidatedTracker.ExportSheetName = "Tracker";

                exportorConsolidatedTracker.Export(true);

            }
            catch (Exception ex)
            {
                PMAssistReleaseVersion.AppCode.ErrorLogging.clsErrorLogging.LogError(ex.Message, "clsGenerateReports.cs", "ConsolidatedStatusReport()");
            }
            return strExportFileName;
        }

        public static string SlaCharismaKpiSheet(int month, int year)
        {
            string strExportFileName = string.Empty;
            try
            {
                ExcelAppExportor<SLACharismaKpi> exportor = new ExcelAppExportor<SLACharismaKpi>();
                exportor.BindDataList = clsReports.SlaCharismaKpi(month, year);

                exportor.AddExportColumn(new ExportColumn("Target", "Target", 10, 4));
                exportor.AddExportColumn(new ExportColumn("CurrentMonthAchieved", "Current Month Achieved", 10, 5));
                exportor.AddExportColumn(new ExportColumn("CurrentMonthVolume", "Current Month Volume", 10, 6));
                exportor.AddExportColumn(new ExportColumn("LastMonthAchieved", "Last Month Achieved", 10, 8));
                exportor.AddExportColumn(new ExportColumn("LastMonthVolume", "Last Month Volume", 10, 9));
                exportor.AddExportColumn(new ExportColumn("SlaCurrentMonth", "Current Month", 8, 5));
                exportor.AddExportColumn(new ExportColumn("SlaLastMonth", "Last Month", 8, 8));
                exportor.AddExportColumn(new ExportColumn("SlaFromDate", "From Date", 1, 10));
                exportor.AddExportColumn(new ExportColumn("SlaToDate", "To Date", 2, 10));

                strExportFileName = Path.Combine(clsGeneral.GetDadeValueByType("Reports Generation Path"), Guid.NewGuid().ToString("N")) + ".xlsx";
                string strTemplateFileName = HttpContext.Current.Request.PhysicalApplicationPath;
                if (!strTemplateFileName.EndsWith("\\"))
                    strTemplateFileName = strTemplateFileName + "\\";

                //Template file is placed in the following folder --C:\Excelmport\Export\Export\ExportToTemplateExcel
                strTemplateFileName = strTemplateFileName + "KPI_Charisma_(End-to-End).xlsx";

                exportor.ExportFileName = strExportFileName;
                exportor.TemplateFileName = strTemplateFileName;
                exportor.IsExportIncludesHeader = false;
                exportor.ExportSheetName = "Charisma_KPI";

                exportor.Export(false);

            }
            catch (Exception ex)
            {
                PMAssistReleaseVersion.AppCode.ErrorLogging.clsErrorLogging.LogError(ex.Message, "GenerateReports.aspx.cs", "SlaCharismaKpiSheet()");
            }
            return strExportFileName;
        }

        public static string SlaResolvedTicketDetails(string GeneratedSlaCharismaKpiFileName, int month, int year)
        {
            string strExportFileName = string.Empty;
            try
            {
                ExcelAppExportor<SLAResolvedTicketsDetails> exportor = new ExcelAppExportor<SLAResolvedTicketsDetails>();
                exportor.BindDataList = clsReports.SlaResolvedTicketDetails(month, year);

                exportor.AddExportColumn(new ExportColumn("SlNo", "SlNo", 2, 1));
                exportor.AddExportColumn(new ExportColumn("ReferenceNo", "Reference No", 2, 2));
                exportor.AddExportColumn(new ExportColumn("IncidentChangeProblem", "Incident/Change/Problem", 2, 3));
                exportor.AddExportColumn(new ExportColumn("Type", "Type", 2, 4));
                exportor.AddExportColumn(new ExportColumn("Priority", "Priority", 2, 5));
                exportor.AddExportColumn(new ExportColumn("AssignedDate", "Assigned Date", 2, 6));
                exportor.AddExportColumn(new ExportColumn("ResolvedDate", "Resolved Date", 2, 7));
                exportor.AddExportColumn(new ExportColumn("TargetDate", "Target Date", 2, 8));
                exportor.AddExportColumn(new ExportColumn("InternalKpisMet", "Internal Kpis Met", 2, 9));
                exportor.AddExportColumn(new ExportColumn("EndToEndKpisMet", "End To End Kpis Met", 2, 10));
                exportor.AddExportColumn(new ExportColumn("Comments", "Comments", 2, 11));

                strExportFileName = Path.Combine(clsGeneral.GetDadeValueByType("Reports Generation Path"), Guid.NewGuid().ToString("N")) + ".xlsx";
                exportor.ExportFileName = strExportFileName;
                exportor.TemplateFileName = GeneratedSlaCharismaKpiFileName;
                exportor.IsExportIncludesHeader = false;
                exportor.ExportSheetName = "Resolved Tickets Details";

                exportor.Export(false);
            }
            catch (Exception ex)
            {
                PMAssistReleaseVersion.AppCode.ErrorLogging.clsErrorLogging.LogError(ex.Message, "GenerateReports.aspx.cs", "SlaResolvedTicketDetails()");
            }
            return strExportFileName;
        }

        public static string WsrPriorityTicketTypeDataPopulation(string generatedWsrFileName, DateTime selectedDate, string application)
        {
            string strWsrExportFileName = string.Empty;
            try
            {
                ExcelAppExportor<ExcelEntitites> exportor = new ExcelAppExportor<ExcelEntitites>();

                exportor.BindDataList = clsReports.WsrExcelList(selectedDate, application);
                // To Load Priority data 
                int incidentsCount = exportor.BindDataList.Count(i => i.IncidentInsertNewLine == "Incident");
                int changeCount = exportor.BindDataList.Count(i => i.ChangeInsertNewLine == "Change");
                int incidentStartRowIndex = 42;
                //int ChangeStartRowIndex = incidentStartRowIndex + incidentsCount + 2;
                //int ProblemStartRowIndex = ChangeStartRowIndex + changeCount + 4;
                int ChangeStartRowIndex = 111;
                int ProblemStartRowIndex = 203;

                // Here   "P1" is column name and "P1" is headertext in excel ,  21 is Row Index, 2 is Column Index
                exportor.AddExportColumn(new ExportColumn("ReportDate", "Report Date:", 4, 2));
                exportor.AddExportColumn(new ExportColumn("From", "From:", 4, 5));
                exportor.AddExportColumn(new ExportColumn("To", "To:", 4, 8));
                exportor.AddExportColumn(new ExportColumn("Status", "Status:", 5, 2));

                //Bind Priority information
                exportor.AddExportColumn(new ExportColumn("P1_Outstanding", "P1", 21, 3));
                exportor.AddExportColumn(new ExportColumn("P2_Outstanding", "P2", 21, 4));
                exportor.AddExportColumn(new ExportColumn("P3_Outstanding", "P3", 21, 5));
                exportor.AddExportColumn(new ExportColumn("P4_Outstanding", "P4", 21, 6));
                exportor.AddExportColumn(new ExportColumn("P5_Outstanding", "P5", 21, 7));

                exportor.AddExportColumn(new ExportColumn("P1_Current", "P1", 22, 3));
                exportor.AddExportColumn(new ExportColumn("P2_Current", "P2", 22, 4));
                exportor.AddExportColumn(new ExportColumn("P3_Current", "P3", 22, 5));
                exportor.AddExportColumn(new ExportColumn("P4_Current", "P4", 22, 6));
                exportor.AddExportColumn(new ExportColumn("P5_Current", "P5", 22, 7));

                exportor.AddExportColumn(new ExportColumn("P1_Resolved", "P1", 23, 3));
                exportor.AddExportColumn(new ExportColumn("P2_Resolved", "P2", 23, 4));
                exportor.AddExportColumn(new ExportColumn("P3_Resolved", "P3", 23, 5));
                exportor.AddExportColumn(new ExportColumn("P4_Resolved", "P4", 23, 6));
                exportor.AddExportColumn(new ExportColumn("P5_Resolved", "P5", 23, 7));

                exportor.AddExportColumn(new ExportColumn("P1_Worked", "P1", 24, 3));
                exportor.AddExportColumn(new ExportColumn("P2_Worked", "P2", 24, 4));
                exportor.AddExportColumn(new ExportColumn("P3_Worked", "P3", 24, 5));
                exportor.AddExportColumn(new ExportColumn("P4_Worked", "P4", 24, 6));
                exportor.AddExportColumn(new ExportColumn("P5_Worked", "P5", 24, 7));

                exportor.AddExportColumn(new ExportColumn("P1_DiffTeam", "P1", 25, 3));
                exportor.AddExportColumn(new ExportColumn("P2_DiffTeam", "P2", 25, 4));
                exportor.AddExportColumn(new ExportColumn("P3_DiffTeam", "P3", 25, 5));
                exportor.AddExportColumn(new ExportColumn("P4_DiffTeam", "P4", 25, 6));
                exportor.AddExportColumn(new ExportColumn("P5_DiffTeam", "P5", 25, 7));

                exportor.AddExportColumn(new ExportColumn("P1_Pending", "P1", 26, 3));
                exportor.AddExportColumn(new ExportColumn("P2_Pending", "P2", 26, 4));
                exportor.AddExportColumn(new ExportColumn("P3_Pending", "P3", 26, 5));
                exportor.AddExportColumn(new ExportColumn("P4_Pending", "P4", 26, 6));
                exportor.AddExportColumn(new ExportColumn("P5_Pending", "P5", 26, 7));

                exportor.AddExportColumn(new ExportColumn("P1_Problem", "P1", 27, 3));
                exportor.AddExportColumn(new ExportColumn("P2_Problem", "P2", 27, 4));
                exportor.AddExportColumn(new ExportColumn("P3_Problem", "P3", 27, 5));
                exportor.AddExportColumn(new ExportColumn("P4_Problem", "P4", 27, 6));
                exportor.AddExportColumn(new ExportColumn("P5_Problem", "P5", 27, 7));

                //Bind Incident Details Data
                exportor.AddExportColumn(new ExportColumn("IncidentReferenceNumber", "Ref No", incidentStartRowIndex, 2));
                exportor.AddExportColumn(new ExportColumn("IncidentTicketType", "Incident /Change", incidentStartRowIndex, 3));
                exportor.AddExportColumn(new ExportColumn("IncidentPriority", "Priority", incidentStartRowIndex, 4));
                exportor.AddExportColumn(new ExportColumn("IncidentStatus", "Status", incidentStartRowIndex, 5));
                exportor.AddExportColumn(new ExportColumn("IncidentTypeInDetail", "Type", incidentStartRowIndex, 6));
                exportor.AddExportColumn(new ExportColumn("IncidentDescription", "Description", incidentStartRowIndex, 7));
                exportor.AddExportColumn(new ExportColumn("IncidentAssignedDate", "Start Date", incidentStartRowIndex, 8));
                exportor.AddExportColumn(new ExportColumn("IncidentResolvedDate", "End Date", incidentStartRowIndex, 9));
                exportor.AddExportColumn(new ExportColumn("IncidentComments", "Comments", incidentStartRowIndex, 10));
                //exportor.AddExportColumn(new ExportColumn("IncidentInsertNewLine", "InsertNewLine", incidentStartRowIndex, 11));

                //Bind Change Details Data
                exportor.AddExportColumn(new ExportColumn("ChangeReferenceNumber", "Ref No", ChangeStartRowIndex, 2));
                exportor.AddExportColumn(new ExportColumn("ChangeTicketType", "Incident /Change", ChangeStartRowIndex, 3));
                exportor.AddExportColumn(new ExportColumn("ChangePrtyPriority", "Priority", ChangeStartRowIndex, 4));
                exportor.AddExportColumn(new ExportColumn("ChangeTicketStatus", "Status", ChangeStartRowIndex, 5));
                exportor.AddExportColumn(new ExportColumn("ChangeTicketTypeInDetail", "Type", ChangeStartRowIndex, 6));
                exportor.AddExportColumn(new ExportColumn("ChangeTcktDescription", "Description", ChangeStartRowIndex, 7));
                exportor.AddExportColumn(new ExportColumn("ChangeTcktAssignedDate", "Start Date", ChangeStartRowIndex, 8));
                exportor.AddExportColumn(new ExportColumn("ChangeTcktResolvedDate", "End Date", ChangeStartRowIndex, 9));
                exportor.AddExportColumn(new ExportColumn("ChangeTcktComments", "Comments", ChangeStartRowIndex, 10));
                //exportor.AddExportColumn(new ExportColumn("ChangeInsertNewLine", "InsertNewLine", ChangeStartRowIndex, 11));

                //Bind Problem Details Data
                exportor.AddExportColumn(new ExportColumn("ProblemReferenceNumber", "Ref No", ProblemStartRowIndex, 2));
                exportor.AddExportColumn(new ExportColumn("ProblemTicketType", "Incident /Change", ProblemStartRowIndex, 3));
                exportor.AddExportColumn(new ExportColumn("ProblemPrtyPriority", "Priority", ProblemStartRowIndex, 4));
                exportor.AddExportColumn(new ExportColumn("ProblemTicketStatus", "Status", ProblemStartRowIndex, 5));
                exportor.AddExportColumn(new ExportColumn("ProblemTicketTypeInDetail", "Type", ProblemStartRowIndex, 6));
                exportor.AddExportColumn(new ExportColumn("ProblemTcktDescription", "Description", ProblemStartRowIndex, 7));
                exportor.AddExportColumn(new ExportColumn("ProblemTcktAssignedDate", "Start Date", ProblemStartRowIndex, 8));
                exportor.AddExportColumn(new ExportColumn("ProblemTcktResolvedDate", "End Date", ProblemStartRowIndex, 9));
                exportor.AddExportColumn(new ExportColumn("ProblemTcktComments", "Comments", ProblemStartRowIndex, 10));
               // exportor.AddExportColumn(new ExportColumn("ProblemInsertNewLine", "InsertNewLine", ProblemStartRowIndex, 11));

                strWsrExportFileName = Path.Combine(clsGeneral.GetDadeValueByType("Reports Generation Path"), Guid.NewGuid().ToString("N")) + ".xlsx";
                exportor.ExportFileName = strWsrExportFileName;
                exportor.TemplateFileName = generatedWsrFileName;
                exportor.IsExportIncludesHeader = false;
                exportor.ExportSheetName = application;

                exportor.Export(true);
            }
            catch (Exception ex)
            {
                PMAssistReleaseVersion.AppCode.ErrorLogging.clsErrorLogging.LogError(ex.Message, "GenerateReports.aspx.cs", "WsrPriorityTicketTypeDataPopulation()");
            }
            return strWsrExportFileName;
        }

        public static string WsrGraphsDataTabPopulation(DateTime selectedDate)
        {
            string strWsrExportFileName = string.Empty;
            try
            {
                ExcelAppExportor<WSRGraphEntities> exportor = new ExcelAppExportor<WSRGraphEntities>();
                exportor.BindDataList = clsReports.WsrGraphsData(selectedDate);
                //Charisma Graph Entities
                exportor.AddExportColumn(new ExportColumn("charismaOutStanding", "Tickets carried forward from previous week", 4, 3));
                exportor.AddExportColumn(new ExportColumn("charismaCurrentWeek", "Tickets received during the week", 4, 4));
                exportor.AddExportColumn(new ExportColumn("charismaResolved", "No of tickets resolved", 12, 3));
                exportor.AddExportColumn(new ExportColumn("charismaWorked", "No of tickets worked", 12, 4));
                exportor.AddExportColumn(new ExportColumn("charismaAssignedToDifferentTeam", "Transferred to other team", 12, 5));
                exportor.AddExportColumn(new ExportColumn("charismaWeekEnding", "Week Ending", 4, 2));
                exportor.AddExportColumn(new ExportColumn("charismaWeekEnding", "Week Ending", 12, 2));
                exportor.AddExportColumn(new ExportColumn("charismaWeekEnding", "Week Ending", 4, 8));
                exportor.AddExportColumn(new ExportColumn("charismaStatusWIP", "WIP", 4, 9));
                exportor.AddExportColumn(new ExportColumn("charismaStatusPendingUAT", "Pending UAT", 4, 10));
                exportor.AddExportColumn(new ExportColumn("charismaStatusHold", "Hold/ SME Peer Review", 4, 11));
                exportor.AddExportColumn(new ExportColumn("charismaStatusPIR", "Post Implementation Review", 4, 12));
                exportor.AddExportColumn(new ExportColumn("charismaStatusYetToStart", "Yet To Start", 4, 13));
                exportor.AddExportColumn(new ExportColumn("charismaStatusRFC", "RFC Required", 4, 14));
                exportor.AddExportColumn(new ExportColumn("charismaStatusRFR", "Ready For Release", 4, 15));
                //Fred Graph Entities
                exportor.AddExportColumn(new ExportColumn("fredOutStanding", "Tickets carried forward from previous week", 32, 3));
                exportor.AddExportColumn(new ExportColumn("fredCurrentWeek", "Tickets received during the week", 32, 4));
                exportor.AddExportColumn(new ExportColumn("fredResolved", "No of tickets resolved", 40, 3));
                exportor.AddExportColumn(new ExportColumn("fredWorked", "No of tickets worked", 40, 4));
                exportor.AddExportColumn(new ExportColumn("fredAssignedToDifferentTeam", "Transferred to other team", 40, 5));
                exportor.AddExportColumn(new ExportColumn("fredWeekEnding", "Week Ending", 32, 2));
                exportor.AddExportColumn(new ExportColumn("fredWeekEnding", "Week Ending", 40, 2));
                exportor.AddExportColumn(new ExportColumn("fredWeekEnding", "Week Ending", 32, 8));
                exportor.AddExportColumn(new ExportColumn("fredStatusWIP", "WIP", 32, 9));
                exportor.AddExportColumn(new ExportColumn("fredStatusPendingUAT", "Pending UAT", 32, 10));
                exportor.AddExportColumn(new ExportColumn("fredStatusHold", "Hold/ SME Peer Review", 32, 11));
                exportor.AddExportColumn(new ExportColumn("fredStatusPIR", "Post Implementation Review", 32, 12));
                exportor.AddExportColumn(new ExportColumn("fredStatusYetToStart", "Yet To Start", 32, 13));
                exportor.AddExportColumn(new ExportColumn("fredStatusRFC", "RFC Required", 32, 14));
                exportor.AddExportColumn(new ExportColumn("fredStatusRFR", "Ready For Release", 32, 15));
                //Share Point Graph Entities
                exportor.AddExportColumn(new ExportColumn("sharepointOutStanding", "Tickets carried forward from previous week", 60, 3));
                exportor.AddExportColumn(new ExportColumn("sharepointCurrentWeek", "Tickets received during the week", 60, 4));
                exportor.AddExportColumn(new ExportColumn("sharepointResolved", "No of tickets resolved", 68, 3));
                exportor.AddExportColumn(new ExportColumn("sharepointWorked", "No of tickets worked", 68, 4));
                exportor.AddExportColumn(new ExportColumn("sharepointAssignedToDifferentTeam", "Transferred to other team", 68, 5));
                exportor.AddExportColumn(new ExportColumn("sharepointWeekEnding", "Week Ending", 60, 2));
                exportor.AddExportColumn(new ExportColumn("sharepointWeekEnding", "Week Ending", 68, 2));
                exportor.AddExportColumn(new ExportColumn("sharepointWeekEnding", "Week Ending", 60, 8));
                exportor.AddExportColumn(new ExportColumn("sharepointStatusWIP", "WIP", 60, 9));
                exportor.AddExportColumn(new ExportColumn("sharepointStatusPendingUAT", "Pending UAT", 60, 10));
                exportor.AddExportColumn(new ExportColumn("sharepointStatusHold", "Hold/ SME Peer Review", 60, 11));
                exportor.AddExportColumn(new ExportColumn("sharepointStatusPIR", "Post Implementation Review", 60, 12));
                exportor.AddExportColumn(new ExportColumn("sharepointStatusYetToStart", "Yet To Start", 60, 13));
                exportor.AddExportColumn(new ExportColumn("sharepointStatusRFC", "RFC Required", 60, 14));
                exportor.AddExportColumn(new ExportColumn("sharepointStatusRFR", "Ready For Release", 60, 15));

                strWsrExportFileName = Path.Combine(clsGeneral.GetDadeValueByType("Reports Generation Path"), Guid.NewGuid().ToString("N")) + ".xlsx";
                string strTemplateFileName = HttpContext.Current.Request.PhysicalApplicationPath;
                if (!strTemplateFileName.EndsWith("\\"))
                    strTemplateFileName = strTemplateFileName + "\\";

                //Template file is placed in the following folder --C:\Excelmport\Export\Export\ExportToTemplateExcel
                strTemplateFileName = strTemplateFileName + "WSR_Template.xlsx";

                exportor.ExportFileName = strWsrExportFileName;
                exportor.TemplateFileName = strTemplateFileName;
                exportor.IsExportIncludesHeader = false;
                exportor.ExportSheetName = "Sheet1";

                exportor.Export(false);
            }
            catch (Exception ex)
            {
                PMAssistReleaseVersion.AppCode.ErrorLogging.clsErrorLogging.LogError(ex.Message, "GenerateReports.aspx.cs", "WsrGraphsDataTabPopulation()");
            }
            return strWsrExportFileName;
        }

        public static void ClearServerReports()
        {
            try
            {
                string[] files = Directory.GetFiles(clsGeneral.GetDadeValueByType("Reports Generation Path"));
                foreach (string file in files)
                {
                    FileInfo fileInfo = new FileInfo(file);
                    fileInfo.Delete();
                }
            }
            catch (Exception ex)
            {
                PMAssistReleaseVersion.AppCode.ErrorLogging.clsErrorLogging.LogError(ex.Message, "GenerateReports.aspx.cs", "ClearServerReports()");
            }
        }
    }
}