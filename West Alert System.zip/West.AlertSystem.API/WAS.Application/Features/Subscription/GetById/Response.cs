﻿using System;
using System.Collections.Generic;
using System.Text;

namespace WAS.Application.Features.Subscription.GetById
{
    public class Response : Common.Models.SubscriptionDetails
    {
 
    }
}
