﻿namespace WAS.Application.Common.Constants
{
    public static class Constants
    {
        public static readonly string CLONE="-Clone";
    }
}
