﻿using System.Collections.Generic;

namespace WAS.Application.Features.Group.GetCount
{
    public class Response
    {
        /// <summary>
        /// Count of All Gropus
        /// </summary>
        public int Count { get; set; }

    }
}
