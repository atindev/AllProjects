﻿namespace WAS.Application.Features.IncomingMessage.GetById
{
    public class Response
    {
        /// <summary>
        /// IncomingMessage details
        /// </summary>
        public Common.Models.IncomingMessage IncomingMessage { get; set; }

    }
}
