﻿using WAS.Application.Common.Models;

namespace WAS.Application.Features.Group.GetGroupSubscriberCount
{
    public class Response : GroupSubscribers
    {
    }
}
