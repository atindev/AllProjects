﻿using System;
using System.Collections.Generic;
using System.Text;

namespace WAS.Application.Features.Subscription.SubscriptionFeedback
{
    public class Response
    {
        /// <summary>
        /// Is feedback captured successfully
        /// </summary>
        public bool Success { get; set; }
    }
}
