﻿using System.Collections.Generic;

namespace WAS.Application.Features.Notification.GetCount
{
    public class Response
    {
        /// <summary>
        /// Count of All Notification
        /// </summary>
        public int Count { get; set; }

    }
}
