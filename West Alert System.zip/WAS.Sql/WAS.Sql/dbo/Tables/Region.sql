﻿CREATE TABLE [dbo].[Region] (
    [Id]   INT          NOT NULL,
    [Name] VARCHAR (50) NULL,
    CONSTRAINT [PK_Region] PRIMARY KEY CLUSTERED ([Id] ASC)
);

