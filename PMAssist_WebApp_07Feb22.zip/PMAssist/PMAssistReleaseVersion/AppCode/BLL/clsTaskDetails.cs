﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace PMAssistReleaseVersion.AppCode.Generic
{
    public class clsTaskDetails
    {
        public int TaskId { get; set; }
        public string TaskReference { get; set; }
        public string TaskDate { get; set; }
        public string PrimaryActivityId { get; set; }
        public string SecondaryActivityId { get; set; }
        public string Task { get; set; }
        public string TaskDescription { get; set; }
        public string TaskHours { get; set; }
        public string TaskRemarks { get; set; }
        public string TaskStatus { get; set; }
        public string TaskDeleted { get; set; }
        public string EntryId { get; set; }
        public string EntryDate { get; set; }
        public string LastChangedId { get; set; }
        public string LastChangedDate { get; set; }
        
    }
}