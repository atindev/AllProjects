﻿using System.Collections.Generic;

namespace WAS.Application.Features.Subscription.GetCount
{
    public class Response
    {
        /// <summary>
        /// Count of All Peoples
        /// </summary>
        public int Count { get; set; }

    }
}
