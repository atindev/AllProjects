﻿using Microsoft.ApplicationBlocks.Data;
using PMAssistReleaseVersion.AppCode.Generic;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;

namespace PMAssistReleaseVersion.AppCode
{
    public class clsTaskInformation
    {
        //LoadTaskDetails
        public static clsTaskDetails LoadTaskDetailsByReference(string TaskReference)
        {
            SqlCommand cmd = new SqlCommand();
            cmd.CommandText = "spLoadTaskDetailsByReference";
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@ReferenceNumber", TaskReference);
            DataSet dsTaskDetails = SqlHelper.ExecuteDataset(clsGeneral.ConStr, cmd.CommandType, cmd.CommandText, cmd);
            var TaskDetails = new clsTaskDetails();
            if (dsTaskDetails != null && dsTaskDetails.Tables.Count > 0 && dsTaskDetails.Tables[0].Rows.Count > 0)
            {
                TaskDetails.TaskId = Convert.ToInt32(dsTaskDetails.Tables[0].Rows[0]["TaskId"].ToString());
                TaskDetails.TaskReference = dsTaskDetails.Tables[0].Rows[0]["ReferenceNumber"].ToString();
                TaskDetails.TaskDate = dsTaskDetails.Tables[0].Rows[0]["TaskDate"].ToString();
                TaskDetails.PrimaryActivityId = dsTaskDetails.Tables[0].Rows[0]["PrimaryActivity"].ToString();
                TaskDetails.SecondaryActivityId = dsTaskDetails.Tables[0].Rows[0]["SecondaryActivity"].ToString();
                TaskDetails.Task = dsTaskDetails.Tables[0].Rows[0]["Task"].ToString();
                TaskDetails.TaskDescription = dsTaskDetails.Tables[0].Rows[0]["TaskDescription"].ToString();
                TaskDetails.TaskHours = dsTaskDetails.Tables[0].Rows[0]["TaskHours"].ToString();
                TaskDetails.TaskRemarks = dsTaskDetails.Tables[0].Rows[0]["Remarks"].ToString();
                TaskDetails.TaskStatus = dsTaskDetails.Tables[0].Rows[0]["TaskStatus"].ToString();
                TaskDetails.TaskDeleted = dsTaskDetails.Tables[0].Rows[0]["Deleted"].ToString();
                TaskDetails.EntryId = dsTaskDetails.Tables[0].Rows[0]["TaskEntryId"].ToString();
            }
            return TaskDetails;
        }

        //Load IncidentChangeRequest data
        public static DataTable LoadPrimaryActivity()
        {
            DataSet ds = SqlHelper.ExecuteDataset(clsGeneral.ConStr, "spGetPrimaryActivityData");
            return ds.Tables[0];
        }

        //Load IncidentChangeRequest data
        public static DataTable LoadSecondaryActivity(int PrimaryActivityId)
        {
            SqlCommand cmd = new SqlCommand();
            cmd.Connection = new SqlConnection(clsGeneral.ConStr);
            cmd.Parameters.AddWithValue("@intPrimaryActivityId", PrimaryActivityId);
            cmd.CommandText = "spGetSecondaryActivityData";
            cmd.CommandType= CommandType.StoredProcedure;
            DataSet ds = SqlHelper.ExecuteDataset(clsGeneral.ConStr,cmd.CommandType,cmd.CommandText,cmd);
            return ds.Tables[0];
        }

        //Check whether the Reference Number exist or not 
        public static DataSet CheckTaskReferenceNumber(string TaskReferenceNumber)
        {
            try
            {
                SqlParameter[] par = new SqlParameter[1];
                par[0] = new SqlParameter("@ReferenceNumber", TaskReferenceNumber);
                return SqlHelper.ExecuteDataset(clsGeneral.ConStr, "spCheckTaskReference", par);
            }
            catch (Exception ex)
            {
                PMAssistReleaseVersion.AppCode.ErrorLogging.clsErrorLogging.LogError(ex.Message, "clsTaskInformation.cs", "CheckTaskReferenceNumber");
                throw;
            }

        }


        // To Add Ticket details into database 
        public static void AddTaskDetails(string referenceNumber, string date, int primaryActivity, int secondaryActivity, string task, string description, int hours, int status, string remarks,string entryId )
        {
            try
            {

                SqlParameter[] par = new SqlParameter[10];
                par[0] = new SqlParameter("@vchTaskReference", referenceNumber);
                par[1] = new SqlParameter("@vchTaskDate", date);
                par[2] = new SqlParameter("@sintTaskPrmyId", primaryActivity);
                par[3] = new SqlParameter("@sintTaskScacId", secondaryActivity);
                par[4] = new SqlParameter("@vchTask", task);
                par[5] = new SqlParameter("@vchTaskDescription", description);
                par[6] = new SqlParameter("@sintTaskHours", hours);
                par[7] = new SqlParameter("@vchTaskRemarks", remarks);
                par[8] = new SqlParameter("@sintTaskStatus", status);
                par[9] = new SqlParameter("@vchTaskEntryId", entryId);
                SqlHelper.ExecuteNonQuery(clsGeneral.ConStr, CommandType.StoredProcedure, "spAddTaskDetails", par);
            }

            catch (Exception ex)
            {
                PMAssistReleaseVersion.AppCode.ErrorLogging.clsErrorLogging.LogError(ex.Message, "clsTaskInformation.cs", "AddTaskDetails");
                throw;

            }

        }

        // To Update Ticket details in to database
        public static DataSet UpdateTaskDetailsByID(int ticketId, string referenceNumber, int primaryActivity, int secondaryActivity, string task, string description, int hours, int status, string remarks, string lastChangedId, string deleted)
        {
            try
            {
                SqlParameter[] par = new SqlParameter[11];
                par[0] = new SqlParameter("@intTaskId", ticketId);
                par[1] = new SqlParameter("@vchTaskReference", referenceNumber);
                par[2] = new SqlParameter("@sintTaskPrmyId", primaryActivity);
                par[3] = new SqlParameter("@sintTaskScacId", secondaryActivity);
                par[4] = new SqlParameter("@vchTask", task);
                par[5] = new SqlParameter("@vchTaskDescription", description);
                par[6] = new SqlParameter("@sintTaskHours", hours);
                par[7] = new SqlParameter("@vchTaskRemarks", remarks);
                par[8] = new SqlParameter("@sintTaskStatus", status);
                par[9] = new SqlParameter("@chTaskDeleted", deleted);
                par[10] = new SqlParameter("@vchTaskLastChangedId", lastChangedId);
                return SqlHelper.ExecuteDataset(clsGeneral.ConStr, "dbo.spUpdateTaskdetails", par);
            }
            catch (Exception ex)
            {
                PMAssistReleaseVersion.AppCode.ErrorLogging.clsErrorLogging.LogError(ex.Message, "clsTaskInformation.cs", "UpdateTaskDetailsByID");
                throw;
            }

        }

        public static string GetNewTaskReferenceByPortalIdTaskDate(string portalId,string taskDate)
        {
            SqlCommand cmd = new SqlCommand();
            cmd.Connection = new SqlConnection(clsGeneral.ConStr);
            cmd.CommandText = "dbo.spGetNewTaskReference";
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@vchPortalId", portalId);
            cmd.Parameters.AddWithValue("@vchTaskdate", taskDate);
            cmd.Parameters.Add("@vchNewTaskReference", SqlDbType.VarChar);
            cmd.Parameters["@vchNewTaskReference"].Size = -1;
            cmd.Parameters["@vchNewTaskReference"].Direction = ParameterDirection.Output;
            cmd.Connection.Open();
            cmd.ExecuteNonQuery();
            cmd.Connection.Close();
            var str = cmd.Parameters["@vchNewTaskReference"].Value.ToString();
            return str;        
        }
    }
}