﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace PMAssistReleaseVersion
{
    public partial class Login : System.Web.UI.MasterPage
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnOkMaster_Click(object sender, EventArgs e)
        {
            try
            {
                Session["intUnsmPortalId"] = null;
                Session["LoginType"] = null;
                Session["isFirstLogin"] = null;
                Session.Clear();
                Response.Cache.SetExpires(DateTime.UtcNow.AddMinutes(-1));
                Response.Cache.SetCacheability(HttpCacheability.NoCache);
                Response.Cache.SetNoStore();
                Response.Redirect("~/UI/Login.aspx", true);
            }

            catch (Exception ex)
            {
                PMAssistReleaseVersion.AppCode.ErrorLogging.clsErrorLogging.LogError(ex.Message, "Login.Master.cs", "btnOkMaster_Click()");
            }
        }
    }
}