﻿using System;
using System.Collections.Generic;
using System.Text;

namespace WAS.Application.Common.Enum
{
    public enum NotificationChannel
    {
       WhatsApp,
       Voice,
       Email,
       Text
    }
}
