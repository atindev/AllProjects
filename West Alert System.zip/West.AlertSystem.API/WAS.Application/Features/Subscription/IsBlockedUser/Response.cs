﻿namespace WAS.Application.Features.Subscription.IsBlockedUser
{
    public class Response
    {
        /// <summary>
        /// Is user is blocked or not
        /// </summary>
        public bool IsBlocked { get; set; }
        
    }
}
