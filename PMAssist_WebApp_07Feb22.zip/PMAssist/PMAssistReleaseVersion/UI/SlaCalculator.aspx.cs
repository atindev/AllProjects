﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
//Add
using PMAssistReleaseVersion.AppCode;
using PMAssistReleaseVersion.AppCode.Generic;
using System.Drawing;

namespace PMAssistReleaseVersion.UI.Resource
{
    public partial class SlaCalculator : System.Web.UI.Page
    {
        protected void Page_PreInit(object sender, EventArgs e)
        {
            try
            {
                if (Session["LoginType"] != null)
                {
                    clsGeneral.SetMasterPage(this.Page);
                }
            }
            catch (Exception ex)
            {
                PMAssistReleaseVersion.AppCode.ErrorLogging.clsErrorLogging.LogError(ex.Message, "SlaCalculator.aspx.cs", "Page_PreInit()");
            }
        }

        protected void Page_Load(object sender, EventArgs e)
        {
            try
            {
                bool isManager = HttpContext.Current.Session["LoginType"].ToString() == "Y";
                System.Data.DataTable dt = clsTicketInformation.GetTicketDetailsByPortalIdForSlaCalculation(isManager ? "0" : HttpContext.Current.Session["intUnsmPortalId"].ToString());
                gvSlaCalculator.DataSource = dt;
                gvSlaCalculator.DataBind();
                if (!isManager)
                    gvSlaCalculator.Columns.RemoveAt(dt.Columns.IndexOf("AssignedTo"));
                gvSlaCalculator.Columns.RemoveAt(gvSlaCalculator.Columns.Count - 1);
                gvSlaCalculator.DataSource = dt;
                gvSlaCalculator.DataBind();
            }
            catch (Exception ex)
            {
                PMAssistReleaseVersion.AppCode.ErrorLogging.clsErrorLogging.LogError(ex.Message, "SlaCalculator.aspx.cs", "Page_Load()");
            }
        }

        protected void gvSlaCalculator_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            try
            {
                if (e.Row.RowType == DataControlRowType.DataRow)
                {
                    if (DataBinder.Eval(e.Row.DataItem, "TicketStatusColor").ToString() == "R")
                        e.Row.BackColor = Color.FromArgb(255, 64, 64);
                    else if (DataBinder.Eval(e.Row.DataItem, "TicketStatusColor").ToString() == "Y")
                        e.Row.BackColor = Color.FromArgb(255, 255, 66);
                    else if (DataBinder.Eval(e.Row.DataItem, "TicketStatusColor").ToString() == "G")
                        e.Row.BackColor = Color.FromArgb(181, 255, 106);
                }
            }
            catch (Exception ex)
            {
                PMAssistReleaseVersion.AppCode.ErrorLogging.clsErrorLogging.LogError(ex.Message, "SlaCalculator.aspx.cs", "gvSlaCalculator_RowDataBound()");
            }
        }
    }
}