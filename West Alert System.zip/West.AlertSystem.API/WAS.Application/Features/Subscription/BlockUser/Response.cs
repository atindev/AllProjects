﻿namespace WAS.Application.Features.Subscription.BlockUser
{
    public class Response
    {
        /// <summary>
        /// Is user blocking success
        /// </summary>
        public bool Success { get; set; }
        
    }
}
