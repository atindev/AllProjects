﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace PMAssistReleaseVersion
{
    public partial class TimePicker : System.Web.UI.UserControl
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }
        public TextBox txtHoursControl
        {
            get { return txtTimeHours; }
        }
        public TextBox txtMinutesControl
        {
            get { return txtTimeMinutes; }
        }
        public TextBox txtSecondsControl
        {
            get { return txtTimeSeconds; }
        }
        public RangeValidator rgvHourRangeControl
        {
            get { return rgvHourRange; }
        }
        public RangeValidator rgvMinuteRangeControl
        {
            get { return rgvMinuteRange; }
        }
        public RangeValidator rgvSecondRangeControl
        {
            get { return rgvSecondRange; }
        }
        public RequiredFieldValidator rfvHourRequiredControl
        {
            get { return rfvHourRequired; }
        }
        public RequiredFieldValidator rfvMinuteRequiredControl
        {
            get { return rfvMinuteRequired; }
        }
        public RequiredFieldValidator rfvSecondRequiredControl
        {
            get { return rfvSecondRequired; }
        }
        public bool EnableTextBoxes
        {
            set
            {
                txtTimeHours.Enabled = value;
                txtTimeMinutes.Enabled = value;
                txtTimeSeconds.Enabled = value;
            }
        }
        public bool EnableRangeFieldValidators
        {
            set
            {
                rgvHourRange.Enabled = value;
                rgvMinuteRange.Enabled = value;
                rgvSecondRange.Enabled = value;
            }
        }
        public bool EnableRequiredFieldValidators
        {
            set
            {
                rfvHourRequired.Enabled = value;
                rfvMinuteRequired.Enabled = value;
                rfvSecondRequired.Enabled = value;
            }
        }

        public string TimeSet
        {
          get
            {
                if (!(string.IsNullOrEmpty(txtTimeHours.Text) && string.IsNullOrEmpty(txtTimeMinutes.Text) && string.IsNullOrEmpty(txtTimeSeconds.Text))) return txtTimeHours.Text.PadLeft(2,'0') + ":" + txtTimeMinutes.Text.PadLeft(2,'0') + ":" + txtTimeSeconds.Text.PadLeft(2,'0');
                return string.Empty;
            }
        }

        public string TimeGet
        {
            set
            {
                if (!(value == string.Empty))
                {
                    if (value.Length >= 2) txtTimeHours.Text = value.Substring(0, 2);
                    if (value.Length >= 5) txtTimeMinutes.Text = value.Substring(3, 2);
                    if (value.Length >= 8) txtTimeSeconds.Text = value.Substring(6, 2);
                }
                else
                {
                    ltrTimeHourMinuteSeparator.Visible = false;
                    ltrTimeMinuteSecondSeparator.Visible = false;
                }
            }
        }

        public void TextBoxAsLabel()
        {
            foreach (Control inputControl in this.Controls)
            {
                if (inputControl is TextBox)
                {
                    ((TextBox)inputControl).BackColor = System.Drawing.Color.Transparent;
                    ((TextBox)inputControl).Enabled = false;
                    ((TextBox)inputControl).BorderStyle = BorderStyle.None;
                }
            }
        }
    }
}