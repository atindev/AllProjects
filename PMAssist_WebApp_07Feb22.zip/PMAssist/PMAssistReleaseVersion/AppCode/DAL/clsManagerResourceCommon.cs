﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.SqlClient;

namespace PMAssistReleaseVersion.AppCode.Generic
{
    public class clsManagerResourceCommon
    {
        public static SqlCommand GetAllCommonCommandObjectParameters(string strReferenceNumber, string strModule, string strFromDate, string strToDate, string strCOType, string strTicketType, string strStatus, string strAssignedTo)
        {
                SqlCommand cmd = new SqlCommand();
                if (!string.IsNullOrEmpty(strReferenceNumber))
                {
                    cmd.Parameters.AddWithValue("@ReferenceNumber", strReferenceNumber);
                }
                if (!string.IsNullOrEmpty(strModule))
                {
                    cmd.Parameters.AddWithValue("@Module", Convert.ToInt32(strModule));
                }
                if (!string.IsNullOrEmpty(strFromDate))
                {
                    cmd.Parameters.AddWithValue("@FromDate", strFromDate);
                }
                if (!string.IsNullOrEmpty(strToDate))
                {
                    cmd.Parameters.AddWithValue("@ToDate", strToDate);
                }
                if (!(string.IsNullOrEmpty(strCOType)||strCOType=="0"))
                {
                    cmd.Parameters.AddWithValue("@COType", Convert.ToInt32(strCOType));
                }
                if (!string.IsNullOrEmpty(strTicketType))
                {
                    cmd.Parameters.AddWithValue("@TicketType", Convert.ToInt32(strTicketType));
                }
                if (!string.IsNullOrEmpty(strStatus))
                {
                    cmd.Parameters.AddWithValue("@Status", Convert.ToInt32(strStatus));
                }
                if (!string.IsNullOrEmpty(strAssignedTo))
                {
                    cmd.Parameters.AddWithValue("@AssignedTo", strAssignedTo);
                }
                cmd.Connection = new SqlConnection(clsGeneral.ConStr);
            return cmd;
        }

        // For Task Details 
        public static SqlCommand GetAllCommonCommandObjectParameters(string strTaskdate, string strResource)
        {
            SqlCommand cmd = new SqlCommand();

            if (!string.IsNullOrEmpty(strTaskdate))
            {
                cmd.Parameters.AddWithValue("@TaskDate", strTaskdate);
            }

            if (!string.IsNullOrEmpty(strResource))
            {
                cmd.Parameters.AddWithValue("@Resource", strResource);
            }
            cmd.Connection = new SqlConnection(clsGeneral.ConStr);
            return cmd;
        }
    }
}