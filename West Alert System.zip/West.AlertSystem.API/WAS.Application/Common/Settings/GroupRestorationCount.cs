﻿using Microsoft.Graph;
namespace WAS.Application.Common.Settings
{
    public class GroupRestorationCount
    {
        /// <summary>
        /// number of days
        /// </summary>
        public int DeletedGroupRententionDays { get; set; }
    }
}
