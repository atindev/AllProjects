using System;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Collections;
using System.Net.Mail;
using System.Text;
using System.IO;
using Microsoft.ApplicationBlocks.Data;

/// <summary>
/// Summary description for clsGeneral
/// </summary>
public class clsGeneral
{
    public static string ConStr = ConfigurationManager.AppSettings["PMASSISTConnectionString"].ToString();
    public static void SetMasterPage(Page curPage)
    {
        if (curPage.Session["LoginType"] != null)
        {
            if (curPage.Session["LoginType"].ToString() == "Y" && curPage.Session["isFirstLogin"].ToString() == "N")
            {
                curPage.MasterPageFile = curPage.MasterPageFile.Replace("Resource.Master", "Manager.Master");
                curPage.MasterPageFile = curPage.MasterPageFile.Replace("Login.Master", "Manager.Master");
            }
            else if (curPage.Session["LoginType"].ToString() == "N" && curPage.Session["isFirstLogin"].ToString() == "N")
            {
                curPage.MasterPageFile = curPage.MasterPageFile.Replace("Manager.Master", "Resource.master");
                curPage.MasterPageFile = curPage.MasterPageFile.Replace("Login.Master", "Resource.Master");
            }
            else if (curPage.Session["isFirstLogin"].ToString() == "Y")
            {
                curPage.MasterPageFile = curPage.MasterPageFile.Replace("Manager.Master", "Login.Master");
                curPage.MasterPageFile = curPage.MasterPageFile.Replace("Resource.Master", "Login.Master");
            }
        }
    }

    public static string GetDadeValueByType(string dadeType)
    {
        SqlCommand cmd = new SqlCommand();
        try
        {
            cmd.Connection = new SqlConnection(ConStr);
            cmd.CommandText = "spGetDadeValueByType";
            cmd.CommandType = System.Data.CommandType.StoredProcedure;
            SqlParameter[] par = new SqlParameter[2];
            cmd.Parameters.AddWithValue("@vchDadeType", dadeType);
            cmd.Parameters.Add("@vchDadeValue", SqlDbType.VarChar);
            cmd.Parameters["@vchDadeValue"].Size = -1;
            cmd.Parameters["@vchDadeValue"].Direction = System.Data.ParameterDirection.Output;
            cmd.Connection.Open();
            cmd.ExecuteNonQuery();
            cmd.Connection.Close();
        }
        catch (Exception ex)
        {
            PMAssistReleaseVersion.AppCode.ErrorLogging.clsErrorLogging.LogError(ex.Message, "clsGeneral.cs", "GetDadeValueByType()");
        }
        return cmd.Parameters["@vchDadeValue"].Value.ToString();
    }
}