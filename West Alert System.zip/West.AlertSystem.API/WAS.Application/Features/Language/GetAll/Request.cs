﻿using MediatR;

namespace WAS.Application.Features.Language.GetAll
{
    public class Request : IRequest<Response>
    {
    }
}
