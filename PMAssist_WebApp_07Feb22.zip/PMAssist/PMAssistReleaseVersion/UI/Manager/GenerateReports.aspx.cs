﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using Microsoft.ApplicationBlocks.Data;
using System.Data;
using System.Data.SqlClient;
using System.Text;
using System.IO;
using System.Collections;
using System.Configuration;
using PMAssistReleaseVersion.AppCode.Generic;
using PMAssistReleaseVersion.AppCode;
using System.Globalization;
using PMAssistReleaseVersion.AppCode.BLL;

namespace PMAssistReleaseVersion.UI.Manager
{
    public partial class GenerateReports : System.Web.UI.Page
    {
        int PortalId;
        //DataTable dtControlVisibility;
        string strReferenceNumber;
        string strModule;
        string strFromDate;
        string strToDate;
        string strCOType;
        string strTicketType;
        string strStatus;
        string strAssignedTo;

        protected void Page_Load(object sender, EventArgs e)
        {
            try
            {
                if (!Page.IsPostBack)
                {
                    PortalId = Convert.ToInt32(Session["PortalId"]);
                    LoadIncidentChangeRequest();
                    LoadCOType();
                    LoadModules();
                    LoadStatusofTicket();
                    LoadAssignedTo();
                    BindGrid();
                    LoadAvailabeReports();
                    LoadSlaYears();
                    ViewState["dtControlVisibility"] = clsTicketInformation.LoadAvailabeReports();
                }
                ScriptManager scriptManager = ScriptManager.GetCurrent(this.Page);
                scriptManager.RegisterPostBackControl(this.btnGenerateReport);
                CustomizeControls();
            }
            catch (Exception ex)
            {
                PMAssistReleaseVersion.AppCode.ErrorLogging.clsErrorLogging.LogError(ex.Message, "GenerateReports.aspx.cs", "Page_Load()");
                lblError.Text = "Failed";
            }
        }
        void CustomizeControls()
        {
            try
            {
                if (txtWsrDateOfTheWeek.Text != string.Empty)
                {
                    DateTime selectedDate = Convert.ToDateTime(txtWsrDateOfTheWeek.Text, CultureInfo.CurrentCulture);
                    DateTime firstDateOfTheWeek = selectedDate.AddDays(-(int)(selectedDate.DayOfWeek - 1));
                    lblSelectedDateMonday.Text = "WSR will be generated for the week of " + firstDateOfTheWeek.ToString("dd-MMM-yyyy");
                }
            }
            catch (Exception ex)
            {
                PMAssistReleaseVersion.AppCode.ErrorLogging.clsErrorLogging.LogError(ex.Message, "GenerateReports.aspx.cs", "CustomizeControls()");
                lblError.Text = "Failed";
            }

        }

        //To bind gridview with the TicketDetails

        /// <summary>
        /// Method which binds the data to the Grid
        /// </summary>
        public void BindGrid()
        {
            try
            {
                //Here we are passing portalId to get Ticketdetails of the specif user
                DataTable dtTicketDetails = clsSearch.GetTicketDetails();
                gvTicketList.DataSource = dtTicketDetails;
                gvTicketList.DataBind();
                dtTicketDetails.Clear();
            }
            catch (Exception ex)
            {
                PMAssistReleaseVersion.AppCode.ErrorLogging.clsErrorLogging.LogError(ex.Message, "GenerateReports.aspx.cs", "BindGrid()");
                lblError.Text = "Failed";
            }
        }

        //Load LoadTIcketTypeDetails dropdown
        private void LoadIncidentChangeRequest()
        {
            try
            {
                DataTable dt = clsTicketInformation.LoadIncidentChangeRequestData();
                ddlTicketType.DataSource = dt;
                ddlTicketType.DataTextField = "tctpTicketType";
                ddlTicketType.DataValueField = "tctpId";
                ddlTicketType.DataBind();
                ddlTicketType.Items.Insert(0, new ListItem("Select Ticket Type", ""));
            }

            catch (Exception ex)
            {
                PMAssistReleaseVersion.AppCode.ErrorLogging.clsErrorLogging.LogError(ex.Message, "GenerateReports.aspx.cs", "LoadIncidentChangeRequest()");
                lblError.Text = "Failed";
            }

        }

        //Load LoadCOType dropdown
        private void LoadCOType()
        {
            try
            {
                DataTable dt = clsTicketInformation.LoadCOType();
                ddlCoType.DataSource = dt;
                ddlCoType.DataTextField = "CotpChangeOrderType";
                ddlCoType.DataValueField = "CotpId";
                ddlCoType.DataBind();
            }
            catch (Exception ex)
            {
                PMAssistReleaseVersion.AppCode.ErrorLogging.clsErrorLogging.LogError(ex.Message, "GenerateReports.aspx.cs", "LoadCOType()");
                lblError.Text = "Failed";
            }
        }

        //Load ModuleName dropdown
        private void LoadModules()
        {
            try
            {
                DataTable dt = clsTicketInformation.LoadModuleName();
                ddlModule.DataSource = dt;
                ddlModule.DataTextField = "ModlName";
                ddlModule.DataValueField = "ModlId";
                ddlModule.DataBind();
                ddlModule.Items.Insert(0, new ListItem("Select Module", ""));
            }

            catch (Exception ex)
            {
                PMAssistReleaseVersion.AppCode.ErrorLogging.clsErrorLogging.LogError(ex.Message, "GenerateReports.aspx.cs", "LoadModules()");
                lblError.Text = "Failed";
            }
        }

        //Load Status of Ticket dropdown
        private void LoadStatusofTicket()
        {
            try
            {
                DataTable dt = clsTicketInformation.LoadStatusofTicket();
                ddlStatus.DataSource = dt;
                ddlStatus.DataTextField = "TcstTicketStatus";
                ddlStatus.DataValueField = "TcstId";
                ddlStatus.DataBind();
                ddlStatus.Items.Insert(0, new ListItem("Select Ticket Status", ""));
            }
            catch (Exception ex)
            {
                PMAssistReleaseVersion.AppCode.ErrorLogging.clsErrorLogging.LogError(ex.Message, "GenerateReports.aspx.cs", "LoadStatusofTicket()");
                lblError.Text = "Failed";
            }

        }

        //Load AssignedTo dropdown
        private void LoadAssignedTo()
        {
            try
            {
                DataTable dt = clsTicketInformation.LoadAssignedTo();
                ddlAssignedTo.DataSource = dt;
                ddlAssignedTo.DataTextField = "UnsmFirstName";
                ddlAssignedTo.DataValueField = "UnsmPortalId";
                ddlAssignedTo.DataBind();
                ddlAssignedTo.Items.Insert(0, new ListItem("Select Assigned To", ""));
            }
            catch (Exception ex)
            {
                PMAssistReleaseVersion.AppCode.ErrorLogging.clsErrorLogging.LogError(ex.Message, "GenerateReports.aspx.cs", "LoadAssignedTo()");
                lblError.Text = "Failed";
            }

        }

        //Load AssignedTo dropdown
        private void LoadSlaYears()
        {
            try
            {
                DataTable dt = clsTicketInformation.LoadSlaYears();
                ddlYear.DataSource = dt;
                ddlYear.DataTextField = "SlyaSlaYear";
                ddlYear.DataValueField = "SlyaSlaYear";
                ddlYear.DataBind();
                ddlYear.SelectedValue = DateTime.Now.Year.ToString();
            }
            catch (Exception ex)
            {
                PMAssistReleaseVersion.AppCode.ErrorLogging.clsErrorLogging.LogError(ex.Message, "GenerateReports.aspx.cs", "LoadSlaYears()");
                lblError.Text = "Failed";
            }
        }

        //Load Available Reports to dropdown
        private void LoadAvailabeReports()
        {
            try
            {
                DataTable dt = clsTicketInformation.LoadAvailabeReports();
                ddlReport.DataSource = dt;
                ddlReport.DataTextField = "GnrpReport";
                ddlReport.DataValueField = "GnrpId";
                ddlReport.DataBind();
            }
            catch (Exception ex)
            {
                PMAssistReleaseVersion.AppCode.ErrorLogging.clsErrorLogging.LogError(ex.Message, "GenerateReports.aspx.cs", "LoadAvailabeReports()");
                lblError.Text = "Failed";
            }
        }

        protected void OnPaging(object sender, GridViewPageEventArgs e)
        {
            try
            {
                BindGrid();
                gvTicketList.PageIndex = e.NewPageIndex;
                gvTicketList.DataBind();
            }
            catch (Exception ex)
            {
                PMAssistReleaseVersion.AppCode.ErrorLogging.clsErrorLogging.LogError(ex.Message, "GenerateReports.aspx.cs", "OnPaging()");
                lblError.Text = "Failed";
            }
        }

        protected void btnMSR_Click(object sender, EventArgs e)
        {

        }

        protected void ddlReport_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                if (ddlReport.SelectedItem.Text == "Generate WSR")
                {
                    WSRTr.Visible = true;
                }
                else
                {
                    WSRTr.Visible = false;
                }

                var dtControlVisibility = (DataTable)ViewState["dtControlVisibility"];
                var controlVisibility = from dcv in dtControlVisibility.AsEnumerable()
                                        where dcv.Field<int>("GnrpId") == Convert.ToInt32(ddlReport.SelectedValue)
                                        && dcv.Field<string>("GnrpReport") == ddlReport.SelectedItem.ToString()
                                        select dcv;
                foreach (var x in controlVisibility)
                {
                    btnGenerateReport.Text = x.Field<string>("GnrpButtonGenericText");
                    btnGenerateReport.Visible = x.Field<string>("GnrpVisibilityButtonGeneric").ToUpper().Equals("Y");
                    txtReferenceNumber.Visible = x.Field<string>("GnrpVisibilityReferenceNumber").ToUpper().Equals("Y");
                    lblReferenceNumber.Visible = txtReferenceNumber.Visible;
                    ddlStatus.Visible = x.Field<string>("GnrpVisibilityTicketStatus").ToUpper().Equals("Y");
                    lblTicketStatus.Visible = ddlStatus.Visible;
                    ddlModule.Visible = x.Field<string>("GnrpVisibilityTicketModule").ToUpper().Equals("Y");
                    lblModule.Visible = ddlModule.Visible;
                    ddlTicketType.Visible = x.Field<string>("GnrpVisibilityTicketType").ToUpper().Equals("Y");
                    lblTicketType.Visible = ddlTicketType.Visible;
                    txtFromDate.Visible = x.Field<string>("GnrpVisibilityFromDate").ToUpper().Equals("Y");
                    lblFromDate.Visible = txtFromDate.Visible;
                    txtToDate.Visible = x.Field<string>("GnrpVisibilityToDate").ToUpper().Equals("Y");
                    lblToDate.Visible = txtToDate.Visible;
                    ddlAssignedTo.Visible = x.Field<string>("GnrpVisibilityAssignedTo").ToUpper().Equals("Y");
                    lblAssignedTo.Visible = ddlAssignedTo.Visible;
                    ddlCoType.Visible = x.Field<string>("GnrpVisibilityCoType").ToUpper().Equals("Y");
                    lblCoType.Visible = ddlCoType.Visible;
                    gvTicketList.Visible = x.Field<string>("GnrpVisibilityGridView").ToUpper().Equals("Y");
                    lblHeadingUsers.Visible = x.Field<string>("GnrpVisibilityLabelHeading").ToUpper().Equals("Y");
                    btnClear.Visible = x.Field<string>("GnrpVisibilityButtonClear").ToUpper().Equals("Y");
                    txtWsrDateOfTheWeek.Visible = x.Field<string>("GnrpVisibilityDateOfTheWeek").ToUpper().Equals("Y");
                    lblPickDateOfTheWeek.Visible = txtWsrDateOfTheWeek.Visible;
                    lblSelectedDateMonday.Visible = txtWsrDateOfTheWeek.Visible;
                    lblNextRelease.Visible = x.Field<string>("GnrpVisibilityLiteralNextRelease").ToUpper().Equals("Y");
                    ddlMonth.Visible = x.Field<string>("GnrpVisibilitySlaMonth").ToUpper().Equals("Y");
                    lblMonth.Visible = ddlMonth.Visible;
                    ddlYear.Visible = x.Field<string>("GnrpVisibilitySlaYear").ToUpper().Equals("Y");
                    lblYear.Visible = ddlYear.Visible;
                }
                ClearCriteria();
            }

            catch (Exception ex)
            {
                PMAssistReleaseVersion.AppCode.ErrorLogging.clsErrorLogging.LogError(ex.Message, "GenerateReports.aspx.cs", "ddlReport_SelectedIndexChanged()");
                lblError.Text = "Failed";
            }
        }

        void ClearCriteria()
        {
            try
            {
                txtReferenceNumber.Text = string.Empty;
                ddlStatus.SelectedIndex = 0;
                ddlModule.SelectedIndex = 0;
                ddlTicketType.SelectedIndex = 0;
                txtFromDate.Text = string.Empty;
                txtToDate.Text = string.Empty;
                ddlAssignedTo.SelectedIndex = 0;
                ddlCoType.SelectedIndex = 0;
                txtWsrDateOfTheWeek.Text = string.Empty;
                lblSelectedDateMonday.Text = string.Empty;
                ddlMonth.SelectedValue = DateTime.Now.Month.ToString();
                ddlYear.SelectedValue = DateTime.Now.Year.ToString();
            }

            catch (Exception ex)
            {
                PMAssistReleaseVersion.AppCode.ErrorLogging.clsErrorLogging.LogError(ex.Message, "GenerateReports.aspx.cs", "ClearCriteria()");
                lblError.Text = "Failed";
            }
        }

        protected void btnGenerateReport_Click(object sender, EventArgs e)
        {
            try
            {
                if (btnGenerateReport.Text.Contains("Generate Consolidated Status Report")) GenerateConsolidatedStatusReport();
                if (btnGenerateReport.Text.Contains("Generate SLA Report")) GenerateSLAReport();    //SLA For next Release
                if (btnGenerateReport.Text.Contains("Generate WSR")) GenerateWSR();
                if (btnGenerateReport.Text.Contains("Search")) SearchTickets();
            }

            catch (Exception ex)
            {
                PMAssistReleaseVersion.AppCode.ErrorLogging.clsErrorLogging.LogError(ex.Message, "GenerateReports.aspx.cs", "btnGenerateReport_Click()");
                lblError.Text = "Failed";
            }
        }

        void GenerateConsolidatedStatusReport()
        {
            try
            {
                GetControlValues();
                //ExcelAppExportor<ConsolidatedReportExcelEntities> exportorConsolidatedTracker = clsGenerateReports.ConsolidatedStatusReport(strReferenceNumber, strModule, strFromDate, strToDate, strCOType, strTicketType, strStatus, strAssignedTo);
                string strExportFileName = clsGenerateReports.ConsolidatedStatusReport(strReferenceNumber, strModule, strFromDate, strToDate, strCOType, strTicketType, strStatus, strAssignedTo);
                //string strExportFileName = Path.Combine(@"D:\PMAssistReports\", Guid.NewGuid().ToString("N")) + ".xlsm";

                byte[] ExcelStream = File.ReadAllBytes(strExportFileName);

                Context.Response.ClearContent();
                Context.Response.ContentType = "application/ms-excel";
                Context.Response.AddHeader("content-disposition", string.Format("attachment;filename={0}.xlsm", "Consolidated Tracker"));
                Context.Response.Charset = "";
                Context.Response.BinaryWrite(ExcelStream);
                Context.Response.End();
            }
            catch (Exception ex)
            {
                PMAssistReleaseVersion.AppCode.ErrorLogging.clsErrorLogging.LogError(ex.Message, "GenerateReports.aspx.cs", "GenerateConsolidatedStatusReport()");
                lblError.Text = "Failed";
            }
            finally
            {
                clsGenerateReports.ClearServerReports();
            }
        }

        void GenerateSLAReport()
        {
            try
            {
                int month = Convert.ToInt32(ddlMonth.SelectedItem.Value);
                int year = Convert.ToInt32(ddlYear.SelectedItem.Value);
                string exportedCharismaKpiFileName = clsGenerateReports.SlaCharismaKpiSheet(month,year);
                string strExportFileName = clsGenerateReports.SlaResolvedTicketDetails(exportedCharismaKpiFileName, month, year);

                byte[] ExcelStream = File.ReadAllBytes(strExportFileName);

                Context.Response.ClearContent();
                Context.Response.ContentType = "application/ms-excel";
                Context.Response.AddHeader("content-disposition", string.Format("attachment;filename={0}.xlsx", "KPI_Charisma_EndToEnd"));
                Context.Response.Charset = "";
                Context.Response.BinaryWrite(ExcelStream);
                Context.Response.End();
            }
            catch (Exception ex)
            {
                PMAssistReleaseVersion.AppCode.ErrorLogging.clsErrorLogging.LogError(ex.Message, "GenerateReports.aspx.cs", "GenerateSLAReport()");
                lblError.Text = "Failed";
            }
            finally
            {
                 clsGenerateReports.ClearServerReports();
            }
        }
        
        DateTime GetSelectedDate()
        {
            DateTime selectedDate;
            if (txtWsrDateOfTheWeek.Text != string.Empty)
            {
                selectedDate = Convert.ToDateTime(txtWsrDateOfTheWeek.Text);
            }
            else
            {
                selectedDate = DateTime.Now;
            }
            return selectedDate;
        }

        void GenerateWSR()
        {
            try
            {
                DateTime selectedDate = GetSelectedDate();
                string[] applications = new string[]{"SharePoint", "Fred", "Charisma"};
               // string[] applications = new string[] { "Charisma" };
                string exportedWsrFileName = clsGenerateReports.WsrGraphsDataTabPopulation(selectedDate);
                foreach (string application in applications)
                {
                    exportedWsrFileName = clsGenerateReports.WsrPriorityTicketTypeDataPopulation(exportedWsrFileName, selectedDate, application);                
                }

                byte[] ExcelStream = File.ReadAllBytes(exportedWsrFileName);

                Context.Response.ClearContent();
                Context.Response.ContentType = "application/ms-excel";
                Context.Response.AddHeader("content-disposition", string.Format("attachment;filename={0}.xlsx", "Weekly Status Report"));
                Context.Response.Charset = "";
                Context.Response.Flush();
                Context.Response.BinaryWrite(ExcelStream);
                Context.Response.End();
            }
            catch (Exception ex)
            {
                PMAssistReleaseVersion.AppCode.ErrorLogging.clsErrorLogging.LogError(ex.Message, "GenerateReports.aspx.cs", "GenerateSLAReport()");
                lblError.Text = "Failed";
            }
            finally
            {
                clsGenerateReports.ClearServerReports();
            }
        }

        void SearchTickets()
        {
            try
            {
                GetControlValues();
                DataSet dsTicketDetails = clsSearch.GetTicketDetailsbyCriteria(strReferenceNumber, strModule, strFromDate, strToDate, strCOType, strTicketType, strStatus, strAssignedTo);
                gvTicketList.DataSource = dsTicketDetails;
                gvTicketList.DataBind();


                if (gvTicketList.Rows.Count == 0)
                {
                    lblError.Visible = true;
                    lblError.Text = "Sorry, no  matches found the search parameters";

                }
                else
                {
                    lblError.Visible = false;
                    lblError.Text = "";
                }
            }
            catch (Exception ex)
            {
                PMAssistReleaseVersion.AppCode.ErrorLogging.clsErrorLogging.LogError(ex.Message, "GenerateReports.aspx.cs", "SearchTickets()");
                Response.Redirect("Oops.aspx");

            }
        }

        void GetControlValues()
        {
            try
            {
                strReferenceNumber = txtReferenceNumber.Text.TrimEnd().TrimStart();
                strModule = ddlModule.SelectedValue;
                strFromDate = Request.Form[txtFromDate.UniqueID].ToString();
                if (!(strFromDate == string.Empty))
                    strFromDate = Convert.ToDateTime(Request.Form[txtFromDate.UniqueID]).ToShortDateString();
                strToDate = Request.Form[txtToDate.UniqueID].ToString();
                if (!(strToDate == string.Empty))
                    strToDate = Convert.ToDateTime(Request.Form[txtToDate.UniqueID]).ToShortDateString();
                strCOType = ddlCoType.SelectedValue;
                strTicketType = ddlTicketType.SelectedValue;
                strStatus = ddlStatus.SelectedValue;
                strAssignedTo = ddlAssignedTo.SelectedValue;
            }
            catch (Exception ex)
            {
                PMAssistReleaseVersion.AppCode.ErrorLogging.clsErrorLogging.LogError(ex.Message, "GenerateReports.aspx.cs", "GetControlValues()");
                lblError.Text = "Failed";
            }
        }

        protected void gvTicketList_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            try
            {
                gvTicketList.PageIndex = e.NewPageIndex;
                BindGrid();
            }

            catch (Exception ex)
            {
                PMAssistReleaseVersion.AppCode.ErrorLogging.clsErrorLogging.LogError(ex.Message, "GenerateReports.aspx.cs", "gvTicketList_PageIndexChanging()");
                lblError.Text = "Failed";
            }
        }

    }
}