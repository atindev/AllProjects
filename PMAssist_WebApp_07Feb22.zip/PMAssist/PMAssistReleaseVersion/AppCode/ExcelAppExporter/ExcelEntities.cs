﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace PMAssistReleaseVersion.UI.Manager
{
    public class ExcelEntitites
    {
        public string P1 { get; set; }
        public string P2 { get; set; }
        public string P3 { get; set; }
        public string P4 { get; set; }
        public string P5 { get; set; }

        public string P1_Outstanding { get; set; }
        public string P2_Outstanding { get; set; }
        public string P3_Outstanding { get; set; }
        public string P4_Outstanding { get; set; }
        public string P5_Outstanding { get; set; }

        public string P1_Current { get; set; }
        public string P2_Current { get; set; }
        public string P3_Current { get; set; }
        public string P4_Current { get; set; }
        public string P5_Current { get; set; }

        public string P1_Resolved { get; set; }
        public string P2_Resolved { get; set; }
        public string P3_Resolved { get; set; }
        public string P4_Resolved { get; set; }
        public string P5_Resolved { get; set; }

        public string P1_Worked { get; set; }
        public string P2_Worked { get; set; }
        public string P3_Worked { get; set; }
        public string P4_Worked { get; set; }
        public string P5_Worked { get; set; }

        public string P1_DiffTeam { get; set; }
        public string P2_DiffTeam { get; set; }
        public string P3_DiffTeam { get; set; }
        public string P4_DiffTeam { get; set; }
        public string P5_DiffTeam { get; set; }

        public string P1_Pending { get; set; }
        public string P2_Pending { get; set; }
        public string P3_Pending { get; set; }
        public string P4_Pending { get; set; }
        public string P5_Pending { get; set; }

        public string P1_Problem { get; set; }
        public string P2_Problem { get; set; }
        public string P3_Problem { get; set; }
        public string P4_Problem { get; set; }
        public string P5_Problem { get; set; }



        public string ReportDate { get; set; }
        public string From { get; set; }
        public string To { get; set; }
        public string Status { get; set; }

        public string IncidentReferenceNumber { get; set; }
        public string IncidentTicketType { get; set; }
        public string IncidentPriority { get; set; }
        public string IncidentStatus { get; set; }
        public string IncidentDescription { get; set; }
        public string IncidentAssignedDate { get; set; }
        public string IncidentResolvedDate { get; set; }
        public string IncidentComments { get; set; }
        public string IncidentTypeInDetail { get; set; }
        public string IncidentInsertNewLine { get; set; }

        public string ChangeReferenceNumber { get; set; }
        public string ChangeTicketType { get; set; }
        public string ChangePrtyPriority { get; set; }
        public string ChangeTicketStatus { get; set; }
        public string ChangeTcktDescription { get; set; }
        public string ChangeTcktAssignedDate { get; set; }
        public string ChangeTcktResolvedDate { get; set; }
        public string ChangeTcktComments { get; set; }
        public string ChangeTicketTypeInDetail { get; set; }
        public string ChangeInsertNewLine { get; set; }

        public string ProblemReferenceNumber { get; set; }
        public string ProblemTicketType { get; set; }
        public string ProblemPrtyPriority { get; set; }
        public string ProblemTicketStatus { get; set; }
        public string ProblemTcktDescription { get; set; }
        public string ProblemTcktAssignedDate { get; set; }
        public string ProblemTcktResolvedDate { get; set; }
        public string ProblemTcktComments { get; set; }
        public string ProblemTicketTypeInDetail { get; set; }
        public string ProblemInsertNewLine { get; set; }

    }

    public class ConsolidatedReportExcelEntities
    {
        public string ReferenceNumber { get; set; }
        public string TicketType { get; set; }
        public string TicketTypeInDetail { get; set; }
        public string CoNumber { get; set; }
        public string Complexity { get; set; }
        public string PriorityId { get; set; }
        public string ModuleName { get; set; }
        public string IncidentCategory { get; set; }
        public string TicketStatus { get; set; }
        public string Comments { get; set; }
        public string TicketAssignedInTheWeekOf { get; set; }
        public string AssignedTo { get; set; }
        public string TargetDate { get; set; }
        public string AssignedDate { get; set; }
        public string AssignedTime { get; set; }
        public string AcknowldedgedDate { get; set; }
        public string AcknowldedgedTime { get; set; }
        public string OnHoldTime { get; set; }
        public string ResolvedDate { get; set; }
        public string ResolvedTime { get; set; }
        public string Description { get; set; }
        public string ReasonForDefect { get; set; }
        public string TotalAcknowledgedTimeInHrs { get; set; }
        public string TotalResolvedTimeInHrs { get; set; }
        public string AcknowledgedKPI { get; set; }
        public string ResolvedKPI { get; set; }
        public string OriginOfDefect { get; set; }
        public string ReviewedBy { get; set; }
        public string ReceivedDateTime { get; set; }
        public string ResponseDateTime { get; set; }
        public string KPIDate { get; set; }
        public string DateOfPeerReview { get; set; }
        public string ActualEffort { get; set; }
        public string StatusCommentary { get; set; }
        public string ReasonForRejection { get; set; }
    }

    public class SLACharismaKpi
    {
        public string Target { get; set; }
        public string CurrentMonthAchieved { get; set; }
        public string CurrentMonthVolume { get; set; }
        public string LastMonthAchieved { get; set; }
        public string LastMonthVolume { get; set; }
        public string SlaCurrentMonth { get; set; }
        public string SlaLastMonth { get; set; }
        public string SlaFromDate { get; set; }
        public string SlaToDate { get; set; }
    }

    public class SLAResolvedTicketsDetails
    {
        public string SlNo { get; set; }
        public string ReferenceNo { get; set; }
        public string IncidentChangeProblem { get; set; }
        public string Type { get; set; }
        public string Priority { get; set; }
        public string AssignedDate { get; set; }
        public string ResolvedDate { get; set; }
        public string TargetDate { get; set; }
        public string InternalKpisMet { get; set; }
        public string EndToEndKpisMet { get; set; }
        public string Comments { get; set; }
    }

    public class WSRGraphEntities
    {
        public WSRGraphEntities()
        {
            charismaOutStanding = string.Empty;
            charismaCurrentWeek = string.Empty;
            charismaResolved = string.Empty;
            charismaWorked = string.Empty;
            charismaAssignedToDifferentTeam = string.Empty;
            charismaPending = string.Empty;
            charismaProblemManagement = string.Empty;
            charismaWeekEnding = string.Empty;
            charismaStatusWIP = string.Empty;
            charismaStatusPendingUAT = string.Empty;
            charismaStatusHold = string.Empty;
            charismaStatusPIR = string.Empty;
            charismaStatusYetToStart = string.Empty;
            charismaStatusRFC = string.Empty;
            charismaStatusRFR = string.Empty;

            fredOutStanding = string.Empty;
            fredCurrentWeek = string.Empty;
            fredResolved = string.Empty;
            fredWorked = string.Empty;
            fredAssignedToDifferentTeam = string.Empty;
            fredPending = string.Empty;
            fredProblemManagement = string.Empty;
            fredWeekEnding = string.Empty;
            fredStatusWIP = string.Empty;
            fredStatusPendingUAT = string.Empty;
            fredStatusHold = string.Empty;
            fredStatusPIR = string.Empty;
            fredStatusYetToStart = string.Empty;
            fredStatusRFC = string.Empty;
            fredStatusRFR = string.Empty;

            sharepointOutStanding = string.Empty;
            sharepointCurrentWeek = string.Empty;
            sharepointResolved = string.Empty;
            sharepointWorked = string.Empty;
            sharepointAssignedToDifferentTeam = string.Empty;
            sharepointPending = string.Empty;
            sharepointProblemManagement = string.Empty;
            sharepointWeekEnding = string.Empty;
            sharepointStatusWIP = string.Empty;
            sharepointStatusPendingUAT = string.Empty;
            sharepointStatusHold = string.Empty;
            sharepointStatusPIR = string.Empty;
            sharepointStatusYetToStart = string.Empty;
            sharepointStatusRFC = string.Empty;
            sharepointStatusRFR = string.Empty;
        }
        //Charisma Graph Entities
        public string charismaOutStanding { get; set; }
        public string charismaCurrentWeek { get; set; }
        public string charismaResolved { get; set; }
        public string charismaWorked { get; set; }
        public string charismaAssignedToDifferentTeam { get; set; }
        public string charismaPending { get; set; }
        public string charismaProblemManagement { get; set; }
        public string charismaWeekEnding { get; set; }
        public string charismaStatusWIP { get; set; }
        public string charismaStatusPendingUAT { get; set; }
        public string charismaStatusHold { get; set; }
        public string charismaStatusPIR { get; set; }
        public string charismaStatusYetToStart { get; set; }
        public string charismaStatusRFC { get; set; }
        public string charismaStatusRFR { get; set; }

        //Fred Graph Entities
        public string fredOutStanding { get; set; }
        public string fredCurrentWeek { get; set; }
        public string fredResolved { get; set; }
        public string fredWorked { get; set; }
        public string fredAssignedToDifferentTeam { get; set; }
        public string fredPending { get; set; }
        public string fredProblemManagement { get; set; }
        public string fredWeekEnding { get; set; }
        public string fredStatusWIP { get; set; }
        public string fredStatusPendingUAT { get; set; }
        public string fredStatusHold { get; set; }
        public string fredStatusPIR { get; set; }
        public string fredStatusYetToStart { get; set; }
        public string fredStatusRFC { get; set; }
        public string fredStatusRFR { get; set; }

        //Share Point Graph Entities
        public string sharepointOutStanding { get; set; }
        public string sharepointCurrentWeek { get; set; }
        public string sharepointResolved { get; set; }
        public string sharepointWorked { get; set; }
        public string sharepointAssignedToDifferentTeam { get; set; }
        public string sharepointPending { get; set; }
        public string sharepointProblemManagement { get; set; }
        public string sharepointWeekEnding { get; set; }
        public string sharepointStatusWIP { get; set; }
        public string sharepointStatusPendingUAT { get; set; }
        public string sharepointStatusHold { get; set; }
        public string sharepointStatusPIR { get; set; }
        public string sharepointStatusYetToStart { get; set; }
        public string sharepointStatusRFC { get; set; }
        public string sharepointStatusRFR { get; set; }
    }
}

