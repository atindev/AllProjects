﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using Microsoft.ApplicationBlocks.Data;
using System.Data;
using System.Data.SqlClient;
using System.Text;
using System.Collections;
using PMAssistReleaseVersion.AppCode.Generic;

namespace PMAssistReleaseVersion.UI.Resource
{
    public partial class SearchTasks : System.Web.UI.Page
    {

        string strFromDate;
        string strResource;

        protected void Page_PreInit(object sender, EventArgs e)
        {
            try
            {
                if (Session["LoginType"] != null)
                {
                    clsGeneral.SetMasterPage(this.Page);
                }
            }

            catch (Exception ex)
            {
                PMAssistReleaseVersion.AppCode.ErrorLogging.clsErrorLogging.LogError(ex.Message, "SearchTasks.aspx.cs", "Page_PreInit()");
                lblError.Text = "Failed";
            }
        }

        protected void Page_Load(object sender, EventArgs e)
        {
            try
            {
                if (!Page.IsPostBack)
                {
                    LoadResources();
                    BindGrid();
                }
            }

            catch (Exception ex)
            {
                PMAssistReleaseVersion.AppCode.ErrorLogging.clsErrorLogging.LogError(ex.Message, "SearchTasks.aspx.cs", "Page_Load()");
                lblError.Text = "Failed";
            }
           
        }

        //To bind gridview with the TaskDetails
        public void BindGrid()
        {
            try
            {
                //Here we are passing portalId to get TaskDetals of the specific user
                DataTable dtTaskDetails = clsSearch.GetTaskDetails();
                gvTaskList.DataSource = dtTaskDetails;
                gvTaskList.DataBind();
                dtTaskDetails.Clear();

            }
            catch (Exception ex)
            {
                PMAssistReleaseVersion.AppCode.ErrorLogging.clsErrorLogging.LogError(ex.Message, "SearchTasks.aspx.cs", "BindGrid()");
                lblError.Text = "Failed";
            }
        }


        protected void btnSearch_Click(object sender, EventArgs e)
        {
            try
            {
                GetControlValues();
                DataSet dsTicketDetails = clsSearch.GetTaskDetailsByCriteria(strFromDate,strResource);
                gvTaskList.DataSource = dsTicketDetails;
                gvTaskList.DataBind();


                if (gvTaskList.Rows.Count == 0)
                {
                    lblError.Visible = true;
                    lblError.Text = "Sorry, no  matches found the search parameters";
                }
                else
                {
                    lblError.Visible = false;
                    lblError.Text = "";
                }
            }
            catch (Exception ex)
            {
                PMAssistReleaseVersion.AppCode.ErrorLogging.clsErrorLogging.LogError(ex.Message, "SearchTasks.aspx.cs", "btnSearch_Click()");
                Response.Redirect("Oops.aspx");

            }

}
             
        //Load resources dropdown
        private void LoadResources()
        {
            try
            {
                DataTable dt = clsTicketInformation.LoadAssignedTo();
                ddlResource.DataSource = dt;
                ddlResource.DataTextField = "UnsmFirstName";
                ddlResource.DataValueField = "UnsmPortalId";
                ddlResource.DataBind();
                ddlResource.Items.Insert(0, new ListItem("Select Resource", ""));
            }

            catch (Exception ex)
            {
                PMAssistReleaseVersion.AppCode.ErrorLogging.clsErrorLogging.LogError(ex.Message, "SearchTasks.aspx.cs", "LoadResources()");
                lblError.Text = "Failed";
            }
        }

        protected void OnPaging(object sender, GridViewPageEventArgs e)
        {
            try
            {
                BindGrid();
                gvTaskList.PageIndex = e.NewPageIndex;
                gvTaskList.DataBind();
            }

            catch (Exception ex)
            {
                PMAssistReleaseVersion.AppCode.ErrorLogging.clsErrorLogging.LogError(ex.Message, "SearchTasks.aspx.cs", "OnPaging()");
                lblError.Text = "Failed";
            }

        }

        private void GetControlValues()
        {
            try
            {

                strFromDate = Request.Form[txtTaskDate.UniqueID].ToString();
                if (!(strFromDate == string.Empty))
                    strFromDate = Convert.ToDateTime(Request.Form[txtTaskDate.UniqueID]).ToString("dd/MM/yyyy");

                strResource = ddlResource.SelectedValue;
            }
            catch (Exception ex)
            {
                PMAssistReleaseVersion.AppCode.ErrorLogging.clsErrorLogging.LogError(ex.Message, "SearchTasks.aspx.cs", "GetControlValues()");
                lblError.Text = "Failed";
            }

        }

        protected void gvTaskList_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {

            try
            {
                gvTaskList.PageIndex = e.NewPageIndex;
                BindGrid();
            }

            catch (Exception ex)
            {
                PMAssistReleaseVersion.AppCode.ErrorLogging.clsErrorLogging.LogError(ex.Message, "SearchTasks.aspx.cs", "gvTaskList_PageIndexChanging()");
                lblError.Text = "Failed";
            }
        }

        protected void gvTaskList_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}
