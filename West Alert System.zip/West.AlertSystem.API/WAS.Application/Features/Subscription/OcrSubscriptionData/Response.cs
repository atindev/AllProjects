﻿namespace WAS.Application.Features.Subscription.OcrSubscriptionData
{
    public class Response
    {

        /// <summary>
        /// Success Message
        /// </summary>
        public bool Success { get; set; }
    }
}
