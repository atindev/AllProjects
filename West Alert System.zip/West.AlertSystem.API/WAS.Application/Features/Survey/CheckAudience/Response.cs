﻿using System;

namespace WAS.Application.Features.Survey.CheckAudience
{
    public class Response
    {
        /// <summary>
        /// subscription id
        /// </summary>
        public Guid SubscriptionId { get; set; }
    }
}
