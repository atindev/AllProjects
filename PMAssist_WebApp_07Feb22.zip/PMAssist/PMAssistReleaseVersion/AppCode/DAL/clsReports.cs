﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.SqlClient;
using PMAssistReleaseVersion.UI.Manager;
using PMAssistReleaseVersion.AppCode;
using Microsoft.ApplicationBlocks.Data;
using System.Collections;

namespace PMAssistReleaseVersion.AppCode.Generic
{
    public class clsReports
    {
        public static IList<ConsolidatedReportExcelEntities> ConsolidatedStatusReportExcelList(string strReferenceNumber, string strModule, string strFromDate, string strToDate, string strCOType, string strTicketType, string strStatus, string strAssignedTo)
        {
            IList<ConsolidatedReportExcelEntities> ExcelEntityList = new List<ConsolidatedReportExcelEntities>();
            try
            {
                SqlCommand cmd = clsManagerResourceCommon.GetAllCommonCommandObjectParameters(strReferenceNumber, strModule, strFromDate, strToDate, strCOType, strTicketType, strStatus, strAssignedTo);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "spGenerateConsolidatedStatusReport";
                cmd.CommandTimeout = 0;
                SqlConnection connection = cmd.Connection;
                connection.Open();
                SqlDataReader dr = cmd.ExecuteReader();

                while (dr.Read())
                {
                    ConsolidatedReportExcelEntities ExcelEntity = new ConsolidatedReportExcelEntities();
                    //New Consolidated Tracker
                    ExcelEntity.ReferenceNumber = dr["ReferenceNumber"].ToString();
                    ExcelEntity.CoNumber = dr["CoNumber"].ToString();
                    ExcelEntity.PriorityId = dr["PriorityId"].ToString();
                    ExcelEntity.TicketType = dr["TicketType"].ToString();
                    ExcelEntity.Complexity = dr["Complexity"].ToString();
                    ExcelEntity.ModuleName = dr["ModuleName"].ToString();
                    ExcelEntity.Description = dr["Description"].ToString();
                    ExcelEntity.OriginOfDefect = dr["OriginOfDefect"].ToString();
                    ExcelEntity.TicketStatus = dr["TicketStatus"].ToString();
                    ExcelEntity.AssignedTo = dr["AssignedTo"].ToString();
                    ExcelEntity.ReviewedBy = dr["ReviewedBy"].ToString();
                    ExcelEntity.ReceivedDateTime = dr["ReceivedDateTime"].ToString();
                    ExcelEntity.ResponseDateTime = dr["ResponseDateTime"].ToString();
                    ExcelEntity.TargetDate = dr["TargetDate"].ToString();
                    ExcelEntity.KPIDate = dr["KPIDate"].ToString();
                    ExcelEntity.DateOfPeerReview = dr["DateOfPeerReview"].ToString();
                    ExcelEntity.ResolvedDate = dr["ResolvedDate"].ToString();
                    ExcelEntity.ActualEffort = dr["ActualEffort"].ToString();
                    ExcelEntity.StatusCommentary = dr["StatusCommentary"].ToString();
                    ExcelEntity.ReasonForRejection = dr["ReasonForRejection"].ToString();
                    ExcelEntity.OnHoldTime = dr["OnHoldTime"].ToString();
                    ExcelEntity.TicketTypeInDetail = dr["TicketTypeInDetail"].ToString();
                    ExcelEntity.IncidentCategory = dr["IncidentCategory"].ToString();
                    ExcelEntity.TicketAssignedInTheWeekOf = dr["TicketAssignedInTheWeekOf"].ToString();
                    ExcelEntity.ResolvedTime = dr["ResolvedTime"].ToString();
                    ExcelEntity.TotalAcknowledgedTimeInHrs = dr["TotalAcknowledgedTimeInHrs"].ToString();
                    ExcelEntity.TotalResolvedTimeInHrs = dr["TotalResolvedTimeInHrs"].ToString();
                    ExcelEntity.AcknowledgedKPI = dr["AcknowledgedKPI"].ToString();
                    ExcelEntity.ResolvedKPI = dr["ResolvedKPI"].ToString();

                    //Old Consolidated Tracker
                    //ExcelEntity.ReferenceNumber = dr["ReferenceNumber"].ToString();
                    //ExcelEntity.TicketType = dr["TicketType"].ToString();
                    //ExcelEntity.TicketTypeInDetail = dr["TicketTypeInDetail"].ToString();
                    //ExcelEntity.CoNumber = dr["CoNumber"].ToString();
                    //ExcelEntity.Complexity = dr["Complexity"].ToString();
                    //ExcelEntity.PriorityId = dr["PriorityId"].ToString();
                    //ExcelEntity.ModuleName = dr["ModuleName"].ToString();
                    //ExcelEntity.IncidentCategory = dr["IncidentCategory"].ToString();
                    //ExcelEntity.TicketStatus = dr["TicketStatus"].ToString();
                    //ExcelEntity.Comments = dr["Comments"].ToString();
                    //ExcelEntity.TicketAssignedInTheWeekOf = dr["TicketAssignedInTheWeekOf"].ToString();
                    //ExcelEntity.AssignedTo = dr["AssignedTo"].ToString();
                    //ExcelEntity.TargetDate = dr["TargetDate"].ToString();
                    //ExcelEntity.AssignedDate = dr["AssignedDate"].ToString();
                    //ExcelEntity.AssignedTime = dr["AssignedTime"].ToString();
                    //ExcelEntity.AcknowldedgedDate = dr["AcknowldedgedDate"].ToString();
                    //ExcelEntity.AcknowldedgedTime = dr["AcknowldedgedTime"].ToString();
                    //ExcelEntity.OnHoldTime = dr["OnHoldTime"].ToString();
                    //ExcelEntity.ResolvedDate = dr["ResolvedDate"].ToString();
                    //ExcelEntity.ResolvedTime = dr["ResolvedTime"].ToString();
                    //ExcelEntity.Description = dr["Description"].ToString();
                    //ExcelEntity.TotalAcknowledgedTimeInHrs = dr["TotalAcknowledgedTimeInHrs"].ToString();
                    //ExcelEntity.TotalResolvedTimeInHrs = dr["TotalResolvedTimeInHrs"].ToString();
                    //ExcelEntity.AcknowledgedKPI = dr["AcknowledgedKPI"].ToString();
                    //ExcelEntity.ResolvedKPI = dr["ResolvedKPI"].ToString();
                    //flag = true;
                    ExcelEntityList.Add(ExcelEntity);
                }

            }
            catch (Exception ex)
            {
                PMAssistReleaseVersion.AppCode.ErrorLogging.clsErrorLogging.LogError(ex.Message, "clsReports.cs", "GenerateConsolidatedStatusReport()");
            }
            return ExcelEntityList;
        }

        private static IList<ExcelEntitites> PriorityDataList(DateTime selectedDate, string application)
        {
            SqlConnection connection = new SqlConnection(clsGeneral.ConStr);
            SqlCommand cmd = new SqlCommand("spGenerateWsrTicketPriorityCount", connection);
            cmd.Parameters.AddWithValue("@dteSelectedDate", selectedDate.ToString("yyyyMMdd"));
            cmd.Parameters.AddWithValue("@vchApplication", application);
            cmd.CommandType = CommandType.StoredProcedure;
            IList<ExcelEntitites> ExcelEntityList = new List<ExcelEntitites>();
            connection.Open();
            SqlDataReader dr = cmd.ExecuteReader();

            while (dr.Read())
            {
                ExcelEntitites ExcelEntity = new ExcelEntitites();
                ExcelEntity.P1 = dr["P1"].ToString();
                ExcelEntity.P2 = dr["P2"].ToString();
                ExcelEntity.P3 = dr["P3"].ToString();
                ExcelEntity.P4 = dr["P4"].ToString();
                ExcelEntity.P5 = dr["P5"].ToString();
                ExcelEntityList.Add(ExcelEntity);
            }
            return ExcelEntityList;
        }

        private static IList<ExcelEntitites> ChangeDataList(DateTime selectedDate, string application)
        {
            SqlConnection connection = new SqlConnection(clsGeneral.ConStr);
            SqlCommand cmd = new SqlCommand("spLoadWsrChangeDetails", connection);
            cmd.Parameters.AddWithValue("@dteSelectedDate", selectedDate.ToString("yyyyMMdd"));
            cmd.Parameters.AddWithValue("@vchApplication", application);
            cmd.CommandType = CommandType.StoredProcedure;
            IList<ExcelEntitites> ExcelEntityList = new List<ExcelEntitites>();
            connection.Open();
            SqlDataReader dr = cmd.ExecuteReader();
            while (dr.Read())
            {
                ExcelEntitites ExcelEntity = new ExcelEntitites();
                ExcelEntity.ChangeReferenceNumber = dr["ChangeReferenceNumber"].ToString();
                ExcelEntity.ChangeTicketType = dr["ChangeTicketType"].ToString();
                ExcelEntity.ChangeTicketTypeInDetail = dr["ChangeTicketTypeInDetail"].ToString();
                ExcelEntity.ChangePrtyPriority = dr["ChangePrtyPriority"].ToString();
                ExcelEntity.ChangeTicketStatus = dr["ChangeTicketStatus"].ToString();
                ExcelEntity.ChangeTcktDescription = dr["ChangeTcktDescription"].ToString();
                ExcelEntity.ChangeTcktAssignedDate = dr["ChangeTcktAssignedDate"].ToString();
                ExcelEntity.ChangeTcktResolvedDate = dr["ChangeTcktResolvedDate"].ToString();
                ExcelEntity.ChangeTcktComments = dr["ChangeTcktComments"].ToString();
                ExcelEntityList.Add(ExcelEntity);
            }
            return ExcelEntityList;
        }

        private static IList<ExcelEntitites> ProblemDataList(DateTime selectedDate, string application)
        {
            SqlConnection connection = new SqlConnection(clsGeneral.ConStr);
            SqlCommand cmd = new SqlCommand("spLoadWsrProblemDetails", connection);
            cmd.Parameters.AddWithValue("@dteSelectedDate", selectedDate.ToString("yyyyMMdd"));
            cmd.Parameters.AddWithValue("@vchApplication", application);
            cmd.CommandType = CommandType.StoredProcedure;
            IList<ExcelEntitites> ExcelEntityList = new List<ExcelEntitites>();
            connection.Open();
            SqlDataReader dr = cmd.ExecuteReader();

            while (dr.Read())
            {
                ExcelEntitites ExcelEntity = new ExcelEntitites();
                ExcelEntity.ProblemReferenceNumber = dr["ProblemReferenceNumber"].ToString();
                ExcelEntity.ProblemTicketType = dr["ProblemTicketType"].ToString();
                ExcelEntity.ProblemTicketTypeInDetail = dr["ProblemTicketTypeInDetail"].ToString();
                ExcelEntity.ProblemPrtyPriority = dr["ProblemPrtyPriority"].ToString();
                ExcelEntity.ProblemTicketStatus = dr["ProblemTicketStatus"].ToString();
                ExcelEntity.ProblemTcktDescription = dr["ProblemTcktDescription"].ToString();
                ExcelEntity.ProblemTcktAssignedDate = dr["ProblemTcktAssignedDate"].ToString();
                ExcelEntity.ProblemTcktResolvedDate = dr["ProblemTcktResolvedDate"].ToString();
                ExcelEntity.ProblemTcktComments = dr["ProblemTcktComments"].ToString();
                ExcelEntityList.Add(ExcelEntity);
            }
            return ExcelEntityList;
        }

        public static IList<ExcelEntitites> WsrExcelList(DateTime selectedDate, string application)
        {
            IList<ExcelEntitites> ExcelEntityListPriority = PriorityDataList(selectedDate, application);
            IList<ExcelEntitites> ExcelEntityListChangeDetails = ChangeDataList(selectedDate, application);
            IList<ExcelEntitites> ExcelEntityListProblemDetails = ProblemDataList(selectedDate, application);
            SqlConnection connection = new SqlConnection(clsGeneral.ConStr);
            SqlCommand cmd = new SqlCommand("spLoadWsrIncidentDetails", connection);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@dteSelectedDate", selectedDate.ToString("yyyyMMdd"));
            cmd.Parameters.AddWithValue("@vchApplication", application);
            connection.Open();
            SqlDataReader dr = cmd.ExecuteReader();

            IList<ExcelEntitites> ExcelEntityList = new List<ExcelEntitites>();
            int i = 0;
            if (dr.HasRows)
            {
                while (dr.Read())
                {
                    ExcelEntitites ExcelEntity = new ExcelEntitites();
                    ExcelEntity.IncidentReferenceNumber = dr["IncidentReferenceNumber"].ToString();
                    ExcelEntity.IncidentTicketType = dr["IncidentTicketType"].ToString();
                    ExcelEntity.IncidentTypeInDetail = dr["IncidentTypeInDetail"].ToString();
                    ExcelEntity.IncidentPriority = dr["IncidentPriority"].ToString();
                    ExcelEntity.IncidentStatus = dr["IncidentStatus"].ToString();
                    ExcelEntity.IncidentTicketType = dr["IncidentTicketType"].ToString();
                    ExcelEntity.IncidentDescription = dr["IncidentDescription"].ToString();
                    ExcelEntity.IncidentAssignedDate = dr["IncidentAssignedDate"].ToString();
                    ExcelEntity.IncidentResolvedDate = dr["IncidentResolvedDate"].ToString();
                    ExcelEntity.IncidentComments = dr["IncidentComments"].ToString();
                    ExcelEntity.IncidentInsertNewLine = "Incident";
                    ExcelEntity.ReportDate = DateTime.Now.ToString("dd/MMM/yyyy");
                    ExcelEntity.From = selectedDate.AddDays(-(int)(selectedDate.DayOfWeek - 1)).ToString("dd/MMM/yyyy");
                    ExcelEntity.To = selectedDate.AddDays(-(int)(selectedDate.DayOfWeek - 1)).AddDays(4).ToString("dd/MMM/yyyy");
                    ExcelEntity.Status = "Green";
                    //if (i == 0)
                    //{
                    ExcelEntity.P1_Outstanding = ExcelEntityListPriority[0].P1;
                    ExcelEntity.P2_Outstanding = ExcelEntityListPriority[0].P2;
                    ExcelEntity.P3_Outstanding = ExcelEntityListPriority[0].P3;
                    ExcelEntity.P4_Outstanding = ExcelEntityListPriority[0].P4;
                    ExcelEntity.P5_Outstanding = ExcelEntityListPriority[0].P5;

                    ExcelEntity.P1_Current = ExcelEntityListPriority[1].P1;
                    ExcelEntity.P2_Current = ExcelEntityListPriority[1].P2;
                    ExcelEntity.P3_Current = ExcelEntityListPriority[1].P3;
                    ExcelEntity.P4_Current = ExcelEntityListPriority[1].P4;
                    ExcelEntity.P5_Current = ExcelEntityListPriority[1].P5;

                    ExcelEntity.P1_Resolved = ExcelEntityListPriority[2].P1;
                    ExcelEntity.P2_Resolved = ExcelEntityListPriority[2].P2;
                    ExcelEntity.P3_Resolved = ExcelEntityListPriority[2].P3;
                    ExcelEntity.P4_Resolved = ExcelEntityListPriority[2].P4;
                    ExcelEntity.P5_Resolved = ExcelEntityListPriority[2].P5;

                    ExcelEntity.P1_Worked = ExcelEntityListPriority[3].P1;
                    ExcelEntity.P2_Worked = ExcelEntityListPriority[3].P2;
                    ExcelEntity.P3_Worked = ExcelEntityListPriority[3].P3;
                    ExcelEntity.P4_Worked = ExcelEntityListPriority[3].P4;
                    ExcelEntity.P5_Worked = ExcelEntityListPriority[3].P5;

                    ExcelEntity.P1_DiffTeam = ExcelEntityListPriority[4].P1;
                    ExcelEntity.P2_DiffTeam = ExcelEntityListPriority[4].P2;
                    ExcelEntity.P3_DiffTeam = ExcelEntityListPriority[4].P3;
                    ExcelEntity.P4_DiffTeam = ExcelEntityListPriority[4].P4;
                    ExcelEntity.P5_DiffTeam = ExcelEntityListPriority[4].P5;

                    ExcelEntity.P1_Pending = ExcelEntityListPriority[5].P1;
                    ExcelEntity.P2_Pending = ExcelEntityListPriority[5].P2;
                    ExcelEntity.P3_Pending = ExcelEntityListPriority[5].P3;
                    ExcelEntity.P4_Pending = ExcelEntityListPriority[5].P4;
                    ExcelEntity.P5_Pending = ExcelEntityListPriority[5].P5;

                    ExcelEntity.P1_Problem = ExcelEntityListPriority[6].P1;
                    ExcelEntity.P2_Problem = ExcelEntityListPriority[6].P2;
                    ExcelEntity.P3_Problem = ExcelEntityListPriority[6].P3;
                    ExcelEntity.P4_Problem = ExcelEntityListPriority[6].P4;
                    ExcelEntity.P5_Problem = ExcelEntityListPriority[6].P5;
                    //}

                    //else
                    //{
                    //    ExcelEntity.P1_Outstanding = string.Empty;
                    //    ExcelEntity.P2_Outstanding = string.Empty;
                    //    ExcelEntity.P3_Outstanding = string.Empty;
                    //    ExcelEntity.P4_Outstanding = string.Empty;
                    //    ExcelEntity.P5_Outstanding = string.Empty;

                    //    ExcelEntity.P1_Current = string.Empty;
                    //    ExcelEntity.P2_Current = string.Empty;
                    //    ExcelEntity.P3_Current = string.Empty;
                    //    ExcelEntity.P4_Current = string.Empty;
                    //    ExcelEntity.P5_Current = string.Empty;

                    //    ExcelEntity.P1_Resolved = string.Empty;
                    //    ExcelEntity.P2_Resolved = string.Empty;
                    //    ExcelEntity.P3_Resolved = string.Empty;
                    //    ExcelEntity.P4_Resolved = string.Empty;
                    //    ExcelEntity.P5_Resolved = string.Empty;

                    //    ExcelEntity.P1_Worked = string.Empty;
                    //    ExcelEntity.P2_Worked = string.Empty;
                    //    ExcelEntity.P3_Worked = string.Empty;
                    //    ExcelEntity.P4_Worked = string.Empty;
                    //    ExcelEntity.P5_Worked = string.Empty;

                    //    ExcelEntity.P1_DiffTeam = string.Empty;
                    //    ExcelEntity.P2_DiffTeam = string.Empty;
                    //    ExcelEntity.P3_DiffTeam = string.Empty;
                    //    ExcelEntity.P4_DiffTeam = string.Empty;
                    //    ExcelEntity.P5_DiffTeam = string.Empty;

                    //    ExcelEntity.P1_Pending = string.Empty;
                    //    ExcelEntity.P2_Pending = string.Empty;
                    //    ExcelEntity.P3_Pending = string.Empty;
                    //    ExcelEntity.P4_Pending = string.Empty;
                    //    ExcelEntity.P5_Pending = string.Empty;

                    //    ExcelEntity.P1_Problem = string.Empty;
                    //    ExcelEntity.P2_Problem = string.Empty;
                    //    ExcelEntity.P3_Problem = string.Empty;
                    //    ExcelEntity.P4_Problem = string.Empty;
                    //    ExcelEntity.P5_Problem = string.Empty;
                    //}
                    i++;
                    ExcelEntityList.Add(ExcelEntity);
                }
            }
            else
            {
                ExcelEntitites ExcelEntity = new ExcelEntitites();
                //ExcelEntity.ReferenceNumber = dr["ReferenceNumber"].ToString();
                //ExcelEntity.TicketType = dr["TicketType"].ToString();
                //ExcelEntity.TicketTypeInDetail = dr["TicketTypeInDetail"].ToString();
                //ExcelEntity.PrtyPriority = dr["PriorityId"].ToString();
                //ExcelEntity.TicketStatus = dr["TicketStatus"].ToString();
                //ExcelEntity.TicketType = dr["TicketType"].ToString();
                //ExcelEntity.TcktDescription = dr["Description"].ToString();
                //ExcelEntity.TcktAssignedDate = dr["AssignedDate"].ToString();
                //ExcelEntity.TcktResolvedDate = dr["ResolvedDate"].ToString();
                //ExcelEntity.TcktComments = dr["Comments"].ToString();
                ExcelEntity.IncidentReferenceNumber = string.Empty;
                ExcelEntity.IncidentTicketType = string.Empty;
                ExcelEntity.IncidentPriority = string.Empty;
                ExcelEntity.IncidentStatus = string.Empty;
                ExcelEntity.IncidentTicketType = string.Empty;
                ExcelEntity.IncidentTypeInDetail = string.Empty;
                ExcelEntity.IncidentDescription = string.Empty;
                ExcelEntity.IncidentAssignedDate = string.Empty;
                ExcelEntity.IncidentResolvedDate = string.Empty;
                ExcelEntity.IncidentComments = string.Empty;
                ExcelEntity.IncidentInsertNewLine = string.Empty;
                ExcelEntity.ReportDate = DateTime.Now.ToString("dd/MMM/yyyy");
                ExcelEntity.From = selectedDate.AddDays(-(int)(selectedDate.DayOfWeek - 1)).ToString("dd/MMM/yyyy");
                ExcelEntity.To = selectedDate.AddDays(-(int)(selectedDate.DayOfWeek - 1)).AddDays(4).ToString("dd/MMM/yyyy");
                ExcelEntity.Status = "Green";
                //if (i == 0)
                //{
                ExcelEntity.P1_Outstanding = ExcelEntityListPriority[0].P1;
                ExcelEntity.P2_Outstanding = ExcelEntityListPriority[0].P2;
                ExcelEntity.P3_Outstanding = ExcelEntityListPriority[0].P3;
                ExcelEntity.P4_Outstanding = ExcelEntityListPriority[0].P4;
                ExcelEntity.P5_Outstanding = ExcelEntityListPriority[0].P5;

                ExcelEntity.P1_Current = ExcelEntityListPriority[1].P1;
                ExcelEntity.P2_Current = ExcelEntityListPriority[1].P2;
                ExcelEntity.P3_Current = ExcelEntityListPriority[1].P3;
                ExcelEntity.P4_Current = ExcelEntityListPriority[1].P4;
                ExcelEntity.P5_Current = ExcelEntityListPriority[1].P5;

                ExcelEntity.P1_Resolved = ExcelEntityListPriority[2].P1;
                ExcelEntity.P2_Resolved = ExcelEntityListPriority[2].P2;
                ExcelEntity.P3_Resolved = ExcelEntityListPriority[2].P3;
                ExcelEntity.P4_Resolved = ExcelEntityListPriority[2].P4;
                ExcelEntity.P5_Resolved = ExcelEntityListPriority[2].P5;

                ExcelEntity.P1_Worked = ExcelEntityListPriority[3].P1;
                ExcelEntity.P2_Worked = ExcelEntityListPriority[3].P2;
                ExcelEntity.P3_Worked = ExcelEntityListPriority[3].P3;
                ExcelEntity.P4_Worked = ExcelEntityListPriority[3].P4;
                ExcelEntity.P5_Worked = ExcelEntityListPriority[3].P5;

                ExcelEntity.P1_DiffTeam = ExcelEntityListPriority[4].P1;
                ExcelEntity.P2_DiffTeam = ExcelEntityListPriority[4].P2;
                ExcelEntity.P3_DiffTeam = ExcelEntityListPriority[4].P3;
                ExcelEntity.P4_DiffTeam = ExcelEntityListPriority[4].P4;
                ExcelEntity.P5_DiffTeam = ExcelEntityListPriority[4].P5;

                ExcelEntity.P1_Pending = ExcelEntityListPriority[5].P1;
                ExcelEntity.P2_Pending = ExcelEntityListPriority[5].P2;
                ExcelEntity.P3_Pending = ExcelEntityListPriority[5].P3;
                ExcelEntity.P4_Pending = ExcelEntityListPriority[5].P4;
                ExcelEntity.P5_Pending = ExcelEntityListPriority[5].P5;

                ExcelEntity.P1_Problem = ExcelEntityListPriority[6].P1;
                ExcelEntity.P2_Problem = ExcelEntityListPriority[6].P2;
                ExcelEntity.P3_Problem = ExcelEntityListPriority[6].P3;
                ExcelEntity.P4_Problem = ExcelEntityListPriority[6].P4;
                ExcelEntity.P5_Problem = ExcelEntityListPriority[6].P5;
                ExcelEntityList.Add(ExcelEntity);
            }
            int j = 0;
            foreach (ExcelEntitites exet in ExcelEntityList)
            {
                if (j < ExcelEntityList.Count)
                {
                    if (ExcelEntityListChangeDetails.Count > j)
                    {
                        exet.ChangeReferenceNumber = ExcelEntityListChangeDetails[j].ChangeReferenceNumber;
                        exet.ChangeTicketType = ExcelEntityListChangeDetails[j].ChangeTicketType;
                        exet.ChangeTicketTypeInDetail = ExcelEntityListChangeDetails[j].ChangeTicketTypeInDetail;
                        exet.ChangePrtyPriority = ExcelEntityListChangeDetails[j].ChangePrtyPriority;
                        exet.ChangeTicketStatus = ExcelEntityListChangeDetails[j].ChangeTicketStatus;
                        exet.ChangeTcktDescription = ExcelEntityListChangeDetails[j].ChangeTcktDescription;
                        exet.ChangeTcktAssignedDate = ExcelEntityListChangeDetails[j].ChangeTcktAssignedDate;
                        exet.ChangeTcktResolvedDate = ExcelEntityListChangeDetails[j].ChangeTcktResolvedDate;
                        exet.ChangeTcktComments = ExcelEntityListChangeDetails[j].ChangeTcktComments;
                        exet.ChangeInsertNewLine = "Change";
                    }
                    else
                    {
                        exet.ChangeReferenceNumber = string.Empty;
                        exet.ChangeTicketType = string.Empty;
                        exet.ChangeTicketTypeInDetail = string.Empty;
                        exet.ChangePrtyPriority = string.Empty;
                        exet.ChangeTicketStatus = string.Empty;
                        exet.ChangeTcktDescription = string.Empty;
                        exet.ChangeTcktAssignedDate = string.Empty;
                        exet.ChangeTcktResolvedDate = string.Empty;
                        exet.ChangeTcktComments = string.Empty;
                        exet.ChangeInsertNewLine = string.Empty;
                    }
                }
                j++;
            }
            if (ExcelEntityListChangeDetails.Count > ExcelEntityList.Count)
            {
                for (int k = j; k < ExcelEntityListChangeDetails.Count; k++)
                {
                    ExcelEntitites excelEntity = new ExcelEntitites();
                    excelEntity.IncidentReferenceNumber = string.Empty;
                    excelEntity.IncidentTicketType = string.Empty;
                    excelEntity.IncidentPriority = string.Empty;
                    excelEntity.IncidentStatus = string.Empty;
                    excelEntity.IncidentTicketType = string.Empty;
                    excelEntity.IncidentTypeInDetail = string.Empty;
                    excelEntity.IncidentDescription = string.Empty;
                    excelEntity.IncidentAssignedDate = string.Empty;
                    excelEntity.IncidentResolvedDate = string.Empty;
                    excelEntity.IncidentComments = string.Empty;
                    excelEntity.IncidentInsertNewLine = string.Empty;
                    excelEntity.ReportDate = DateTime.Now.ToString("dd/MMM/yyyy");
                    excelEntity.From = selectedDate.AddDays(-(int)(selectedDate.DayOfWeek - 1)).ToString("dd/MMM/yyyy");
                    excelEntity.To = selectedDate.AddDays(-(int)(selectedDate.DayOfWeek - 1)).AddDays(4).ToString("dd/MMM/yyyy");
                    excelEntity.Status = "Green";
                    excelEntity.P1_Outstanding = ExcelEntityListPriority[0].P1;
                    excelEntity.P2_Outstanding = ExcelEntityListPriority[0].P2;
                    excelEntity.P3_Outstanding = ExcelEntityListPriority[0].P3;
                    excelEntity.P4_Outstanding = ExcelEntityListPriority[0].P4;
                    excelEntity.P5_Outstanding = ExcelEntityListPriority[0].P5;

                    excelEntity.P1_Current = ExcelEntityListPriority[1].P1;
                    excelEntity.P2_Current = ExcelEntityListPriority[1].P2;
                    excelEntity.P3_Current = ExcelEntityListPriority[1].P3;
                    excelEntity.P4_Current = ExcelEntityListPriority[1].P4;
                    excelEntity.P5_Current = ExcelEntityListPriority[1].P5;

                    excelEntity.P1_Resolved = ExcelEntityListPriority[2].P1;
                    excelEntity.P2_Resolved = ExcelEntityListPriority[2].P2;
                    excelEntity.P3_Resolved = ExcelEntityListPriority[2].P3;
                    excelEntity.P4_Resolved = ExcelEntityListPriority[2].P4;
                    excelEntity.P5_Resolved = ExcelEntityListPriority[2].P5;

                    excelEntity.P1_Worked = ExcelEntityListPriority[3].P1;
                    excelEntity.P2_Worked = ExcelEntityListPriority[3].P2;
                    excelEntity.P3_Worked = ExcelEntityListPriority[3].P3;
                    excelEntity.P4_Worked = ExcelEntityListPriority[3].P4;
                    excelEntity.P5_Worked = ExcelEntityListPriority[3].P5;

                    excelEntity.P1_DiffTeam = ExcelEntityListPriority[4].P1;
                    excelEntity.P2_DiffTeam = ExcelEntityListPriority[4].P2;
                    excelEntity.P3_DiffTeam = ExcelEntityListPriority[4].P3;
                    excelEntity.P4_DiffTeam = ExcelEntityListPriority[4].P4;
                    excelEntity.P5_DiffTeam = ExcelEntityListPriority[4].P5;

                    excelEntity.P1_Pending = ExcelEntityListPriority[5].P1;
                    excelEntity.P2_Pending = ExcelEntityListPriority[5].P2;
                    excelEntity.P3_Pending = ExcelEntityListPriority[5].P3;
                    excelEntity.P4_Pending = ExcelEntityListPriority[5].P4;
                    excelEntity.P5_Pending = ExcelEntityListPriority[5].P5;

                    excelEntity.P1_Problem = ExcelEntityListPriority[6].P1;
                    excelEntity.P2_Problem = ExcelEntityListPriority[6].P2;
                    excelEntity.P3_Problem = ExcelEntityListPriority[6].P3;
                    excelEntity.P4_Problem = ExcelEntityListPriority[6].P4;
                    excelEntity.P5_Problem = ExcelEntityListPriority[6].P5;

                    excelEntity.ChangeReferenceNumber = ExcelEntityListChangeDetails[k].ChangeReferenceNumber;
                    excelEntity.ChangeTicketType = ExcelEntityListChangeDetails[k].ChangeTicketType;
                    excelEntity.ChangeTicketTypeInDetail = ExcelEntityListChangeDetails[k].ChangeTicketTypeInDetail;
                    excelEntity.ChangePrtyPriority = ExcelEntityListChangeDetails[k].ChangePrtyPriority;
                    excelEntity.ChangeTicketStatus = ExcelEntityListChangeDetails[k].ChangeTicketStatus;
                    excelEntity.ChangeTcktDescription = ExcelEntityListChangeDetails[k].ChangeTcktDescription;
                    excelEntity.ChangeTcktAssignedDate = ExcelEntityListChangeDetails[k].ChangeTcktAssignedDate;
                    excelEntity.ChangeTcktResolvedDate = ExcelEntityListChangeDetails[k].ChangeTcktResolvedDate;
                    excelEntity.ChangeTcktComments = ExcelEntityListChangeDetails[k].ChangeTcktComments;
                    excelEntity.ChangeInsertNewLine = ExcelEntityListChangeDetails[k].ChangeInsertNewLine;
                    ExcelEntityList.Add(excelEntity);
                }
            }
            int p = 0;
            foreach (ExcelEntitites exet in ExcelEntityList)
            {
                if (p < ExcelEntityList.Count)
                {
                    if (ExcelEntityListProblemDetails.Count > p)
                    {
                        exet.ProblemReferenceNumber = ExcelEntityListProblemDetails[p].ProblemReferenceNumber;
                        exet.ProblemTicketType = ExcelEntityListProblemDetails[p].ProblemTicketType;
                        exet.ProblemTicketTypeInDetail = ExcelEntityListProblemDetails[p].ProblemTicketTypeInDetail;
                        exet.ProblemPrtyPriority = ExcelEntityListProblemDetails[p].ProblemPrtyPriority;
                        exet.ProblemTicketStatus = ExcelEntityListProblemDetails[p].ProblemTicketStatus;
                        exet.ProblemTcktDescription = ExcelEntityListProblemDetails[p].ProblemTcktDescription;
                        exet.ProblemTcktAssignedDate = ExcelEntityListProblemDetails[p].ProblemTcktAssignedDate;
                        exet.ProblemTcktResolvedDate = ExcelEntityListProblemDetails[p].ProblemTcktResolvedDate;
                        exet.ProblemTcktComments = ExcelEntityListProblemDetails[p].ProblemTcktComments;
                        exet.ProblemInsertNewLine = "Problem";
                    }
                    else
                    {
                        exet.ProblemReferenceNumber = string.Empty;
                        exet.ProblemTicketType = string.Empty;
                        exet.ProblemTicketTypeInDetail = string.Empty;
                        exet.ProblemPrtyPriority = string.Empty;
                        exet.ProblemTicketStatus = string.Empty;
                        exet.ProblemTcktDescription = string.Empty;
                        exet.ProblemTcktAssignedDate = string.Empty;
                        exet.ProblemTcktResolvedDate = string.Empty;
                        exet.ProblemTcktComments = string.Empty;
                        exet.ProblemInsertNewLine = string.Empty;
                    }
                }
                p++;
            }
            if (ExcelEntityListProblemDetails.Count > ExcelEntityList.Count)
            {
                for (int k = p; k < ExcelEntityListProblemDetails.Count; k++)
                {
                    ExcelEntitites excelEntity = new ExcelEntitites();
                    excelEntity.IncidentReferenceNumber = string.Empty;
                    excelEntity.IncidentTicketType = string.Empty;
                    excelEntity.IncidentPriority = string.Empty;
                    excelEntity.IncidentStatus = string.Empty;
                    excelEntity.IncidentTicketType = string.Empty;
                    excelEntity.IncidentTypeInDetail = string.Empty;
                    excelEntity.IncidentDescription = string.Empty;
                    excelEntity.IncidentAssignedDate = string.Empty;
                    excelEntity.IncidentResolvedDate = string.Empty;
                    excelEntity.IncidentComments = string.Empty;
                    excelEntity.IncidentInsertNewLine = string.Empty;
                    excelEntity.ReportDate = DateTime.Now.ToString("dd/MMM/yyyy");
                    excelEntity.From = selectedDate.AddDays(-(int)(selectedDate.DayOfWeek - 1)).ToString("dd/MMM/yyyy");
                    excelEntity.To = selectedDate.AddDays(-(int)(selectedDate.DayOfWeek - 1)).AddDays(4).ToString("dd/MMM/yyyy");
                    excelEntity.Status = "Green";

                    excelEntity.P1_Outstanding = ExcelEntityListPriority[0].P1;
                    excelEntity.P2_Outstanding = ExcelEntityListPriority[0].P2;
                    excelEntity.P3_Outstanding = ExcelEntityListPriority[0].P3;
                    excelEntity.P4_Outstanding = ExcelEntityListPriority[0].P4;
                    excelEntity.P5_Outstanding = ExcelEntityListPriority[0].P5;

                    excelEntity.P1_Current = ExcelEntityListPriority[1].P1;
                    excelEntity.P2_Current = ExcelEntityListPriority[1].P2;
                    excelEntity.P3_Current = ExcelEntityListPriority[1].P3;
                    excelEntity.P4_Current = ExcelEntityListPriority[1].P4;
                    excelEntity.P5_Current = ExcelEntityListPriority[1].P5;

                    excelEntity.P1_Resolved = ExcelEntityListPriority[2].P1;
                    excelEntity.P2_Resolved = ExcelEntityListPriority[2].P2;
                    excelEntity.P3_Resolved = ExcelEntityListPriority[2].P3;
                    excelEntity.P4_Resolved = ExcelEntityListPriority[2].P4;
                    excelEntity.P5_Resolved = ExcelEntityListPriority[2].P5;

                    excelEntity.P1_Worked = ExcelEntityListPriority[3].P1;
                    excelEntity.P2_Worked = ExcelEntityListPriority[3].P2;
                    excelEntity.P3_Worked = ExcelEntityListPriority[3].P3;
                    excelEntity.P4_Worked = ExcelEntityListPriority[3].P4;
                    excelEntity.P5_Worked = ExcelEntityListPriority[3].P5;

                    excelEntity.P1_DiffTeam = ExcelEntityListPriority[4].P1;
                    excelEntity.P2_DiffTeam = ExcelEntityListPriority[4].P2;
                    excelEntity.P3_DiffTeam = ExcelEntityListPriority[4].P3;
                    excelEntity.P4_DiffTeam = ExcelEntityListPriority[4].P4;
                    excelEntity.P5_DiffTeam = ExcelEntityListPriority[4].P5;

                    excelEntity.P1_Pending = ExcelEntityListPriority[5].P1;
                    excelEntity.P2_Pending = ExcelEntityListPriority[5].P2;
                    excelEntity.P3_Pending = ExcelEntityListPriority[5].P3;
                    excelEntity.P4_Pending = ExcelEntityListPriority[5].P4;
                    excelEntity.P5_Pending = ExcelEntityListPriority[5].P5;

                    excelEntity.P1_Problem = ExcelEntityListPriority[6].P1;
                    excelEntity.P2_Problem = ExcelEntityListPriority[6].P2;
                    excelEntity.P3_Problem = ExcelEntityListPriority[6].P3;
                    excelEntity.P4_Problem = ExcelEntityListPriority[6].P4;
                    excelEntity.P5_Problem = ExcelEntityListPriority[6].P5;

                    excelEntity.ChangeReferenceNumber = string.Empty;
                    excelEntity.ChangeTicketType = string.Empty;
                    excelEntity.ChangeTicketTypeInDetail = string.Empty;
                    excelEntity.ChangePrtyPriority = string.Empty;
                    excelEntity.ChangeTicketStatus = string.Empty;
                    excelEntity.ChangeTcktDescription = string.Empty;
                    excelEntity.ChangeTcktAssignedDate = string.Empty;
                    excelEntity.ChangeTcktResolvedDate = string.Empty;
                    excelEntity.ChangeTcktComments = string.Empty;
                    excelEntity.ChangeInsertNewLine = string.Empty;
                    excelEntity.ProblemReferenceNumber = ExcelEntityListProblemDetails[k].ProblemReferenceNumber;
                    excelEntity.ProblemTicketType = ExcelEntityListProblemDetails[k].ProblemTicketType;
                    excelEntity.ProblemTicketTypeInDetail = ExcelEntityListProblemDetails[k].ProblemTicketTypeInDetail;
                    excelEntity.ProblemPrtyPriority = ExcelEntityListProblemDetails[k].ProblemPrtyPriority;
                    excelEntity.ProblemTicketStatus = ExcelEntityListProblemDetails[k].ProblemTicketStatus;
                    excelEntity.ProblemTcktDescription = ExcelEntityListProblemDetails[k].ProblemTcktDescription;
                    excelEntity.ProblemTcktAssignedDate = ExcelEntityListProblemDetails[k].ProblemTcktAssignedDate;
                    excelEntity.ProblemTcktResolvedDate = ExcelEntityListProblemDetails[k].ProblemTcktResolvedDate;
                    excelEntity.ProblemTcktComments = ExcelEntityListProblemDetails[k].ProblemTcktComments;
                    excelEntity.ProblemInsertNewLine = ExcelEntityListProblemDetails[k].ProblemInsertNewLine;
                    ExcelEntityList.Add(excelEntity);
                }
            }
            return ExcelEntityList;
        }

        public static IList<WSRGraphEntities> WsrGraphsData(DateTime selectedDate)
        {
            IList<WSRGraphEntities> graphEntityList = new List<WSRGraphEntities>();
            try
            {
                SqlCommand cmd = new SqlCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "dbo.spGenerateWsrGraphsData";
                cmd.CommandTimeout = 0;
                cmd.Connection = new SqlConnection(clsGeneral.ConStr);
                SqlParameter[] param = new SqlParameter[1];
                param[0] = new SqlParameter("@dteSelectedDate", selectedDate.ToString("yyyyMMdd"));

                cmd.Connection.Open();
                SqlDataReader dr = SqlHelper.ExecuteReader(cmd.Connection, cmd.CommandType, cmd.CommandText, param);

                while (dr.Read())
                {
                    WSRGraphEntities graphEntities = new WSRGraphEntities();
                    //Charisma Graph Entities
                    graphEntities.charismaOutStanding = dr["charismaOutStanding"].ToString();
                    graphEntities.charismaCurrentWeek = dr["charismaCurrentWeek"].ToString();
                    graphEntities.charismaResolved = dr["charismaResolved"].ToString();
                    graphEntities.charismaWorked = dr["charismaWorked"].ToString();
                    graphEntities.charismaAssignedToDifferentTeam = dr["charismaAssignedToDifferentTeam"].ToString();
                    graphEntities.charismaPending = dr["charismaPending"].ToString();
                    graphEntities.charismaProblemManagement = dr["charismaProblemManagement"].ToString();
                    graphEntities.charismaWeekEnding = dr["charismaWeekEnding"].ToString();
                    graphEntities.charismaStatusWIP = dr["charismaStatusWIP"].ToString();
                    graphEntities.charismaStatusPendingUAT = dr["charismaStatusPendingUAT"].ToString();
                    graphEntities.charismaStatusHold = dr["charismaStatusHold"].ToString();
                    graphEntities.charismaStatusPIR = dr["charismaStatusPIR"].ToString();
                    graphEntities.charismaStatusYetToStart = dr["charismaStatusYetToStart"].ToString();
                    graphEntities.charismaStatusRFC = dr["charismaStatusRFC"].ToString();
                    graphEntities.charismaStatusRFR = dr["charismaStatusRFR"].ToString();
                    //Fred Graph Entities
                    graphEntities.fredOutStanding = dr["fredOutStanding"].ToString();
                    graphEntities.fredCurrentWeek = dr["fredCurrentWeek"].ToString();
                    graphEntities.fredResolved = dr["fredResolved"].ToString();
                    graphEntities.fredWorked = dr["fredWorked"].ToString();
                    graphEntities.fredAssignedToDifferentTeam = dr["fredAssignedToDifferentTeam"].ToString();
                    graphEntities.fredPending = dr["fredPending"].ToString();
                    graphEntities.fredProblemManagement = dr["fredProblemManagement"].ToString();
                    graphEntities.fredWeekEnding = dr["fredWeekEnding"].ToString();
                    graphEntities.fredStatusWIP = dr["fredStatusWIP"].ToString();
                    graphEntities.fredStatusPendingUAT = dr["fredStatusPendingUAT"].ToString();
                    graphEntities.fredStatusHold = dr["fredStatusHold"].ToString();
                    graphEntities.fredStatusPIR = dr["fredStatusPIR"].ToString();
                    graphEntities.fredStatusYetToStart = dr["fredStatusYetToStart"].ToString();
                    graphEntities.fredStatusRFC = dr["fredStatusRFC"].ToString();
                    graphEntities.fredStatusRFR = dr["fredStatusRFR"].ToString();
                    //Share Point Graph Entities
                    graphEntities.sharepointOutStanding = dr["sharepointOutStanding"].ToString();
                    graphEntities.sharepointCurrentWeek = dr["sharepointCurrentWeek"].ToString();
                    graphEntities.sharepointResolved = dr["sharepointResolved"].ToString();
                    graphEntities.sharepointWorked = dr["sharepointWorked"].ToString();
                    graphEntities.sharepointAssignedToDifferentTeam = dr["sharepointAssignedToDifferentTeam"].ToString();
                    graphEntities.sharepointPending = dr["sharepointPending"].ToString();
                    graphEntities.sharepointProblemManagement = dr["sharepointProblemManagement"].ToString();
                    graphEntities.sharepointWeekEnding = dr["sharepointWeekEnding"].ToString();
                    graphEntities.sharepointStatusWIP = dr["sharepointStatusWIP"].ToString();
                    graphEntities.sharepointStatusPendingUAT = dr["sharepointStatusPendingUAT"].ToString();
                    graphEntities.sharepointStatusHold = dr["sharepointStatusHold"].ToString();
                    graphEntities.sharepointStatusPIR = dr["sharepointStatusPIR"].ToString();
                    graphEntities.sharepointStatusYetToStart = dr["sharepointStatusYetToStart"].ToString();
                    graphEntities.sharepointStatusRFC = dr["sharepointStatusRFC"].ToString();
                    graphEntities.sharepointStatusRFR = dr["sharepointStatusRFR"].ToString();
                    graphEntityList.Add(graphEntities);
                }
                cmd.Connection.Close();
            }
            catch (Exception ex)
            {
                PMAssistReleaseVersion.AppCode.ErrorLogging.clsErrorLogging.LogError(ex.Message, "clsReports.cs", "WsrGraphsData()");
            }
            return graphEntityList;
            //cmd.Parameters.AddWithValue("@dteSelectedDate", selectedDate.ToString("yyyyMMdd"));
            //cmd.CommandType = CommandType.StoredProcedure;
            //cmd.Connection = new SqlConnection(clsGeneral.ConStr);
            //cmd.CommandText = "dbo.spGenerateWsrGraphsData";
            //var ds = SqlHelper.ExecuteDataset(cmd.Connection.ConnectionString, cmd.CommandType, cmd.CommandText, cmd);
            //if (ds != null && ds.Tables.Count == 8)
            //{
            //    string[] graphHeadings = new string[] { "OutStanding", "CurrentWeek",
            //                                            "Resolved","Worked",
            //                                            "AssignedToDifferentTeam",
            //                                            "Pending", "ProblemManagement",
            //                                            "WeekEnding"};
            //foreach (DataTable dt in ds.Tables)
            //{
            //    dt.TableName = graphHeadings[ds.Tables.IndexOf(dt)];
            //}
            //foreach (DataTable dt in ds.Tables)
            //{
            //    foreach (DataRow dr in dt.Rows)
            //    {

            //        string graphHeadingName = graphHeadings[ds.Tables.IndexOf(dt)];
            //        if (dt.Columns[0].ColumnName == graphHeadingName)
            //        {
            //            graphEntities.OutStanding = dr[graphHeadingName].ToString();
            //        }
            //        graphEntityList.Add(graphEntities);
            //    }
            //}
        }

        public static IList<SLACharismaKpi> SlaCharismaKpi(int month, int year)
        {
            DateTime firstDayOfCurrentMonth = new DateTime(year, month, 1);
            DateTime firstDayOfPreviousMonth = firstDayOfCurrentMonth.AddMonths(-1);
            string slaCurrentMonth = firstDayOfCurrentMonth.ToString("MMM") + "'" + firstDayOfCurrentMonth.Year.ToString().Substring(2);
            string slaLastMonth = firstDayOfPreviousMonth.ToString("MMM") + "'" + firstDayOfPreviousMonth.Year.ToString().Substring(2);
            string from = "From: " + firstDayOfCurrentMonth.Day + "-" + firstDayOfCurrentMonth.ToString("MMM") + "-" + firstDayOfCurrentMonth.Year;
            string to = "To: " + DateTime.DaysInMonth(firstDayOfCurrentMonth.Year, firstDayOfCurrentMonth.Month) + "-" + firstDayOfCurrentMonth.ToString("MMM") + "-" + firstDayOfCurrentMonth.Year;
            IList<SLACharismaKpi> ExcelEntityList = new List<SLACharismaKpi>();
            try
            {
                SqlCommand cmd = new SqlCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "dbo.spGenerateSLAKPIResults";
                cmd.CommandTimeout = 0;
                cmd.Connection = new SqlConnection(clsGeneral.ConStr);
                SqlParameter[] param = new SqlParameter[2];
                param[0] = new SqlParameter("@intMonth", month);
                param[1] = new SqlParameter("@intYear", year);
                cmd.Connection.Open();
                SqlDataReader dr = SqlHelper.ExecuteReader(cmd.Connection, cmd.CommandType, cmd.CommandText, param);

                while (dr.Read())
                {
                    SLACharismaKpi ExcelEntity = new SLACharismaKpi();
                    ExcelEntity.Target = dr["Target"].ToString();
                    ExcelEntity.CurrentMonthAchieved = dr["CurrentMonthAchieved"].ToString();
                    ExcelEntity.CurrentMonthVolume = dr["CurrentMonthVolume"].ToString();
                    ExcelEntity.LastMonthAchieved = dr["LastMonthAchieved"].ToString();
                    ExcelEntity.LastMonthVolume = dr["LastMonthVolume"].ToString();
                    ExcelEntity.SlaCurrentMonth = slaCurrentMonth;
                    ExcelEntity.SlaLastMonth = slaLastMonth;
                    ExcelEntity.SlaFromDate = from;
                    ExcelEntity.SlaToDate = to;
                    ExcelEntityList.Add(ExcelEntity);
                }
                cmd.Connection.Close();

            }
            catch (Exception ex)
            {
                PMAssistReleaseVersion.AppCode.ErrorLogging.clsErrorLogging.LogError(ex.Message, "clsReports.cs", "SlaCharismaKpi()");
            }
            return ExcelEntityList;
        }

        public static IList<SLAResolvedTicketsDetails> SlaResolvedTicketDetails(int month, int year)
        {
            IList<SLAResolvedTicketsDetails> ExcelEntityList = new List<SLAResolvedTicketsDetails>();
            try
            {
                SqlCommand cmd = new SqlCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "dbo.spGenerateSlaResolvedTicketDetails";
                cmd.CommandTimeout = 0;
                cmd.Connection = new SqlConnection(clsGeneral.ConStr);
                SqlParameter[] param = new SqlParameter[2];
                param[0] = new SqlParameter("@intMonth", month);
                param[1] = new SqlParameter("@intYear", year);
                cmd.Connection.Open();
                SqlDataReader dr = SqlHelper.ExecuteReader(cmd.Connection, cmd.CommandType, cmd.CommandText, param);

                while (dr.Read())
                {
                    SLAResolvedTicketsDetails ExcelEntity = new SLAResolvedTicketsDetails();
                    ExcelEntity.SlNo = dr["SlNo"].ToString();
                    ExcelEntity.ReferenceNo = dr["ReferenceNo"].ToString();
                    ExcelEntity.IncidentChangeProblem = dr["IncidentChangeProblem"].ToString();
                    ExcelEntity.Type = dr["Type"].ToString();
                    ExcelEntity.Priority = dr["Priority"].ToString();
                    ExcelEntity.AssignedDate = dr["AssignedDate"].ToString();
                    ExcelEntity.ResolvedDate = dr["ResolvedDate"].ToString();
                    ExcelEntity.TargetDate = dr["TargetDate"].ToString();
                    ExcelEntity.InternalKpisMet = dr["InternalKpisMet"].ToString();
                    ExcelEntity.EndToEndKpisMet = dr["EndToEndKpisMet"].ToString();
                    ExcelEntity.Comments = dr["Comments"].ToString();
                    ExcelEntityList.Add(ExcelEntity);
                }
                cmd.Connection.Close();

            }
            catch (Exception ex)
            {
                PMAssistReleaseVersion.AppCode.ErrorLogging.clsErrorLogging.LogError(ex.Message, "clsReports.cs", "SlaCharismaKpi()");
            }
            return ExcelEntityList;
        }

        // Validate static Fields

        public static ArrayList GetReportStaticFields()
        {
            try
            {
                ArrayList wsrStaticFields = new ArrayList();
                using (SqlConnection connection = new SqlConnection(clsGeneral.ConStr))
                {
                    SqlCommand cmd = new SqlCommand();
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "dbo.spGetReportStaticFields";
                    cmd.CommandTimeout = 0;
                    cmd.Connection = connection;
                    cmd.Connection.Open();
                    SqlDataReader dr = cmd.ExecuteReader(CommandBehavior.CloseConnection);

                    while (dr.Read())
                    {
                        wsrStaticFields.Add(dr["FieldName"].ToString());
                    }
                    //if (al.Contains(fieldname))
                    //{
                    //    return true;
                    //}
                    //else
                    //{
                    //    return false;
                    //}
                    return wsrStaticFields;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }

        }

    }
}