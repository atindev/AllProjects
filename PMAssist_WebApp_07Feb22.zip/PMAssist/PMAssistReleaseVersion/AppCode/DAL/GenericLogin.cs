﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.Security;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using Microsoft.ApplicationBlocks.Data;
using System.Data;
using System.Data.SqlClient;
using System.Text;
using System.Configuration;
using System.Collections;

 
namespace PMAssistReleaseVersion.AppCode.Generic
{
    public class GenericLogin
    {
        public static Boolean  ValidateLogin(string PortalId, byte[] Password)
        {

           try
            {
                DataSet dstLogin;
                DataRow drow;

                SqlParameter[] SqlParam = new SqlParameter[2];
                SqlParam[0] = new SqlParameter("@intUnsmPortalId", PortalId);
                SqlParam[1] = new SqlParameter("@vchUnsmPassword", Password);
                //SqlParam[2] = new SqlParameter("@chUnsmIsManager", LoginType);

                dstLogin = SqlHelper.ExecuteDataset(clsGeneral.ConStr, "spLoginCheck", SqlParam);
                if (dstLogin != null)
                {
                    drow = dstLogin.Tables[0].Rows[0];

                    HttpContext.Current.Session["intUnsmPortalId"] = drow["UnsmPortalId"];
                    HttpContext.Current.Session["LoginType"] = drow["UnsmIsManager"];
                    return true;
                }

            }
            catch (Exception ex)
            {
                PMAssistReleaseVersion.AppCode.ErrorLogging.clsErrorLogging.LogError(ex.Message, "GenericLogin.cs", "ValidateLogin()");
            }

            return false;
             

        }

        // To get Email List 
        public static DataTable GetTeamEmailsList()
        {
            DataSet ds = SqlHelper.ExecuteDataset(clsGeneral.ConStr, "spGetTeamEmailList");
            return ds.Tables[0];

        }

    }
}