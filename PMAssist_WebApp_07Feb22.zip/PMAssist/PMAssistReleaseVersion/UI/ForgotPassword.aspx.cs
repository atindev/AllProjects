﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using Microsoft.ApplicationBlocks.Data;
using System.Data;
using System.Data.SqlClient;
using System.Text;
using PMAssistReleaseVersion.AppCode;
using PMAssistReleaseVersion.AppCode.Generic;
using AjaxControlToolkit;

namespace PMAssistReleaseVersion.UI
{
    public partial class ForgotPassword : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            try
            {
                if (!IsPostBack)
                {
                    LoadSecurityQuestion();
                    Page.Validate();
                }
            }
            catch (Exception ex)
            {
                PMAssistReleaseVersion.AppCode.ErrorLogging.clsErrorLogging.LogError(ex.Message, "ForgotPassword.aspx.cs", "Page_Load()");
                lblError.Text = "Failed";
            }

          }
        //Load SecurityQuestion dropdown
        public void LoadSecurityQuestion()
        {
            try
            {
                DataTable dt = clsUsers.LoadSecurityQuestionData();
                ddlSecurityQuestion.DataSource = dt;
                ddlSecurityQuestion.DataTextField = "ScqsSecurityQuestion";
                ddlSecurityQuestion.DataValueField = "ScqsID";
                ddlSecurityQuestion.DataBind();
                ddlSecurityQuestion.Items.Insert(0, new ListItem("Select Security Question", ""));
            }
            catch (Exception ex)
            {
                PMAssistReleaseVersion.AppCode.ErrorLogging.clsErrorLogging.LogError(ex.Message, "ForgotPassword.aspx.cs", "LoadSecurityQuestion()");
                lblError.Text = "Failed";
            }

        }

        //To verify User Security Rules
        public void VerifyUserSecurityRules()
        {
            try
            {
                string IsVerifiedUser = string.Empty;
                IsVerifiedUser = clsUsers.VerifyUserSecurityRules(txtPortalId.Text, ddlSecurityQuestion.SelectedValue, txtSecurityAnswer.Text, IsVerifiedUser);
                
                if (IsVerifiedUser == "Y")
                {
                    lblScqs.Visible = false;
                    ddlSecurityQuestion.Visible = false;
                    lblSecurityAnswer.Visible = false;
                    txtSecurityAnswer.Visible = false;
                    lblNewPassword.Visible = true;
                    lblConfirmPassword.Visible = true;
                    txtNewPassword.Visible = true;
                    txtConfirmPassword.Visible = true;
                    reqNewPasswordRequired.Enabled = true;
                    reqConfirmPasswordRequired.Enabled = true;
                    lblError.Text = "Please enter your new password.";
                    lblError.ForeColor = System.Drawing.Color.Green;  
                    btnSubmit.Visible = true;
                    btnSubmit.Text = "Update";
                }
                else
                {
                    txtConfirmPassword.Text = "";
                    ddlSecurityQuestion.SelectedValue = "";
                    txtSecurityAnswer.Text = "";
                    txtNewPassword.Text = "";
                    txtConfirmPassword.Text = "";

                    //Response.Redirect("~/UI/ForgotPassword.aspx");
                    lblError.Text = "Provided details are incorrect. <br/> Please try again.";
                    lblError.ForeColor = System.Drawing.Color.Red;  
                }
                Page.Validate();
            }

            catch (Exception ex)
            {
                PMAssistReleaseVersion.AppCode.ErrorLogging.clsErrorLogging.LogError(ex.Message, "ForgotPassword.aspx.cs", "VerifyUserSecurityRules()");
                lblError.Text = "Provided details are incorrect. <br/> Please try again.";
                lblError.ForeColor = System.Drawing.Color.Red;      
            }
        }

        //To reset password
        public bool UpdatePassword()
        {
            bool sucess = false;
            try
            {
                string IsVerifiedUser;
                byte[] confirmpassword;
                IsVerifiedUser = 'Y'.ToString();
                confirmpassword = new ASCIIEncoding().GetBytes(txtConfirmPassword.Text);
                clsUsers.UpdatePassword(IsVerifiedUser, txtPortalId.Text, confirmpassword);
                
                sucess = true;
            }

            catch (Exception ex)
            {
                PMAssistReleaseVersion.AppCode.ErrorLogging.clsErrorLogging.LogError(ex.Message, "ForgotPassword.aspx.cs", "UpdatePassword()");
                lblError.Text = "Failed to Reset";
                sucess = false;
            }
            return sucess;
        }

        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            // To validate detials and if true reset password
            try
            {
                bool proceed = false;
                if (btnSubmit.Text == "Submit")
                {
                    VerifyUserSecurityRules();
                    
                }
                else if (btnSubmit.Text == "Update")
                {
                    proceed = UpdatePassword();
                    lblError.Text = "Your password has been reset." + Environment.NewLine + "Please Login to continue.";
                    lblError.ForeColor = System.Drawing.Color.Green;
                    
                }
            }
            catch (Exception ex)
            {
                PMAssistReleaseVersion.AppCode.ErrorLogging.clsErrorLogging.LogError(ex.Message, "forgotPassword.aspx.cs", "btnSubmit_Click()");
                lblError.Text = "Failed to Update, Authentication Failed";
            }
        }
    }
}