﻿using System;
using System.Collections.Generic;
using System.Text;

namespace WAS.Application.Features.Subscription.DiscardOcrSubscription
{
    public class Response
    {
        /// <summary>
        /// Is subscription success
        /// </summary>
        public bool Success { get; set; }
    }
}
