﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.Security;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using Microsoft.ApplicationBlocks.Data;
using System.Data;
using System.Data.SqlClient;
using System.Text;
using System.Collections;

namespace PMAssistReleaseVersion.AppCode.Generic
{
    public class clsSearch
    {

        //To Get all the details if given values are empty
        public static DataTable GetTicketDetails()
        {
            DataSet ds = SqlHelper.ExecuteDataset(clsGeneral.ConStr, "spLoadTicketDetails");
            return ds.Tables[0];
        }

        //To get Specific search criteria.. 
        public static DataSet GetTicketDetailsbyCriteria(string strReferenceNumber, string strModule, string strFromDate, string strToDate, string strCOType, string strTicketType, string strStatus, string strAssignedTo)
        {
            try
            {
                SqlCommand cmd = clsManagerResourceCommon.GetAllCommonCommandObjectParameters(strReferenceNumber, strModule, strFromDate, strToDate, strCOType, strTicketType, strStatus, strAssignedTo);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "spLoadTicketDetails";
                cmd.CommandTimeout = 0;

                return SqlHelper.ExecuteDataset(clsGeneral.ConStr, cmd.CommandType, cmd.CommandText, cmd);
            }
            catch (Exception ex)
            {
                PMAssistReleaseVersion.AppCode.ErrorLogging.clsErrorLogging.LogError(ex.Message, "clsSearch.cs", "GetTicketDetailsbyCriteria");
                throw;
            }

        }

        //Search by date to generate WSR or MSR.. 
        public static DataSet GetTicketDetailsbetweenFromDateTodate(string strFromdate, string strToDate)
        {
            try
            {
                SqlParameter[] par = new SqlParameter[2];
                par[0] = new SqlParameter("@vchFromDate", strFromdate);
                par[1] = new SqlParameter("@vchToDate", strToDate);

                return SqlHelper.ExecuteDataset(clsGeneral.ConStr, "sptblSearchTicketDetailsBetweenTwoDates", par);

            }
            catch (Exception ex)
            {
                PMAssistReleaseVersion.AppCode.ErrorLogging.clsErrorLogging.LogError(ex.Message, "clsSearch.cs", "GetTicketDetailsbyDate");
                throw;
            }

        }

        // To get the user details

        public static DataSet GetUserDetails(string strportalId)
        {
            try
            {
                SqlParameter[] par = new SqlParameter[1];
                par[0] = new SqlParameter("@intPortalID", strportalId);

                return SqlHelper.ExecuteDataset(clsGeneral.ConStr, "spLoadUserDetails", par);

            }

            catch (Exception ex)
            {
                PMAssistReleaseVersion.AppCode.ErrorLogging.clsErrorLogging.LogError(ex.Message, "clsSearch.cs", "GetUserDetails");
                throw;
            }
        }


        // To Get Task Details by ID 


        //To get Specific search criteria.. 
        public static DataSet GetTaskDetailsByCriteria(string strTaskDate, string strResource)
        {
            try
            {
                SqlCommand cmd = clsManagerResourceCommon.GetAllCommonCommandObjectParameters(strTaskDate, strResource);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "spLoadTaskDetailsByCriteria";
                cmd.CommandTimeout = 0;

                return SqlHelper.ExecuteDataset(clsGeneral.ConStr, cmd.CommandType, cmd.CommandText, cmd);
            }
            catch (Exception ex)
            {
                PMAssistReleaseVersion.AppCode.ErrorLogging.clsErrorLogging.LogError(ex.Message, "clsSearch.cs", "GetTaskDetailsbyCriteria");
                throw;
            }

        }
        // Task

        public static DataTable GetTaskDetails()
        {
            DataSet ds = SqlHelper.ExecuteDataset(clsGeneral.ConStr, "spLoadTaskDetails");
            return ds.Tables[0];
        }


    }
}