﻿using System.Timers;
using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace TryCharts
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class chartPage : ContentPage
    {
        private readonly ViewModel viewmodel;

        private static Timer wdTimer = new Timer(5000);

        public chartPage()
        {
            viewmodel = new ViewModel();
            InitializeComponent();
            ////viewmodel.FormChart(barChart);

            wdTimer.Elapsed += Check;
            wdTimer.Start();
            wdTimer.Enabled = true;

            BindingContext = viewmodel;
        }

        private void Check(object sender, ElapsedEventArgs e)
        {
            Set();
        }

        private void Button_Clicked(object sender, System.EventArgs e)
        {
            Set();
        }

        private void Set()
        {
            Device.BeginInvokeOnMainThread(async () =>
            {
                var te = await viewmodel.GetWeight();
                Weight.Text = !string.IsNullOrEmpty(te) ? te : "NA";
            });
        }
    }
}