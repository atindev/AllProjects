﻿using WAS.Application.Common.Models;

namespace WAS.Application.Features.Notification.ViewAttachment
{
    public class Response : AttachmentData
    {
    }
}
