﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace PMAssistReleaseVersion.AppCode
{
    public class clsTicketDetails
    {       
        public int TicketId {get;set;}
        public string TicketReferenceNumber {get;set;}
        public int TicketTypeId { get; set; }
        public int TicketTypeInDetailId { get; set; }
        public int CoId {get;set;}
        public int CotypeId { get; set; }
        public string CoNumber {get;set;}
        public int ComplexityId { get; set; }
        public int PriorityId {get;set;}
        public int ModuleId {get;set;}
        public int IncidentCategoryId {get;set;}
        public int StatusOfTicketId {get;set;}
        public string AssignedTo {get;set;}
        public string FirstName { get; set; }
        public string AssignedTime {get;set;}
        public string AssignedDate { get; set; }
        public string ResolvedDate {get;set;}
        public string ResolvedTime {get;set;}
        public string AcknowldedgeDate {get;set;}
        public string AcknowldedgeTime {get;set;}
        public string TargetDate { get; set; }
        public string Comments {get;set;}
        public string Description { get; set; }
        public string ReasonForRejection { get; set; }
        public char Deleted {get;set;}
        public int EntryId {get;set;}
        public string EntryDate {get;set;}
        public string KpiDate {get;set;}
        public int LastChangedId {get;set;}
        public string LastChangedDate {get;set;}
        public int OriginOfDefect { get; set; }
        public string ReviewedBy { get; set; }
        public string DateOfPeerReview { get; set; }
        public string ActualEffort { get; set; }
    }
}