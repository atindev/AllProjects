﻿using MediatR;
using System;
using System.Collections.Generic;
using System.Text;

namespace WAS.Application.Features.Notification.GetWhatsAppTemplate
{
   public class Request:IRequest<Response>
    {
    }
}
