﻿using System;
using System.Collections.Generic;
using System.Text;

namespace WAS.Application.Features.Notification.ApproveReject
{
    public class Response
    {
        /// <summary>
        /// Is Notification approve/reject status change success
        /// </summary>
        public bool Success { get; set; }
    }
}
