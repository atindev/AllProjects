﻿using System;
using WAS.Application.Common.Models;

namespace WAS.Application.Features.Survey.Broadcast
{
    public class Response : BroadcastSurveyResponse
    {
       
    }
}
