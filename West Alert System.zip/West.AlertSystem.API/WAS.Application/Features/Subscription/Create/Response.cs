﻿namespace WAS.Application.Features.Subscription.Create
{
    public class Response
    {
        /// <summary>
        /// Is subscription success
        /// </summary>
        public bool Success { get; set; }
        
    }
}
