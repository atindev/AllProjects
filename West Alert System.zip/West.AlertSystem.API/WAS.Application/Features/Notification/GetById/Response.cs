﻿namespace WAS.Application.Features.Notification.GetById
{
    public class Response
    {
        /// <summary>
        /// Notification details
        /// </summary>
        public Common.Models.Notification Notification { get; set; }

    }
}
