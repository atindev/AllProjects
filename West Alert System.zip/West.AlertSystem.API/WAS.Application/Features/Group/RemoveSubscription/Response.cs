﻿using System;
using System.Collections.Generic;
using System.Text;

namespace WAS.Application.Features.Group.RemoveSubscription
{
    public class Response
    {
        /// <summary>
        /// Is Groups Create/update success
        /// </summary>
        public bool Success { get; set; }

    }
}
